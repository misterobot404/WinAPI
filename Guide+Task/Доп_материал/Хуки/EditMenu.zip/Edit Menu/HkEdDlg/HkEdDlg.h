#ifndef HKEDDLG_H
#define HKEDDLG_H

LRESULT DlgBoxMsgFilter( UINT code, WPARAM wParam, LPARAM lParam );
BOOL CALLBACK DlgProc( HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam );

#endif