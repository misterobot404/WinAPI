#include "stdafx.h"
#include "HookLib\SysMsgFilter.h"

BOOL CALLBACK EditDlgProc( HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam )
{
	static HINSTANCE    hLib  = NULL;
	static IHookDriver* pHook = NULL;

	switch( msg )
	{
	case WM_INITDIALOG:
		break;
	case WM_COMMAND:
		switch(wParam)
		{
		case IDOK:
			{
				hLib = LoadLibrary( _T("HookLib.dll") );
				if( hLib )
				{
					IHookDriver* (*pfnGetHookObject)();
					*(FARPROC*)&pfnGetHookObject = GetProcAddress( hLib, "GetHookObject" );
					if( pfnGetHookObject )
					{
						pHook = pfnGetHookObject();
						if( pHook )
						{
							pHook->SetHwnd( (long)GetDlgItem(hDlg, IDC_LOG) );
							pHook->Set( (long)hLib, 0 );
						}
					}
					if(pHook) 
						EnableWindow( GetDlgItem( hDlg, IDOK ), FALSE );
				}
			}
			break;
		case IDCANCEL:
			{
				if(hLib)
				{
					if( pHook )
						pHook->Free();
					FreeLibrary( hLib );
				}
			}
			EndDialog( hDlg, 0 );
			break;
		}
		break;
	}
	return 0;
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	DialogBox( 
			hInstance, 
			MAKEINTRESOURCE(IDD_EDITDLG),
			HWND_DESKTOP,
			(DLGPROC)EditDlgProc );
	return 0;
}



