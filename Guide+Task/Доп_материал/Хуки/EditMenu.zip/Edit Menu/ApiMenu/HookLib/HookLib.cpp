#include "stdafx.h"

#define __GLOBAL_HOOK
#include "SysMsgFilter.h"

ALLOCATE_GLOBAL_HOOK_OBJ( CHookSysMsgFilter, mf, CData, g_data ) = CData(WH_SYSMSGFILTER);

extern "C" __declspec(dllexport) 
IHookDriver* GetHookObject()
{
    return static_cast<IHookDriver*> (&mf);
}

