//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ApiMenu.rc
//
#define IDD_EDITDLG                     101
#define IDR_EDITMENU                    102
#define ID_ADD                          1000
#define IDC_LOG                         1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
