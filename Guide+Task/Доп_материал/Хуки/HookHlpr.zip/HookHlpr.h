///////////////////////////////////////////////////////////////
//
// HookHlpr.h
//
// 2002 (c) Igor Vartanov
//
// Version 1.0
//
// Last update: Aug 28 2002
//
// mailto:ivartanov@rsdn.ru
// FIDOnet 2:5025/16.26 AKA /38.70
//
///////////////////////////////////////////////////////////////


#ifndef __IV_HOOKHELPER_H_
#define __IV_HOOKHELPER_H_

#if defined( __GLOBAL_HOOK ) && ( defined( _DLL ) || defined( _USRDLL ) )
    
#pragma comment(linker, "/section:HOOKDAT,RWS") 
#pragma data_seg("HOOKDAT") 
#pragma data_seg() 

#endif

#ifndef stringer
#define stringer( x ) ( #x )
#endif

///////////////////////////////////////////////////////////////
//  C-valuable part of Helper

// Client-side definitions
/*----------- Local hooks -------------------------------------*/

#define DECLARE_LOCAL_HOOK( hook_message, HookProc )             \
    static HHOOK __g_hhk_##hook_message = NULL;                  \
    LRESULT CALLBACK __HookProc_##hook_message(                  \
                         int code,                               \
                         WPARAM wParam,                          \
                         LPARAM lParam  )                        \
        {                                                        \
            LRESULT res = 0;                                     \
            if( 0 > code )                                       \
                return CallNextHookEx( __g_hhk_##hook_message,   \
                                       code, wParam, lParam );   \
            res = HookProc( code, wParam, lParam );              \
            if( !res )                                           \
                return CallNextHookEx( __g_hhk_##hook_message,   \
                                       code, wParam, lParam );   \
            return res;                                          \
        }

#define SET_LOCAL_HOOK( hook_message )    \
    { __g_hhk_##hook_message =             \
                SetWindowsHookEx(          \
                hook_message,              \
                __HookProc_##hook_message, \
                GetModuleHandle(NULL),     \
                GetCurrentThreadId() );    \
    }

#define UNHOOK_LOCAL_HOOK( hook_message )   \
        { if( __g_hhk_##hook_message ) \
              UnhookWindowsHookEx( __g_hhk_##hook_message ); \
        }

#define IS_VALID_HHOOK( hook_message ) \
    ( NULL != __g_hhk_##hook_message ) \


/*----------- Global hooks ------------------------------------*/

#define DECLARE_HOOK_DLL( hook_message )                         \
    static HINSTANCE __HookLib_##hook_message = NULL;            \
    static HHOOK*    __g_phhk_##hook_message  = NULL;            \
    HOOKPROC __HookProc_##hook_message = NULL;

#define LOAD_HOOK_DLL( hook_message, libname )                   \
    {                                                            \
        __HookLib_##hook_message = LoadLibrary( libname );       \
        _ASSERTE(__HookLib_##hook_message);                      \
        if( __HookLib_##hook_message )                           \
        {                                                        \
            __HookProc_##hook_message = (HOOKPROC)               \
                    GetProcAddress( __HookLib_##hook_message,    \
                    stringer(___HookProc_##hook_message@12) );   \
            _ASSERTE( __HookProc_##hook_message );               \
            __g_phhk_##hook_message = (HHOOK*)                   \
                    GetProcAddress( __HookLib_##hook_message,    \
                             stringer(__g_hhk_##hook_message) ); \
            _ASSERTE(__g_phhk_##hook_message);                   \
            *__g_phhk_##hook_message =                           \
                            SetWindowsHookEx( hook_message,      \
                                      __HookProc_##hook_message, \
                                      __HookLib_##hook_message,  \
                                      NULL );                    \
            _ASSERTE(*__g_phhk_##hook_message);                  \
        }                                                        \
    }

#define UNLOAD_HOOK_DLL( hook_message )                          \
    {                                                            \
        if(*__g_phhk_##hook_message)                             \
            UnhookWindowsHookEx(*__g_phhk_##hook_message);       \
        if(__HookLib_##hook_message)                             \
            FreeLibrary( __HookLib_##hook_message );             \
    }

#define IS_VALID_DLL_HHOOK( hook_message ) \
    ( _CrtIsValidPointer( __g_phhk_##hook_message, sizeof(HHOOK*), TRUE ) \
      && *__g_phhk_##hook_message ) \


// Dll-side definitions (for global hooking)

#define DECLARE_GLOBAL_HOOK( hook_message, HookProc )            \
    EXTERN_C __declspec(dllexport)                               \
    __declspec( allocate("HOOKDAT") )                            \
    HHOOK __g_hhk_##hook_message = NULL;                         \
    EXTERN_C __declspec(dllexport)                               \
    LRESULT CALLBACK __HookProc_##hook_message(                  \
                         int code,                               \
                         WPARAM wParam,                          \
                         LPARAM lParam )                         \
        {                                                        \
            LRESULT res = 0;                                     \
            if( 0 > code )                                       \
                return CallNextHookEx( __g_hhk_##hook_message,   \
                                       code, wParam, lParam );   \
            res = HookProc( code, wParam, lParam );              \
            if( !res )                                           \
                return CallNextHookEx( __g_hhk_##hook_message,   \
                                       code, wParam, lParam );   \
            return res;                                          \
        }


///////////////////////////////////////////////////////////////
//  C++ part of Helper

#ifdef __cplusplus

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <crtdbg.h>

// CHookBaseData 
struct CHookBaseData
{
    HHOOK      m_hHook;
    int        m_nHookType;
};

// CHookThunk
#pragma pack(push,1)
typedef struct  
{
    // move code ( dword ptr [esp+0x4] ) to eax
    DWORD   m_movc; // 0x0424448B
    // move eax to member m_nCode
    BYTE    m_move; // 0xA3
    DWORD   m_addr; // m_nCode address
    // move this to code ( dword ptr [esp+0x4] )
    DWORD   m_movt; // 0x042444C7
    DWORD   m_this; // this
    // jump to static _HookProc
    BYTE    m_jump; // 0xE9
    DWORD   m_proc; // offset to _HookProc
} CHookThunk;
#pragma pack(pop)

// CHookBaseT
template <class T, class TData = CHookBaseData> 
class CHookBaseT
{
private:
    CHookThunk m_thunk;
    int        m_nCode;

protected:  
    TData* m_pData;
    
private:
    static LRESULT WINAPI _HookProc( T* pThis, WPARAM wParam, LPARAM lParam )
    {
        LRESULT ret = 0;
        if( 0 > pThis->GetCode() )
            return ::CallNextHookEx( pThis->GetHookHandle(), 
                                     pThis->GetCode(), 
                                     wParam, lParam );
        ret = pThis->HookProc( pThis->GetCode(), wParam, lParam );
        if( !ret )
            return ::CallNextHookEx( pThis->GetHookHandle(), 
                                     pThis->GetCode(), 
                                     wParam, lParam );
        return ret;
    }

public:
    CHookBaseT() : m_pData(NULL)
    {
    }

    CHookBaseT( TData* pData ) : m_pData(pData)
    {
    }

    void Init()
    {
        T* pThis = static_cast< T* > (this);

        m_thunk.m_movc = 0x0424448B;
        m_thunk.m_move = 0xA3;
        m_thunk.m_addr = (DWORD)&m_nCode;
        m_thunk.m_movt = 0x042444C7;
        m_thunk.m_this = (DWORD)pThis;
        m_thunk.m_jump = 0xE9;
        m_thunk.m_proc = (int)_HookProc - ( (int)&m_thunk + sizeof(m_thunk) );
    }

    void SetHookHandle( HHOOK hHook )
    {
        m_pData->m_hHook = hHook;
    }

    void SetHookType( int nHookType )
    {
        m_pData->m_nHookType = nHookType;
    }

    BOOL SetHook( HINSTANCE hInst, DWORD dwThreadId )
    {
        _ASSERTE( m_pData->m_nHookType );
        _ASSERTE( !m_pData->m_hHook );
        _ASSERTE( hInst || dwThreadId );  // one of them should be nonzero
        m_pData->m_hHook = 
            ::SetWindowsHookEx( m_pData->m_nHookType, 
                                (HOOKPROC)&m_thunk, 
                                hInst, dwThreadId );
        _ASSERTE(m_pData->m_hHook);
        return (BOOL)m_pData->m_hHook;
    }

    void Unhook()
    {
        _ASSERTE( m_pData->m_hHook );
        if( m_pData->m_hHook )
            ::UnhookWindowsHookEx( m_pData->m_hHook );
        m_pData->m_hHook = NULL;
    }

    BOOL IsValid() const
    {
        return (BOOL)m_pData->m_hHook;
    }

    inline 
    HHOOK GetHookHandle() const
    {
        return m_pData->m_hHook;
    }

    inline 
    int GetHookType() const
    {
        return m_pData->m_nHookType;
    }

    inline 
    int GetCode() const
    {
        return m_nCode;
    }

    void AttachData( TData* pData )
    { 
        m_pData = pData;
    }
};

#if defined( __GLOBAL_HOOK ) && ( defined( _DLL ) || defined( _USRDLL ) )
    
    #define ALLOCATE_GLOBAL_HOOK_OBJ( TObject, obj, TData, data ) \
        extern TData data;     \
        TObject obj( & data ); \
        __declspec(allocate("HOOKDAT")) TData data \

#endif


#endif // ifdef __cplusplus

#endif // ifndef __IV_HOOKHELPER_H_