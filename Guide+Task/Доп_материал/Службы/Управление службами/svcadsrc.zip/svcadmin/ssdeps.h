// ssdeps.h
//
// Start/Stop dependencies dialog
//
// $Id: $
//

#ifndef __ssdeps_h_included
#define __ssdeps_h_included

class CMainWnd;
class CService;

class CStartStopDlg : public CDialogImpl<CStartStopDlg>
{
  public:

	CStartStopDlg(CMainWnd * pMainWnd)
		{ m_pMainWnd = pMainWnd; m_pszList = NULL; m_bStop = FALSE; }

	~CStartStopDlg()
		{ if (m_pszList != NULL) free(m_pszList); }

	PCTSTR GetAffectedList(CService * pService, BOOL bStop);

  public:

	enum { IDD = IDD_START_STOP_DEPS };

	BEGIN_MSG_MAP_EX(CStartStopDlg)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDOK, BN_CLICKED, OnOK)
		CMD_SIMPLE(IDCANCEL, BN_CLICKED, OnCancel)
	END_MSG_MAP()

  protected:

	BOOL OnInitDialog(HWND, LPARAM);

	void OnOK()
		{ EndDialog(IDOK); }

	void OnCancel()
		{ EndDialog(IDCANCEL); }

  protected:

	CMainWnd *		m_pMainWnd;		// pointer to the main window
	BOOL			m_bStop;		// stopping flag
	PTSTR			m_pszList;		// list of affected services
	UINT			m_iEnd;			// index of the end of the list
	UINT			m_cchList;		// allocated memory for the list

  protected:

	void GetStartServices(PCTSTR pszName);
	void GetStopServices(PCTSTR pszName);
	void AppendName(PCTSTR pszName);

};

#endif // __ssdeps_h_included
