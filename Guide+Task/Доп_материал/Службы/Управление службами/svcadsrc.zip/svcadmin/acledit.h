// acledit.h
//
// ACLEDIT.DLL interface
//
// Based on the description at www.sysinternals.com by Mark Russinovich
//
// $Id: $
//

#ifndef __acledit_h_included
#define __acledit_h_included

typedef struct _ACLHELPCONTROL {
	PWSTR				HelpFile;
	DWORD				MainDialogTopic;
	DWORD				ACLEditorDialogTopic;
	DWORD				Reserved1;
	DWORD				AddEntryDialogTopic;
	DWORD				Reserved2;
	DWORD				Reserved3;
	DWORD				AccountDialogTopic;
} ACLHELPCONTROL, * PACLHELPCONTROL; 

typedef struct _ACLEDITENTRY {
	DWORD				Type;
	DWORD				AccessMask;
	DWORD				Reserved;
	PWSTR				Name;
} ACLEDITENTRY, * PACLEDITENTRY;

typedef struct _ACLEDITCONTROL {
	DWORD				NumberOfEntries;
	PACLEDITENTRY		Entries;
} ACLEDITCONTROL, * PACLEDITCONTROL;

typedef struct _ACLDLGCONTROL {
    DWORD				Version;
    PGENERIC_MAPPING	GenericAccessMap; 
    PGENERIC_MAPPING	SpecificAccessMap; 
    PWSTR				DialogTitle;
    PACLHELPCONTROL		HelpInfo;
    PWSTR				SubReplaceTitle;
    DWORD				Reserved;
    PWSTR				SubReplaceConfirmation;
    PWSTR				SpecialAccess;
} ACLDLGCONTROL, * PACLDLGCONTROL;

typedef DWORD (CALLBACK * PACLCHANGE)( 
    IN PVOID DontKnow1, 
    IN PVOID DontKnow2, 
    IN PVOID CallbackContext, 
    IN PSECURITY_DESCRIPTOR NewSD,
    IN PVOID DontKnow3, 
    IN PVOID DontKnow4,
    IN PVOID DontKnow5, 
    OUT PDWORD ChangeContextStatus
	);

EXTERN_C
DECLSPEC_IMPORT
DWORD
APIENTRY
SedDiscretionaryAclEditor( 
	IN HWND hWnd, 
	IN HINSTANCE Instance,               
	IN PCWSTR MachineName OPTIONAL,
	IN PACLDLGCONTROL AclDlgControl,
	IN PACLEDITCONTROL AclEditControl,
	IN PCWSTR ObjectName,
	IN PACLCHANGE ChangeCallback,
	IN PVOID ChangeCallbackContext,
	IN PSECURITY_DESCRIPTOR ObjectSecurity,
	IN BOOLEAN NoReadPermission,
	IN BOOLEAN ReadOnly,
	OUT PDWORD ChangeContextStatus,
	IN PVOID MustBeZero
	);

EXTERN_C
DECLSPEC_IMPORT
DWORD
APIENTRY
SedSystemAclEditor(
	IN HWND hWnd,
	IN HINSTANCE Instance,
	IN PCWSTR MachineName OPTIONAL,
	IN PACLDLGCONTROL AclDlgControl,
	IN PACLEDITCONTROL AclEditControl,
	IN PCWSTR ObjectName,
	IN PACLCHANGE ChangeCallback,
	IN PVOID ChangeCallbackContext,
	IN PSECURITY_DESCRIPTOR ObjectSecurity,
	IN BOOLEAN NoReadPermission,
	OUT PDWORD ChangeContextStatus,
	IN PVOID MustBeZero
	);          

EXTERN_C
DECLSPEC_IMPORT
DWORD
APIENTRY
SedTakeOwnership(
	IN HWND hWnd,
	IN HINSTANCE Instance,
	IN PCWSTR MachineName OPTIONAL,
	IN PCWSTR ObjectType,
	IN PCWSTR ObjectName,
	IN BOOLEAN SetToTrue,
	IN PACLCHANGE ChangeCallback,
	IN PVOID ChangeCallbackContext,
	IN PSECURITY_DESCRIPTOR ObjectSecurity,
	IN BOOLEAN NoReadPermission,
	IN PVOID DontCare1,
	OUT PDWORD ChangeContextStatus,
	IN PACLHELPCONTROL HelpInfo,
	IN PVOID MustBeZero
	); 

#endif // __acledit_h_included
