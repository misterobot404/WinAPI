// svcobj.cpp
//
// Service object implementation.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "svcobj.h"

//---------------------------------------------------------------------------
// Init
//
//  Initializes the object.
//
//  Parameters:
//	  hSCM    - service control manager handle
//	  pStatus - pointer to a structure describing the service
//
//  Returns:
//	  standard COM return code.
//
HRESULT
CService::Init(
	SC_HANDLE hSCM,
	LPENUM_SERVICE_STATUS pStatus
	)
{
	_ASSERTE(hSCM != NULL);
	_ASSERTE(pStatus != NULL);

	lstrcpyn(m_szName, pStatus->lpServiceName, countof(m_szName));

	return Update(hSCM, pStatus);
}

//---------------------------------------------------------------------------
// Update
//
//  Updates service object data.
//
//  Parameters:
//	  hSCM	  - service control manager handle
//	  pStatus - pointer to a structure describing the service
//
//  Returns:
//	  standard COM return code.
//
HRESULT
CService::Update(
	SC_HANDLE hSCM,
	LPENUM_SERVICE_STATUS pStatus
	)
{
	_ASSERTE(pStatus != NULL);
	_ASSERTE(lstrcmpi(pStatus->lpServiceName, m_szName) == 0);

	SC_HANDLE hService;
	HRESULT hRes;

	lstrcpyn(m_szDisplayName, pStatus->lpDisplayName, 
			 countof(m_szDisplayName));

	m_dwCurrentState	 = pStatus->ServiceStatus.dwCurrentState;
	m_dwControlsAccepted = pStatus->ServiceStatus.dwControlsAccepted;
	m_bDelete			 = FALSE;

	m_dwStartupType  = SERVICE_INVALID_VALUE;
	m_dwServiceType	 = SERVICE_INVALID_VALUE;
	m_dwErrorControl = SERVICE_INVALID_VALUE;

	// open service with SERVICE_QUERY_CONFIG access right
	hService = OpenService(hSCM, m_szName, SERVICE_QUERY_CONFIG);
	if (hService == NULL)
	{
		_RPT_API_FAILED(OpenService);
		return HRESULT_FROM_WIN32(GetLastError());
	}

	// query basis service configuration
	hRes = QueryConfig(hService);

	// query service description
	if (SUCCEEDED(hRes))
		hRes = QueryDescription(hService);

	// query service failure actions
	if (SUCCEEDED(hRes))
		hRes = QueryFailureActions(hService);

	// close service handle
	_VERIFY(CloseServiceHandle(hService));

	return hRes;
}

//---------------------------------------------------------------------------
// QueryConfig
//
//  Queries service configuration.
//
//  Parameters:
//	  hService - service handle
//
//  Returns:
//	  standard COM return code.
//
HRESULT
CService::QueryConfig(
	SC_HANDLE hService
	)
{
	_ASSERTE(hService != NULL);

	DWORD cbNeeded;
	LPQUERY_SERVICE_CONFIG pConfig;
	DWORD dwError;

	if (!QueryServiceConfig(hService, NULL, 0, &cbNeeded))
	{
		dwError = GetLastError();

		if (dwError != ERROR_INSUFFICIENT_BUFFER)
			return HRESULT_FROM_WIN32(dwError);
	}

	pConfig = (LPQUERY_SERVICE_CONFIG)_alloca(cbNeeded);
	_ASSERTE(pConfig != NULL);

	if (!QueryServiceConfig(hService, pConfig, cbNeeded, &cbNeeded))
		return HRESULT_FROM_WIN32(GetLastError());

	m_dwServiceType = pConfig->dwServiceType;
	m_dwStartupType = pConfig->dwStartType;
	m_dwErrorControl = pConfig->dwErrorControl;

	lstrcpyn(m_szLoadGroup, pConfig->lpLoadOrderGroup, 
			 countof(m_szLoadGroup));

	lstrcpyn(m_szImagePath, pConfig->lpBinaryPathName, 
			 countof(m_szImagePath));

	PCTSTR pszLogon = pConfig->lpServiceStartName;
	if (pszLogon == NULL)
	{
		lstrcpyn(m_szLogon, _szLocalSystem, countof(m_szLogon));
		m_bLocalSystem = TRUE;
	}
	else
	{
		lstrcpyn(m_szLogon, pszLogon, countof(m_szLogon));
		m_bLocalSystem = lstrcmpi(pszLogon, _szLocalSystem) == 0;
		m_bLocalService = lstrcmpi(pszLogon, _szLocalService) == 0;
		m_bNetworkService = lstrcmpi(pszLogon, _szNetworkService) == 0;
	}

	return S_OK;
}

//---------------------------------------------------------------------------
// QueryDescription
//
//  Queries service description.
//
//  Parameters:
//	  hService - service handle
//
//  Returns:
//	  standard COM return code.
//
HRESULT
CService::QueryDescription(
	SC_HANDLE hService
	)
{
	_ASSERTE(hService != NULL);

	if (_QueryServiceConfig2 == NULL)
	{
		_ASSERTE(m_pszDescription == (PTSTR)&_chNil);
		return S_OK;
	}

	if (m_pszDescription != (PTSTR)&_chNil)
	{
		free(m_pszDescription);
		m_pszDescription = (PTSTR)&_chNil;
	}

	DWORD cbNeeded;
	LPSERVICE_DESCRIPTION pDesc;
	DWORD dwError;

	if (!_QueryServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION,
							  NULL, 0, &cbNeeded))
	{
		dwError = GetLastError();

		if (dwError == ERROR_CALL_NOT_IMPLEMENTED)
			return S_OK;

		if (dwError != ERROR_INSUFFICIENT_BUFFER)
			return HRESULT_FROM_WIN32(dwError);
	}

	pDesc = (LPSERVICE_DESCRIPTION)malloc(cbNeeded);
	if (pDesc == NULL)
		return E_OUTOFMEMORY;

	if (!_QueryServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION,
							  (PBYTE)pDesc, cbNeeded, &cbNeeded))
	{
		dwError = GetLastError();
		free(pDesc);
		return HRESULT_FROM_WIN32(dwError);
	}

	if (pDesc->lpDescription != NULL)
	{
		// dirty trick
		int len = lstrlen(pDesc->lpDescription);
		memmove(pDesc, pDesc->lpDescription, (len + 1) * sizeof(TCHAR));
		m_pszDescription = (PTSTR)pDesc;
	}
	else
		free(pDesc);

	return S_OK;
}

//---------------------------------------------------------------------------
// QueryFailureActions
//
//  Queries service failure actions.
//
//  Parameters:
//	  hService - service handle
//
//  Returns:
//	  standard COM return code.
//
HRESULT
CService::QueryFailureActions(
	SC_HANDLE hService
	)
{
	_ASSERTE(hService != NULL);

	if (m_pActions != NULL)
	{
		free(m_pActions);
		m_pActions = NULL;
	}

	if (_QueryServiceConfig2 == NULL)
		return S_OK;

	DWORD cbNeeded;
	DWORD dwError;

	if (!_QueryServiceConfig2(hService, SERVICE_CONFIG_FAILURE_ACTIONS,
							  NULL, 0, &cbNeeded))
	{
		dwError = GetLastError();

		if (dwError == ERROR_CALL_NOT_IMPLEMENTED)
			return S_OK;

		if (dwError != ERROR_INSUFFICIENT_BUFFER)
			return HRESULT_FROM_WIN32(dwError);
	}

	m_pActions = (PSFA)malloc(cbNeeded);
	if (m_pActions == NULL)
		return E_OUTOFMEMORY;

	if (!_QueryServiceConfig2(hService, SERVICE_CONFIG_FAILURE_ACTIONS,
							  (PBYTE)m_pActions, cbNeeded, &cbNeeded))
		return HRESULT_FROM_WIN32(GetLastError());

	return S_OK;
}
