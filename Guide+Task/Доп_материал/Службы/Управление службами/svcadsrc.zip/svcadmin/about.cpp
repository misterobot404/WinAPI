// aboutdlg.cpp
//
// About dialog.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "about.h"

//---------------------------------------------------------------------------
// OnCtlColorDlg
//
//  Handles WM_CTLCOLORDLG message. Draws the background for the dialog.
//
//  Parameters:
//    hDC  - device context
//    hWnd - dialog window handle
//
//  Returns:
//	  handle to the brush which will be used to fill dialog background.
//
HBRUSH
CAboutDlg::OnCtlColorDlg(
	HDC hDC,
	HWND hWnd
    )
{
    _UNUSED(hWnd);

	HDC hMemDC = CreateCompatibleDC(hDC);
	_ASSERTE(hMemDC != NULL);

	HGDIOBJ hBitmap = SelectObject(hMemDC, m_bmpBack);

	RECT rcClip;
	GetClipBox(hDC, &rcClip);

	_VERIFY(BitBlt(hDC, rcClip.left, rcClip.top, rcClip.right - rcClip.left,
				   rcClip.bottom - rcClip.top, hMemDC, rcClip.left, 
				   rcClip.top, SRCCOPY));

	SelectObject(hMemDC, hBitmap);
	_VERIFY(DeleteDC(hMemDC));

	return (HBRUSH)GetStockObject(NULL_BRUSH);
}

//---------------------------------------------------------------------------
// OnCtlColorStatic
//
//  Handles WM_CTLCOLORSTATIC message. Draws the URL static control with
//	blue color and makes all other static controls transparent.
//
//  Parameters:
//    hDC  - device context
//    hWnd - dialog window handle
//
//  Returns:
//	  handle to the brush which will be used to fill static control
//    background.
//
HBRUSH
CAboutDlg::OnCtlColorStatic(
    HDC hDC,
    HWND hWnd
    )
{
	if (hWnd == m_hWndUrl)
		SetTextColor(hDC, RGB(0x00,0x00,0xC0));

	SetBkMode(hDC, TRANSPARENT);
	return (HBRUSH)GetStockObject(NULL_BRUSH);
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Creates bold and underlined version of
//  the standard dialog font and assign them to the static controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CAboutDlg::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	HGDIOBJ hFont = (HGDIOBJ)SendDlgItemMessage(IDC_HEADER, WM_GETFONT);
	if (hFont == NULL)
		hFont = GetStockObject(DEFAULT_GUI_FONT);

	LOGFONT lf;
	_VERIFY(GetObject(hFont, sizeof(lf), &lf));

	lf.lfWeight = FW_BOLD;
	_VERIFY(m_fntBold.CreateFontIndirect(&lf));

	lf.lfWeight = FW_NORMAL;
	lf.lfUnderline = TRUE;
	_VERIFY(m_fntUnderline.CreateFontIndirect(&lf));

	m_fntHeader = CreateLocalFont(MAKEINTRESOURCE(IDS_WIZARD_FONT));

	SendDlgItemMessage(IDC_HEADER, WM_SETFONT, (WPARAM)(HFONT)m_fntBold);
	SendDlgItemMessage(IDC_URL, WM_SETFONT, (WPARAM)(HFONT)m_fntUnderline);
	SendDlgItemMessage(IDC_HEADER, WM_SETFONT, (WPARAM)(HFONT)m_fntHeader);

	m_hWndUrl = GetDlgItem(IDC_URL);

	OSVERSIONINFO osvi;
	osvi.dwOSVersionInfoSize = sizeof(osvi);

	_VERIFY(GetVersionEx(&osvi));

	if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT &&
		osvi.dwMajorVersion >= 5 ||
		osvi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS &&
		(osvi.dwMajorVersion >= 5 ||
		 osvi.dwMajorVersion == 4 && osvi.dwMinorVersion > 10))
	{
		m_hCursor = LoadCursor(NULL, IDC_HAND);
	}
	else
	{
		m_hCursor = AtlLoadCursor(IDR_HAND);
	}

	m_bmpBack.LoadBitmap(IDB_WELCOME);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnSetCursor
//
//  Handles WM_SETCURSOR message. Changes mouse cursor when it is above the
//	URL static control
//
//  Parameters:
//    hWnd     - window handle
//    wHitTest - hit-test code
//    uMsg     - mouse message code
//
//  Returns:
//	  TRUE, if the cursor was set, FALSE - otherwise.
//
BOOL
CAboutDlg::OnSetCursor(
	HWND hWnd,
	UINT wHitTest,
	UINT uMsg
    )
{
	_UNUSED(wHitTest);
    _UNUSED(uMsg);

	if (m_hWndUrl == hWnd)
	{
		SetCursor(m_hCursor);
		return TRUE;
	}

	SetMsgHandled(FALSE);
	return FALSE;
}
