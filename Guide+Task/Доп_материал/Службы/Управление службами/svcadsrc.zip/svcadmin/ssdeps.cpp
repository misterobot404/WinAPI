// ssdeps.cpp
//
// Start/stop dependencies dialog.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "ssdeps.h"
#include "mainwnd.h"
#include "svcobj.h"

//---------------------------------------------------------------------------
// GetAffectedList
//
//  Returns a null-separated list of services would be affected by the start
//  or stop operation. This function should be called before invoking the
//	actual dialog UI.
//
//  Parameters:
//	  pService - service to start or stop
//	  bStop	   - operation indicator
//
//  Returns:
//	  pointer to the list of affected services; this pointer is valid as
//	  long as the CStartStopDlg object exists.
//
PCTSTR
CStartStopDlg::GetAffectedList(
	CService * pService, 
	BOOL bStop
	)
{
	_ASSERTE(pService != NULL);
	_ASSERTE(m_pszList == NULL);

	m_bStop = bStop;

	// allocate initial chunk of memory for the list
	m_pszList = (PTSTR)malloc(256);
	if (m_pszList == NULL)
		return NULL;

	m_cchList = 256 / sizeof(TCHAR);
	m_pszList[m_iEnd = 0] = 0;

	if (bStop)
		GetStopServices(pService->m_szName);
	else
		GetStartServices(pService->m_szName);

	return m_pszList;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CStartStopDlg::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	SC_HANDLE hSCM =  m_pMainWnd->m_hSCM;
	_ASSERTE(hSCM != NULL);

	// initialize list view control
	CListViewCtrl wndList = GetDlgItem(IDC_LIST);
	wndList.SetImageList(m_pMainWnd->GetImageList(), LVSIL_SMALL);

	// insert a column into the list view
	wndList.InsertColumn(0, &_chNil, LVCFMT_LEFT, 0, 0);

	TCHAR szDisplayName[256];
	DWORD cchName;

	PCTSTR psz = m_pszList;
	PCTSTR qsz = psz + lstrlen(psz) + 1;

	LVITEM lvi;
	lvi.mask = LVIF_TEXT;
	lvi.iItem = 0;
	lvi.iSubItem = 0;
	lvi.pszText = szDisplayName;

	// insert all services except the last one into the list
	while (*qsz != 0)
	{
		cchName = countof(szDisplayName);
		GetServiceDisplayName(hSCM, psz, szDisplayName, &cchName);

		wndList.InsertItem(&lvi);

		psz = qsz;
		qsz += lstrlen(qsz) + 1;
	}

	// resize the column
	wndList.SetColumnWidth(0, LVSCW_AUTOSIZE);

	cchName = countof(szDisplayName);
	GetServiceDisplayName(hSCM, psz, szDisplayName, &cchName);

	TCHAR szTitle[80];
	UINT nTitle = m_bStop ? IDS_STOP_OTHER_TITLE : IDS_START_OTHER_TITLE;
	UINT nHeader = m_bStop ? IDS_STOP_OTHER_HEADER : IDS_START_OTHER_HEADER;
	UINT nPrompt = m_bStop ? IDS_STOP_OTHER_PROMPT : IDS_START_OTHER_PROMPT;

	AtlLoadString(nTitle, szTitle, countof(szTitle));
	SetWindowText(szTitle);

	FormatDlgItem(m_hWnd, IDC_HEADER, MAKEINTRESOURCE(nHeader), 
				  szDisplayName);
	FormatDlgItem(m_hWnd, IDC_PROMPT, MAKEINTRESOURCE(nPrompt));
	
	return TRUE;
}

//---------------------------------------------------------------------------
// GetStartServices
//
//  Appends to the list names of services have to be started if the specified
//  service needs to be started.
//
//  Parameters:
//    pszName - name of the service
//
//  Returns:
//	  no return value.
//
void
CStartStopDlg::GetStartServices(
	PCTSTR pszName
	)
{
	_ASSERTE(pszName != NULL);

	SC_HANDLE hService;
	SERVICE_STATUS ServiceStatus;
	LPQUERY_SERVICE_CONFIG pConfig;
	DWORD cbNeeded;

	// open service handle
	hService = OpenService(m_pMainWnd->m_hSCM, pszName,
						   SERVICE_QUERY_CONFIG|SERVICE_QUERY_STATUS);
	if (hService == NULL)
		return;

	// query current service state
	if (!QueryServiceStatus(hService, &ServiceStatus) ||
		ServiceStatus.dwCurrentState == SERVICE_RUNNING)
	{
		_VERIFY(CloseServiceHandle(hService));
		return;
	}

	// query list of dependent services
	if (!QueryServiceConfig(hService, NULL, 0, &cbNeeded))
	{
		if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
			_VERIFY(CloseServiceHandle(hService));
			return;
		}
	}

	// allocate memory for the config data
	pConfig = (LPQUERY_SERVICE_CONFIG)_alloca(cbNeeded);
	_ASSERTE(pConfig != NULL);

	if (!QueryServiceConfig(hService, pConfig, cbNeeded, &cbNeeded))
	{
		_VERIFY(CloseServiceHandle(hService));
		return;
	}

	_VERIFY(CloseServiceHandle(hService));

	// for each dependency perform the same procedure
	if (pConfig->lpDependencies != NULL)
	{
		PTSTR psz = pConfig->lpDependencies;
		while (*psz != 0)
		{
			GetStartServices(psz);
			psz += lstrlen(psz) + 1;
		}
	}

	// append the name of this service after all services we depend on
	// has been enumerated; this will ensure that those services will be
	// started first
	AppendName(pszName);
}

//---------------------------------------------------------------------------
// GetStopServices
//
//  Appends to the list names of services have to be stopped if the specified
//  service needs to be stopped.
//
//  Parameters:
//    pszName - name of the service
//
//  Returns:
//	  no return value.
//
void
CStartStopDlg::GetStopServices(
	PCTSTR pszName
	)
{
	_ASSERTE(pszName != NULL);

	SC_HANDLE hService;
	LPENUM_SERVICE_STATUS pStatus;
	DWORD cbNeeded;
	DWORD cServices;

	// open service handle
	hService = OpenService(m_pMainWnd->m_hSCM, pszName,
						   SERVICE_ENUMERATE_DEPENDENTS);
	if (hService == NULL)
		return;

	// enumerate active dependent services
	if (!EnumDependentServices(hService, SERVICE_ACTIVE, NULL, 0, 
							   &cbNeeded, &cServices))
	{
		if (GetLastError() != ERROR_MORE_DATA)
		{
			_VERIFY(CloseServiceHandle(hService));
			return;
		}
	}

	pStatus = (LPENUM_SERVICE_STATUS)_alloca(cbNeeded);
	_ASSERTE(pStatus != NULL);

	if (!EnumDependentServices(hService, SERVICE_ACTIVE, pStatus, cbNeeded,
							   &cbNeeded, &cServices))
	{
		_VERIFY(CloseServiceHandle(hService));
		return;
	}

	_VERIFY(CloseServiceHandle(hService));
	
	// for each dependent service perform the same procedure
	for (DWORD i = 0; i < cServices; i++)
		GetStopServices(pStatus[i].lpServiceName);

	// append the name of this service after all dependent services
	// has been enumerated; this will ensure that those services will be
	// stopped first
	AppendName(pszName);
}

//---------------------------------------------------------------------------
// AppendName
//
//  Appends a name to the list.
//
//  Parameters:
//	  pszName - name to append
//
//  Returns:
//	  no return value.
//
void
CStartStopDlg::AppendName(
	PCTSTR pszName
	)
{
	_ASSERTE(pszName != NULL);

	UINT cch = lstrlen(pszName) + 2;

	if (m_cchList - m_iEnd < cch)
	{
		UINT cbNew = m_cchList * sizeof(TCHAR) + 256;

		PTSTR psz = (PTSTR)realloc(m_pszList, cbNew);
		if (psz == NULL)
			return;

		m_pszList = psz;
		m_cchList = cbNew / sizeof(TCHAR);
	}

	lstrcpy(m_pszList + m_iEnd, pszName);
	m_iEnd += cch - 1;

	m_pszList[m_iEnd] = 0;
}
