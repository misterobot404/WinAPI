// svcadmin.h
//
// Global declarations.
//
// $Id: $
//

#ifndef __svcadmin_h_included
#define __svcadmin_h_included

EXTERN_C extern OSVERSIONINFO _osvi;
EXTERN_C extern const TCHAR	  _szLocalSystem[];
EXTERN_C extern const TCHAR	  _szLocalService[];
EXTERN_C extern const TCHAR	  _szNetworkService[];
EXTERN_C extern const TCHAR	  _chNil;

EXTERN_C
extern
BOOL 
(APIENTRY * 
 _QueryServiceConfig2)(
	IN SC_HANDLE hService, 
	IN DWORD dwInfoLevel,
	OUT PBYTE pBuffer, 
	IN DWORD cbBuffer,
	OUT LPDWORD pcbNeeded
	);

EXTERN_C
extern
BOOL
(APIENTRY *
 _ChangeServiceConfig2)(
	IN SC_HANDLE hService,
	IN DWORD dwInfoLevel,
	IN PVOID pInfo
	);

EXTERN_C
BOOL
APIENTRY
LoadFilterString(
	IN UINT nStringId,
	OUT PTSTR pString,
	IN UINT cchMax
	);

EXTERN_C
BOOL
APIENTRY
FormatTimeInterval(
	IN DWORD dwInterval,
	OUT PTSTR pString,
	IN UINT cchMax
	);

EXTERN_C
BOOL
APIENTRY
ParseTimeInterval(
	IN PCTSTR pString,
	OUT DWORD * pdwInterval
	);

EXTERN_C
BOOL
APIENTRY
AdjustPrivilege(
	IN PCTSTR pszPrivilegeName,
	IN BOOL bEnable,
	IN BOOL bProcess,
	OUT PBOOL pbPreviousState
	);

EXTERN_C
BOOL
APIENTRY
IsPrivilege(
	IN PCTSTR pszPrivilegeName
	);

EXTERN_C
HRESULT
APIENTRY
GrantPrivilege(
	IN PCTSTR pszMachineName,
	IN PCTSTR pszUserName,
	IN PCTSTR pszPrivilegeName
	);

EXTERN_C
BOOL
APIENTRY
EnableDlgItem(
	IN HWND hWnd,
	IN UINT nCtrlId,
	IN BOOL bEnable
	);

EXTERN_C
BOOL
APIENTRY
ShowDlgItem(
	IN HWND hWnd,
	IN UINT nCtrlId,
	IN INT nCmdShow
	);

EXTERN_C
VOID 
CDECL
FormatDlgItem(
    IN HWND hWnd, 
    IN UINT nCtrlID, 
    IN PCTSTR pszFormat, 
    IN ...
    );

EXTERN_C
int 
__cdecl 
FormatString(
    LPTSTR pszBuffer, 
    UINT cchMax, 
    LPCTSTR pszFormat, 
    ...
    );

EXTERN_C
BOOL
APIENTRY
FillLoadOrderGroupCombo(
	IN HWND hWnd,
	IN PCTSTR pszMachine
	);

EXTERN_C
int
APIENTRY
BrowseForUser(
	IN HWND hWnd,
	IN PCTSTR pszMachine,
	OUT PTSTR pszUser,
	IN UINT cchUser
	);

EXTERN_C
HFONT
APIENTRY
CreateLocalFont(
	IN PCTSTR pszFont
	);

// from NTDDK
#define STATUS_OBJECT_NAME_NOT_FOUND     ((NTSTATUS)0xC0000034L)

#ifndef _ATL_MIN_CRT
#	define _itot10(a, b)	_itot(a, b, 10)
#else
	EXTERN_C void __fastcall _itot10(int i, _TCHAR * str);
#endif

#endif