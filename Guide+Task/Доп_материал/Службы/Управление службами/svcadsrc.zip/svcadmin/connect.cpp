// connect.cpp
//
// Connection dialog.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "connect.h"
#include "errorbox.h"

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Creates bold and underlined version of
//  the standard dialog font and assign them to the static controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CConnectDlg::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	EnableDlgItem(IDC_USERNAME, FALSE);
	EnableDlgItem(IDC_PASSWORD, FALSE);
	EnableDlgItem(IDOK, FALSE);

	SendDlgItemMessage(IDC_MACHINE, EM_LIMITTEXT, UNCLEN);
	SendDlgItemMessage(IDC_USERNAME, EM_LIMITTEXT, UNLEN);
	SendDlgItemMessage(IDC_PASSWORD, EM_LIMITTEXT, PWLEN);

	return TRUE;
}

//---------------------------------------------------------------------------
// OnOK
//
//  Handles OK button.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  no return value.
//
void
CConnectDlg::OnOK()
{
	GetDlgItemText(IDC_MACHINE, m_szMachine + 2, countof(m_szMachine) - 2);
	GetDlgItemText(IDC_USERNAME, m_szUserName, countof(m_szUserName));
	GetDlgItemText(IDC_PASSWORD, m_szPassword, countof(m_szPassword));

	m_bAltAuth = IsDlgButtonChecked(IDC_ALTERNATE);

	if (m_szMachine[2] == _T('\\'))
	{
		memmove(m_szMachine, m_szMachine + 2, 
				sizeof(m_szMachine) - 2 * sizeof(TCHAR));
	}
	else
	{
		m_szMachine[0] = _T('\\');
		m_szMachine[1] = _T('\\');
	}

	EndDialog(IDOK);
}

//---------------------------------------------------------------------------
// OnBrowse
//
//  Handles Browse button.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  no return value.
//
void
CConnectDlg::OnBrowse()
{
	CComPtr<IMalloc> spMalloc;
	HRESULT hRes;

	TCHAR szComputer[260];
	
	hRes = SHGetMalloc(&spMalloc);
	if (SUCCEEDED(hRes))	
	{
		LPITEMIDLIST pidl, pidlRoot;
		BROWSEINFO bi;
		TCHAR szTitle[256];

		hRes = SHGetSpecialFolderLocation(m_hWnd, CSIDL_NETWORK, &pidlRoot);
		if (SUCCEEDED(hRes))
		{
			AtlLoadString(IDS_CONNECT_TITLE, szTitle, countof(szTitle));

			memset(&bi, 0, sizeof(bi));

			bi.hwndOwner = m_hWnd;
			bi.lpszTitle = szTitle;
			bi.ulFlags = BIF_BROWSEFORCOMPUTER;
			bi.pidlRoot = pidlRoot;
			bi.pszDisplayName = szComputer + 2;

			pidl = SHBrowseForFolder(&bi);

			spMalloc->Free(pidlRoot);
			if (pidl != NULL)
				spMalloc->Free(pidl);

			if (pidl == NULL)
				return;
		}
	}

	if (FAILED(hRes))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_NETWORK_DIALOG_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), hRes);
		return;
	}

	PCTSTR pszMachine = szComputer + 2;
	if (szComputer[2] != _T('\\'))
	{
		szComputer[0] = _T('\\');
		szComputer[1] = _T('\\');
		pszMachine = szComputer;
	}

	SetDlgItemText(IDC_MACHINE, pszMachine);
}

//---------------------------------------------------------------------------
// OnAlternate_Clicked
//
//  Handles "Use alternate credentials" check box.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  no return value.
//  
void
CConnectDlg::OnAlternate_Clicked()
{
	BOOL bAltAuth = IsDlgButtonChecked(IDC_ALTERNATE);

	EnableDlgItem(IDC_USERNAME, bAltAuth);
	EnableDlgItem(IDC_PASSWORD, bAltAuth);

	OnUserName_Change();
}

//---------------------------------------------------------------------------
// OnMachine_Change
//
//  Handles EN_CHANGE notification from the Machine edit box. Enables and
//	disables OK button appropriately.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  no return value.
//
void
CConnectDlg::OnMachine_Change()
{
	BOOL bOk = CWindow(GetDlgItem(IDC_MACHINE)).GetWindowTextLength() > 0;

	if (bOk && IsDlgButtonChecked(IDC_ALTERNATE))
		bOk = CWindow(GetDlgItem(IDC_USERNAME)).GetWindowTextLength() > 0;

	EnableDlgItem(IDOK,  bOk);
}

//---------------------------------------------------------------------------
// OnUserName_Change
//
//  Handles EN_CHANGE notification from the User Name edit box. Enables and
//	disables OK button appropriately.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  no return value.
//
void
CConnectDlg::OnUserName_Change()
{
	BOOL bOk = CWindow(GetDlgItem(IDC_MACHINE)).GetWindowTextLength() > 0;

	if (bOk && IsDlgButtonChecked(IDC_ALTERNATE))
		bOk = CWindow(GetDlgItem(IDC_USERNAME)).GetWindowTextLength() > 0;

	EnableDlgItem(IDOK,  bOk);
}
