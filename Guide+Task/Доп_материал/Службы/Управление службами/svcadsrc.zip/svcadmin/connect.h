// connect.h
//
// Connection dialog.
//
// $Id: $
//

#ifndef __connect_h_included
#define __connect_h_included

class CConnectDlg :
	public CDialogImpl<CConnectDlg>
{
  public:

	~CConnectDlg()
		{ memset(m_szPassword, 0, sizeof(m_szPassword)); }

	PCTSTR GetMachineName()
		{ return m_szMachine; }

	PCTSTR GetUserName()
		{ return m_bAltAuth ? m_szUserName : NULL; }

	PCTSTR GetPassword()
		{ return m_bAltAuth ? m_szPassword : NULL; }

  public:

	enum { IDD = IDD_CONNECT };

	BEGIN_MSG_MAP_EX(CConnectDlg)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDOK, BN_CLICKED,  OnOK)
		CMD_SIMPLE(IDCANCEL, BN_CLICKED, OnCancel)
		CMD_SIMPLE(IDC_BROWSE, BN_CLICKED, OnBrowse)
		CMD_SIMPLE(IDC_ALTERNATE, BN_CLICKED, OnAlternate_Clicked)
		CMD_SIMPLE(IDC_MACHINE, EN_CHANGE, OnMachine_Change)
		CMD_SIMPLE(IDC_USERNAME, EN_CHANGE, OnUserName_Change)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// control handlers
	void OnOK();
	void OnBrowse();
	void OnAlternate_Clicked();
	void OnMachine_Change();
	void OnUserName_Change();

	void OnCancel()
		{ EndDialog(IDCANCEL); }

  protected:

	TCHAR	m_szMachine[UNCLEN + 1];			// computer name
	TCHAR	m_szUserName[UNLEN + 1];		// user name
	TCHAR	m_szPassword[PWLEN + 1];		// password
	BOOL	m_bAltAuth;

  protected:

	BOOL EnableDlgItem(UINT nCtrlId, BOOL bEnable)
		{ return ::EnableDlgItem(m_hWnd, nCtrlId, bEnable);	}

};

#endif // __connect_h_included
