// svcadmin.cpp
//
// Entry point and utility functions.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "mainwnd.h"

#include <delayimp.h>

#pragma comment(lib, "acledit.lib")
#pragma comment(lib, "aclui.lib")
#pragma comment(lib, "netapi32.lib")
#pragma comment(lib, "mpr.lib")

#if _MSC_VER < 1300
#	pragma comment(lib, "delayimp.lib")
#	pragma comment(linker, "/delayload:shell32.dll")
#	pragma comment(linker, "/delayload:comdlg32.dll")
#	pragma comment(linker, "/delayload:oleaut32.dll")
#	pragma comment(linker, "/delayload:acledit.dll")
#	pragma comment(linker, "/delayload:aclui.dll")
#	pragma comment(linker, "/delayload:netapi32.dll")
#	pragma comment(linker, "/delayload:mpr.dll")
#endif

CAppModule		_Module;
OSVERSIONINFO	_osvi;
const TCHAR	    _chNil = 0;
const WCHAR		_szHexDigits[] = L"0123456789abcdef";
const TCHAR		_szLocalSystem[] = _T("LocalSystem");
const TCHAR		_szLocalService[] = _T("NT AUTHORITY\\LocalService");
const TCHAR		_szNetworkService[] = _T("NT AUTHORITY\\NetworkService");
const TCHAR		_szGroupOrder[] = _T("System\\CurrentControlSet\\Control")
								  _T("\\ServiceGroupOrder");

BOOL 
(APIENTRY * 
 _QueryServiceConfig2)(
	IN SC_HANDLE hService, 
	IN DWORD dwInfoLevel,
	OUT PBYTE pBuffer, 
	IN DWORD cbBuffer,
	OUT LPDWORD pcbNeeded
	);

BOOL
(APIENTRY *
 _ChangeServiceConfig2)(
	IN SC_HANDLE hService,
	IN DWORD dwInfoLevel,
	IN PVOID pInfo
	);


//---------------------------------------------------------------------------
// WinMain
//
//  Program entry point.
//
//  Parameters:
//    hInstance     - instance handle
//    hPrevInstance - previous instance handle
//    pszCmdLine    - command line
//    nShowCmd	    - show command
//
//  Returns:
//    the return value is the exit code of the process.
//
EXTERN_C
int
WINAPI
_tWinMain(
    IN HINSTANCE hInstance,
    IN HINSTANCE hPrevInstance,
    IN PTSTR pszCmdLine,
    IN int nShowCmd
    )
{
    _UNUSED(hPrevInstance);
	_UNUSED(pszCmdLine);

	_osvi.dwOSVersionInfoSize = sizeof(_osvi);

	// determine operating system version
	_VERIFY(GetVersionEx(&_osvi));

	if (_osvi.dwPlatformId != VER_PLATFORM_WIN32_NT)
	{
		CHAR szTitle[80];
		CHAR szMessage[256];

		_VERIFY(LoadStringA(hInstance, IDS_MESSAGE_TITLE,
							szTitle, countof(szTitle)));
		_VERIFY(LoadStringA(hInstance, IDS_OS_VERSION_MISMATCH,
							szMessage, countof(szMessage)));

		MessageBoxA(NULL, szMessage, szTitle, MB_OK|MB_ICONSTOP);
		return 0;
	}

    HRESULT hRes = CoInitialize(NULL);
    _ASSERTE(SUCCEEDED(hRes));
	_UNUSED(hRes);

    _Module.Init(NULL, hInstance);
    InitCommonControls();

	if (_osvi.dwMajorVersion >= 5)
	{
		// locate Win2K-specific functions
		HINSTANCE hAdvApi;

		hAdvApi = GetModuleHandle(_T("advapi32.dll"));
		_ASSERTE(hAdvApi != NULL);

#ifndef _UNICODE
		*(FARPROC *)&_QueryServiceConfig2 =
			GetProcAddress(hAdvApi, "QueryServiceConfig2A");
		*(FARPROC *)&_ChangeServiceConfig2 =
			GetProcAddress(hAdvApi, "ChangeServiceConfig2A");
#else
		*(FARPROC *)&_QueryServiceConfig2 =
			GetProcAddress(hAdvApi, "QueryServiceConfig2W");
		*(FARPROC *)&_ChangeServiceConfig2 =
			GetProcAddress(hAdvApi, "ChangeServiceConfig2W");
#endif
		
		_ASSERTE(_QueryServiceConfig2 != NULL);
		_ASSERTE(_ChangeServiceConfig2 != NULL);
	}

	{
		CMainWnd wndMain;

		CMessageLoop theLoop;
		_Module.AddMessageLoop(&theLoop);

		if (wndMain.CreateEx(NULL, CWindow::rcDefault) != NULL)
		{
			wndMain.RestoreWindowPos(nShowCmd);
			theLoop.Run();
		}
	}

	_Module.RemoveMessageLoop();
    _Module.Term();

    CoUninitialize();

	_CrtDumpMemoryLeaks();
    return 0;
}

//---------------------------------------------------------------------------
// LoadFilterString
//
//  Loads string to be used as filter in File Open or File Save As dialog.
//
//  Parameters:
//	  nStringId - string identifier
//	  pString	- pointer to a buffer that receives the string
//	  cchMax	- size of the buffer in characters
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
EXTERN_C
BOOL
APIENTRY
LoadFilterString(
	IN UINT nStringId,
	OUT PTSTR pString,
	IN UINT cchMax
	)
{
	_ASSERTE(nStringId != 0);
	_ASSERTE(_CrtIsValidPointer(pString, cchMax * sizeof(TCHAR), 1));

	if (!AtlLoadString(nStringId, pString, cchMax))
		return FALSE;

	while (*pString != 0)
	{
		if (*pString == _T('|'))
			*pString = 0;
		pString++;
	}

	return 0;
}

//---------------------------------------------------------------------------
// FormatTimeInterval
//
//  Formats the specified time interval.
//
//  Parameters:
//	  dwInterval - time interval in seconds
//	  pString	 - pointer to a buffer that receives formatted string
//	  cchMax     - size of the buffer in characters
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
EXTERN_C
BOOL
APIENTRY
FormatTimeInterval(
	IN DWORD dwInterval,
	OUT PTSTR pString,
	IN UINT cchMax
	)
{
	_ASSERTE(_CrtIsValidPointer(pString, cchMax * sizeof(TCHAR), 1));	

	UINT cHours = dwInterval / 3600;	dwInterval %= 3600;
	UINT cMinutes = dwInterval / 60;	dwInterval %= 60;
	UINT cSeconds = dwInterval;

	TCHAR szHours[40], szMinutes[40], szSeconds[40];
	_VERIFY(AtlLoadString(IDS_HOURS, szHours, countof(szHours)));
	_VERIFY(AtlLoadString(IDS_MINUTES, szMinutes, countof(szMinutes)));
	_VERIFY(AtlLoadString(IDS_SECONDS, szSeconds, countof(szSeconds)));

	PTSTR rgParams[6];
	rgParams[0] = (PTSTR)cHours;
	rgParams[1] = szHours;
	rgParams[2] = (PTSTR)cMinutes;
	rgParams[3] = szMinutes;
	rgParams[4] = (PTSTR)cSeconds;
	rgParams[5] = szSeconds;

	PCTSTR pszPattern = NULL;

	if (cHours != 0)
	{
		if (cMinutes != 0)
		{
			if (cSeconds != 0)
				pszPattern = _T("%1!d! %2 %3!02d! %4 %5!02d! %6");
			else
				pszPattern = _T("%1!d! %2 %3!02d! %4");
		}
		else
		{
			if (cSeconds != 0)
				pszPattern = _T("%1!d! %2 %3!02d! %4 %5!02d! %6");
			else
				pszPattern = _T("%1!d! %2");
		}
	}
	else
	{
		if (cMinutes != 0)
		{
			if (cSeconds != 0)
				pszPattern = _T("%3!d! %4 %5!02d! %6");
			else
				pszPattern = _T("%3!d! %4");
		}
		else
			pszPattern = _T("%5!d! %6");
	}

	_ASSERTE(pszPattern != NULL);

	return FormatMessage(FORMAT_MESSAGE_FROM_STRING|
						 FORMAT_MESSAGE_ARGUMENT_ARRAY,
						 pszPattern, 0, 0, pString, cchMax,
						 (va_list *)rgParams);
}

//---------------------------------------------------------------------------
// GetTimePair
//
//  Retrieves a value-unit pair from the string.
//
//  Parameters:
//	  pString  - pointer to the current position in the string.
//	  wType	   - pointer to the character type array
//	  pnPos	   - pointer to a variable that holds the position in the
//				 character type array
//	  pdwValue - pointer to a variable that receives the value
//	  pszUnit  - pointer to a buffer that receives the unit name
//	  cchUnit  - size of the unit buffer in characters
//
//  Returns:
//	  NULL if failed, or starting position of the next token in the string
//	  if succeeded.
//
static
PCTSTR
APIENTRY
GetTimePair(
	IN PCTSTR pString,
	IN CONST WORD * wType,
	IN OUT PINT pnPos,
	OUT PDWORD pdwItem, 
	OUT PTSTR pszUnit,
	UINT cchUnit
	)
{
	_ASSERTE(pString != NULL);
	_ASSERTE(wType != NULL);
	_ASSERTE(_CrtIsValidPointer(pnPos, sizeof(INT), 1));
	_ASSERTE(_CrtIsValidPointer(pdwItem, sizeof(DWORD), 1));
	_ASSERTE(_CrtIsValidPointer(pszUnit, cchUnit * sizeof(TCHAR), 1));

	int nPos = *pnPos;
	_ASSERTE((wType[nPos] & C1_SPACE) == 0);

	TCHAR szNumber[10];
	int cch = 0;

	while (*pString != 0 && cch < countof(szNumber) - 1)
	{
		if ((wType[nPos] & C1_DIGIT) == 0)
			break;

		szNumber[cch] = *pString;

		cch++;
		nPos++;
		pString = CharNext(pString);
	}

	if (cch == 0 || *pString == 0 || (wType[nPos] & C1_DIGIT) != 0)
		return NULL;

	szNumber[cch] = 0;

	USES_CONVERSION;
	if (FAILED(VarI4FromStr(T2OLE(szNumber), 0, 0, (PLONG)pdwItem)))
		return NULL;

	// skip whitespace
	while (*pString != 0)
	{
		if ((wType[nPos] & C1_SPACE) == 0)
			break;

		pString = CharNext(pString);
		nPos++;
	}
	if (*pString == 0)
		return NULL;

	PCTSTR pStart = pString;
	while (*pString != 0)
	{
		if ((wType[nPos] & C1_SPACE) != 0)
			break;

		nPos++;
		pString = CharNext(pString);
	}

	lstrcpyn(pszUnit, pStart, min(pString - pStart + 1, (int)cchUnit));

	// skip whitespace
	while (*pString != 0)
	{
		if ((wType[nPos] & C1_SPACE) == 0)
			break;

		pString = CharNext(pString);
		nPos++;
	}

	*pnPos = nPos;
	return pString;
}

//---------------------------------------------------------------------------
// ParseTimeInterval
//
//  Parses the time interval.
//
//  Parameters:
//	  pString     - pointer to the string containing the time interval
//	  pdwInterval - pointer to a variable that receives the number of
//				    seconds in the interval
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
EXTERN_C
BOOL
APIENTRY
ParseTimeInterval(
	IN PCTSTR pString,
	OUT DWORD * pdwInterval
	)
{
	_ASSERTE(pString != NULL);
	_ASSERTE(lstrlen(pString) < 256);
	_ASSERTE(_CrtIsValidPointer(pdwInterval, sizeof(DWORD), 1));

	*pdwInterval = 0;

	struct {
		TCHAR szUnit[40];
		UINT  cchUnit;
		DWORD dwScale;
		DWORD dwMax;
	} Units[3];

	// hours unit description
	Units[0].cchUnit = AtlLoadString(IDS_HOURS, Units[0].szUnit, 
									 countof(Units[0].szUnit));
	Units[0].dwScale = 3600;
	Units[0].dwMax = UINT_MAX;

	// minutes unit description
	Units[1].cchUnit = AtlLoadString(IDS_MINUTES, Units[1].szUnit,
									 countof(Units[1].szUnit));
	Units[1].dwScale = 60;
	Units[1].dwMax = 60;

	// seconds unit description
	Units[2].cchUnit = AtlLoadString(IDS_SECONDS, Units[2].szUnit,
									 countof(Units[2].szUnit));
	Units[2].dwScale = 1;
	Units[2].dwMax = 60;

	struct {
		TCHAR szUnit[40];
		DWORD dwValue;
	} Values[3];

	WORD wType[256];
	int nPos = 0;

	// get character type information
	if (!GetStringTypeEx(LOCALE_USER_DEFAULT, CT_CTYPE1, pString, -1, wType))
		return FALSE;

	// skip whitespace
	while (*pString != 0)
	{
		if ((wType[nPos] & C1_SPACE) == 0)
			break;

		pString = CharNext(pString);
		nPos++;
	}
	if (*pString == 0)
		return FALSE;

	// split the string into up to three value-unit pairs
	for (UINT cValues = 0; cValues < 3; cValues++)
	{
		pString = GetTimePair(pString, wType, &nPos, 
							  &Values[cValues].dwValue, 
							  Values[cValues].szUnit, 
							  countof(Values[cValues].szUnit));
		if (pString == NULL)
			return FALSE;
		if (*pString == 0)
			break;
	}
	if (cValues == 3)
		return FALSE;

	UINT nUnit = 0;
	DWORD dwInterval = 0;

	for (UINT i = 0; i <= cValues; i++)
	{
		// find the matching unit
		for (UINT j = nUnit; j < 3; j++)
		{
			if (CompareString(LOCALE_USER_DEFAULT, NORM_IGNORECASE,
					Units[j].szUnit, Units[j].cchUnit, Values[i].szUnit, 
					Units[j].cchUnit) == CSTR_EQUAL)
				break;
		}
		if (j == 3)
			return FALSE;

		if (i > 0 && Values[i].dwValue >= Units[j].dwMax)
			return FALSE;

		dwInterval += Values[i].dwValue * Units[j].dwScale;
		nUnit = j + 1;
	}

	*pdwInterval = dwInterval;
	return TRUE;
}

//---------------------------------------------------------------------------
// AdjustPrivilege
//
//  Enables or disables the specified privilege.
//
//  Parameters:
//	  pszPrivilegeName - name of the privilege
//	  bEnable          - new privilege state
//	  bProcess		   - forces using of process token rather than imperso-
//						 nation token
//	  pbPreviousState  - pointer to a variable that receives previous
//					 	 privilege state; this parameter can be NULL
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
EXTERN_C
BOOL
APIENTRY
AdjustPrivilege(
	IN PCTSTR pszPrivilegeName,
	IN BOOL bEnable,
	IN BOOL bProcess,
	OUT PBOOL pbPreviousState
	)
{
	_ASSERTE(pszPrivilegeName != NULL);

	TOKEN_PRIVILEGES Priv, PrivOld;
	DWORD cbPriv = sizeof(PrivOld);
	HANDLE hToken = NULL;

	if (pbPreviousState != NULL)
		*pbPreviousState = FALSE;

	if (!bProcess)
	{
		// obtain the token of the current thread 
		if (!OpenThreadToken(GetCurrentThread(), 
							 TOKEN_QUERY|TOKEN_ADJUST_PRIVILEGES,
							 FALSE, &hToken))
			if (GetLastError() != ERROR_NO_TOKEN)
				return FALSE;
	}

	if (hToken == NULL)
	{
		// revert to the process token
		if (!OpenProcessToken(GetCurrentProcess(),
							  TOKEN_QUERY|TOKEN_ADJUST_PRIVILEGES,
							  &hToken))
			return FALSE;
	}

	_ASSERTE(ANYSIZE_ARRAY > 0);

	Priv.PrivilegeCount = 1;

	if (bEnable)
		Priv.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	else
		Priv.Privileges[0].Attributes = 0;

	LookupPrivilegeValue(NULL, pszPrivilegeName, &Priv.Privileges[0].Luid);

	// try to enable the privilege
	if (!AdjustTokenPrivileges(hToken, FALSE, &Priv, sizeof(Priv),
							   &PrivOld, &cbPriv))
	{
		DWORD dwError = GetLastError();
		CloseHandle(hToken);
		return SetLastError(dwError), FALSE;
	}

	if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)
	{
		// the privilege is not present in the caller's token
		CloseHandle(hToken);
		return SetLastError(ERROR_ACCESS_DENIED), FALSE;
	}

	if (pbPreviousState != NULL)
	{
		*pbPreviousState = 
			(PrivOld.Privileges[0].Attributes & SE_PRIVILEGE_ENABLED) != 0;
	}

	return TRUE;
}

//---------------------------------------------------------------------------
// IsPrivilege
//
//  Checks if the privilege is present in the caller's token.
//
//  Parameters:
//	  pszPrivilegeName - name of the privilege
//
//  Returns:
//	  TRUE, if the privilege is present, FALSE - if it isn't, or if an
//	  error has occured.
//
EXTERN_C
BOOL
APIENTRY
IsPrivilege(
	IN PCTSTR pszPrivilegeName
	)
{
	_ASSERTE(pszPrivilegeName != NULL);

	LUID Luid;
	_VERIFY(LookupPrivilegeValue(NULL, pszPrivilegeName, &Luid));

	HANDLE hToken;
	DWORD cbNeeded;
	PTOKEN_PRIVILEGES pPriv;

	// obtain the token of the current thread 
	if (!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY, FALSE, &hToken))
	{
		if (GetLastError() != ERROR_NO_TOKEN)
			return FALSE;

		// revert to the process token
		if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
			return FALSE;
	}

	// determine size of the buffer required to receive all privileges
	if (!GetTokenInformation(hToken, TokenPrivileges, NULL, 0, &cbNeeded))
	{
		if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
			DWORD dwError = GetLastError();
			_VERIFY(CloseHandle(hToken));
			return SetLastError(dwError), FALSE;
		}
	}

	// allocate privileges buffer
	pPriv = (PTOKEN_PRIVILEGES)_alloca(cbNeeded);
	_ASSERTE(pPriv != NULL);

	// retrieve token privileges
	if (!GetTokenInformation(hToken, TokenPrivileges, pPriv, cbNeeded,
							 &cbNeeded))
	{
		DWORD dwError = GetLastError();
		_VERIFY(CloseHandle(hToken));
		return SetLastError(dwError), FALSE;
	}

	_VERIFY(CloseHandle(hToken));

	// walk through all privileges and check if the specified privilege
	// is present in the caller's token
	for (UINT i = 0; i < pPriv->PrivilegeCount; i++)
	{
		if (pPriv->Privileges[i].Luid.LowPart == Luid.LowPart &&
			pPriv->Privileges[i].Luid.HighPart == Luid.HighPart)
			return TRUE;
	}

	SetLastError(ERROR_SUCCESS);
	return FALSE;
}

//---------------------------------------------------------------------------
// GrantPrivilege
//
//  Grants the specified privilege to the specified user account.
//
//  Parameters:
//	  pszMachineName   - name of the target machine
//	  pszUserName	   - user name
//	  pszPrivilegeName - name of the privilege
//
//  Returns:
//	  * S_OK, if the privilege was granted;
//	  * S_FALSE, if the privilege already granted to the user;
//	  * any standard COM error code in the case of error.
//
EXTERN_C
HRESULT
APIENTRY
GrantPrivilege(
	IN PCTSTR pszMachineName,
	IN PCTSTR pszUserName,
	IN PCTSTR pszPrivilegeName
	)
{
	_ASSERTE(pszUserName != NULL);
	_ASSERTE(pszPrivilegeName != NULL);

	if (pszUserName[0] == _T('.') &&
		pszUserName[1] == _T('\\'))
		pszUserName += 2;

    BYTE bSid[8 + 4 * SID_MAX_SUB_AUTHORITIES];
    DWORD cbSid = sizeof(bSid);
	TCHAR szDomainName[DNLEN + 1];
	DWORD cchDomainName = countof(szDomainName);
	SID_NAME_USE Use;

	// lookup user account SID
	if (!LookupAccountName(pszMachineName, pszUserName, (PSID)bSid,
						   &cbSid, szDomainName, &cchDomainName, &Use))
		return HRESULT_FROM_WIN32(GetLastError());

	USES_CONVERSION;

	NTSTATUS Status;
	LSA_HANDLE hPolicy;
	LSA_UNICODE_STRING SystemName;
	LSA_UNICODE_STRING UserRight;
	PLSA_UNICODE_STRING pSystemName = NULL;
	PLSA_UNICODE_STRING pCurrentRights;
	LSA_OBJECT_ATTRIBUTES ObjAttr;
	ULONG cRights = 0;

	if (pszMachineName != NULL)
	{
		SystemName.Buffer = (PWSTR)W2CT(pszMachineName);
		SystemName.Length = (USHORT)(lstrlenW(SystemName.Buffer) * sizeof(WCHAR));
		SystemName.MaximumLength = (USHORT)(SystemName.Length + sizeof(WCHAR));

		pSystemName = &SystemName;
	}

	UserRight.Buffer = (PWSTR)W2CT(pszPrivilegeName);
	UserRight.Length = (USHORT)(lstrlenW(UserRight.Buffer) * sizeof(WCHAR));
	UserRight.MaximumLength = (USHORT)(UserRight.Length + sizeof(WCHAR));
	
	memset(&ObjAttr, 0, sizeof(ObjAttr));

	// open policy object
	Status = LsaOpenPolicy(pSystemName, &ObjAttr, 
						   POLICY_LOOKUP_NAMES|POLICY_CREATE_ACCOUNT,
						   &hPolicy);
	if (!LSA_SUCCESS(Status))
		return HRESULT_FROM_NT(Status);

	// detemine which rights the user currently has
	Status = LsaEnumerateAccountRights(hPolicy, (PSID)bSid, &pCurrentRights, 
									   &cRights);
	if (Status != STATUS_OBJECT_NAME_NOT_FOUND && !LSA_SUCCESS(Status))
	{
		LsaClose(hPolicy);
		return HRESULT_FROM_NT(Status);
	}

	// check if this right is already granted
	for (ULONG i = 0; i < cRights; i++)
	{
		if (UserRight.Length == pCurrentRights[i].Length &&
			memcmp(UserRight.Buffer, pCurrentRights[i].Buffer, 
				   UserRight.Length) == 0)
		{
			LsaFreeMemory(pCurrentRights);
			LsaClose(hPolicy);
			return S_FALSE;
		}
	}

	// add privilege to the account
	Status = LsaAddAccountRights(hPolicy, (PSID)bSid, &UserRight, 1);

	// close policy handle
	LsaFreeMemory(pCurrentRights);
	LsaClose(hPolicy);

	if (!LSA_SUCCESS(Status))
		return HRESULT_FROM_NT(Status);

	return S_OK;
}

//---------------------------------------------------------------------------
// EnableDlgItem
//
//  Enables or disables a dialog control.
//
//  Parameters:
//	  hWnd	  - dialog window identifier
//	  nCtrlId - control identifier
//	  bEnable - enable flag
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
EXTERN_C
BOOL
APIENTRY
EnableDlgItem(
	HWND hWnd,
	UINT nCtrlId,
	BOOL bEnable
	)
{
	_ASSERTE(IsWindow(hWnd));
	_ASSERTE(nCtrlId != 0);

	hWnd = GetDlgItem(hWnd, nCtrlId);
	if (hWnd != NULL)
	{
		EnableWindow(hWnd, bEnable);
		return TRUE;
	}

	return FALSE;
}

//---------------------------------------------------------------------------
// ShowDlgItem
//
//  Shows or hides the specified dialog control.
//
//  Parameters:
//	  hWnd     - dialog window handle
//	  nCtrlId  - control identifier
//	  nCmdShow - show command
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
EXTERN_C
BOOL
APIENTRY
ShowDlgItem(
	IN HWND hWnd,
	IN UINT nCtrlId,
	IN INT nCmdShow
	)
{
	_ASSERTE(IsWindow(hWnd));
	_ASSERTE(nCtrlId != 0);

	hWnd = GetDlgItem(hWnd, nCtrlId);
	if (hWnd != NULL)
	{
		ShowWindow(hWnd, nCmdShow);
		return TRUE;
	}

	return FALSE;
}

//---------------------------------------------------------------------------
// FormatDlgItem
//
//  Formats the dialog item text in according to the format string and
//  additional arguments.
//
//  Parameters:
//    hWnd      - dialog window identifier
//    nCtrlID   - control identifier
//    pszFormat - pointer to the format string or the identifier of the
//		  string in module resources
//    ...       - additional argiments
//
//  Returns:
//    no return value.
//
EXTERN_C
VOID 
CDECL
FormatDlgItem(
    HWND hWnd, 
    UINT nCtrlID, 
    PCTSTR pszFormat, 
    ...
    )
{
    _ASSERTE(IsWindow(hWnd));
    _ASSERTE(nCtrlID != 0);

    // load the format string if it is not specified
    TCHAR szFormat[256];
    if (pszFormat == NULL)
    {
		GetDlgItemText(hWnd, nCtrlID, szFormat, countof(szFormat));
		pszFormat = szFormat;
    }
    else if (HIWORD(pszFormat) == 0)
    {
		LoadString(_Module.GetResourceInstance(), LOWORD(pszFormat), 
				   szFormat, countof(szFormat));
		pszFormat = szFormat;
    }

    _ASSERTE(pszFormat != NULL);
    _ASSERTE(HIWORD(pszFormat) != 0);

    TCHAR szNewText[256];

    // format the new text of the control
    va_list va;
    va_start(va, pszFormat);

    FormatMessage(FORMAT_MESSAGE_FROM_STRING, pszFormat, 0, 0, 
		  szNewText, countof(szNewText), &va);

    va_end(va);

    // set the new text
    SetDlgItemText(hWnd, nCtrlID, szNewText);
}

//---------------------------------------------------------------------------
// FormatString
//
//  Formats the string with FormatMessage rules, using an explicitly speci-
//  fied string or a string in module resources as a source.
//
//  Parameters:
//    pszBuffer - pointer to a buffer that receives the formatted string
//    cchMax    - size of the buffer in bytes
//    pszFormat - pointer to the format string or the identifier of the
//		          string in module resources
//
//  Returns:
//    number of characters written into the output buffer not including the
//    terminating null character.
//
EXTERN_C
int 
__cdecl 
FormatString(
    LPTSTR pszBuffer, 
    UINT cchMax, 
    LPCTSTR pszFormat, 
    ...
    )
{
    // if a string identifier was specified, load the string from the
    // resources first
    TCHAR szFormat[1024];
    if (HIWORD(pszFormat) == 0)
    {
		AtlLoadString(LOWORD(pszFormat), szFormat, countof(szFormat));
		pszFormat = szFormat;
    }

    // format the string
    va_list va;
    va_start(va, pszFormat);

    int cch = FormatMessage(FORMAT_MESSAGE_FROM_STRING, pszFormat, 0, 0,
			    pszBuffer, cchMax, &va);

    va_end(va);

    return cch;
}

//---------------------------------------------------------------------------
// FillLoadOrderGroupCombo
//
//  Fills a combo box with names of load order groups.
//
//  Parameters:
//	  hWnd	     - combo box window handle
//	  pszMachine - target machine
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
EXTERN_C
BOOL
APIENTRY
FillLoadOrderGroupCombo(
	IN HWND hWnd,
	IN PCTSTR pszMachine
	)
{
	_ASSERTE(IsWindow(hWnd));

	CComboBox wndCombo(hWnd);

	CRegKey key, keyMachine;
	HKEY hKeyMachine;
	LONG lRes;
	PTSTR pszList = NULL;

	// connect to the registry on the specified machine
	lRes = RegConnectRegistry(pszMachine, HKEY_LOCAL_MACHINE, &hKeyMachine);
	if (lRes != ERROR_SUCCESS)
		return FALSE;

	keyMachine.Attach(hKeyMachine);

	// fill load order group combo box
	lRes = key.Open(hKeyMachine, _szGroupOrder, KEY_READ);
	if (lRes == ERROR_SUCCESS)
	{
		// determine value length
		DWORD cbValue = 0;
		lRes = RegQueryValueEx(key, _T("List"), NULL, NULL, NULL, &cbValue);

		if (lRes == ERROR_SUCCESS || lRes == ERROR_MORE_DATA)
		{
			pszList = (PTSTR)_alloca(cbValue);
			*pszList = 0;

			lRes = RegQueryValueEx(key, _T("List"), NULL, NULL, (PBYTE)pszList,
								   &cbValue);
			if (lRes == ERROR_SUCCESS)
			{
				PTSTR psz = pszList;
				while (*psz != 0)
				{
					wndCombo.AddString(psz);
					psz += lstrlen(psz) + 1;
				}
			}
		}
	}

	SetLastError(lRes);
	return lRes == ERROR_SUCCESS;
}

//---------------------------------------------------------------------------
// ParseUserName
//
//  Parses the user name from the LDAP SID path
//
//  Parameters:
//	  pszMachine  - remote machine name
//	  pszPath     - object path
//	  pszUserName - pointer to a buffer that receives the user name
//	  cchMax      - size of the buffer in characters
//
//  Returns:
//	  standard COM return code.
//
static
HRESULT
APIENTRY
ParseUserName(
	IN PCTSTR pszMachine,
	IN PWSTR pszPath,
	OUT PTSTR pszUserName,
	IN UINT cchMax
	)
{
	_ASSERTE(pszPath != NULL);
	_ASSERTE(_CrtIsValidPointer(pszUserName, cchMax * sizeof(TCHAR), 1));

	UINT cch = lstrlenW(pszPath);
	if (cch < 14 || pszPath[11] != L'=')
		return E_UNEXPECTED;
	pszPath[11] = 0;

	if (lstrcmpiW(pszPath, L"LDAP://<SID") != 0)
		return E_UNEXPECTED;
	pszPath += 12;
	cch -= 13;

	if ((cch % 2) != 0 || pszPath[cch] != L'>')
		return E_UNEXPECTED;
	pszPath[cch] = 0;

	CharLowerW(pszPath);

	DWORD cbSid = cch / 2;
	PUCHAR pSid = (PUCHAR)_alloca(cbSid);
	_ASSERTE(pSid != NULL);

	UINT i = 0;
	while (pszPath[0] != 0)
	{
		UINT_PTR bLo = wcschr(_szHexDigits, pszPath[1]) - _szHexDigits;
		UINT_PTR bHi = wcschr(_szHexDigits, pszPath[0]) - _szHexDigits;

		if (bHi > 0x0F || bLo > 0x0F)
			return E_UNEXPECTED;

		pSid[i++] = (BYTE)((bHi << 4) | bLo);
		pszPath += 2;
	}

	TCHAR szUserName[UNLEN + 1];
	TCHAR szDomainName[DNLEN + 1];
	TCHAR szComputerName[CNLEN + 1];
	DWORD cchUserName = countof(szUserName);
	DWORD cchDomainName = countof(szDomainName);
	DWORD cchComputerName = countof(szComputerName);
	SID_NAME_USE Use;

	if (!LookupAccountSid(pszMachine, (PSID)pSid, szUserName, &cchUserName,
						  szDomainName, &cchDomainName, &Use))
		return HRESULT_FROM_WIN32(GetLastError());

	if (!GetComputerName(szComputerName, &cchComputerName))
		return HRESULT_FROM_WIN32(GetLastError());

	if (lstrcmpi(szComputerName, szDomainName) == 0)
		szDomainName[0] = _T('.'), szDomainName[1] = 0;

	FormatString(pszUserName, cchMax, _T("%1\\%2"), szDomainName,
				 szUserName);

	return S_OK;
}

//---------------------------------------------------------------------------
// BrowseForUser
//
//  Opens user selection dialog box and returns name of the user account
//  selected in <domain>\<user> format.
//
//  Parameters:
//	  hWnd		 - owner window for the dialog
//	  pszMachine - machine which user database to use
//	  pszUser	 - pointer to a buffer that receives the user account name
//	  cchUser	 - size of the buffer in characters
//
//  Returns:
//	  -1, if failed;
//	  IDOK, if the account has been selected;
//	  IDCANCEL, if the user has cancelled account selection.
//
EXTERN_C
int
APIENTRY
BrowseForUser(
	IN HWND hWnd,
	IN PCTSTR pszMachine,
	OUT PTSTR pszUser,
	IN UINT cchUser
	)
{
	_ASSERTE(_CrtIsValidPointer(pszUser, cchUser * sizeof(TCHAR), 1));

	USES_CONVERSION;

	HRESULT hRes;
	CComPtr<IDsObjectPicker> spPicker;
	CComPtr<IDataObject> spDataObject;
	
	hRes = CoCreateInstance(CLSID_DsObjectPicker, NULL, CLSCTX_INPROC_SERVER,
							IID_IDsObjectPicker, (PVOID *)&spPicker);
	if (SUCCEEDED(hRes))
	{
		DSOP_SCOPE_INIT_INFO ScopeInfo[1];
		DSOP_INIT_INFO InitInfo;

		ScopeInfo[0].cbSize = sizeof(ScopeInfo[0]);

		ScopeInfo[0].flType =  DSOP_SCOPE_TYPE_ENTERPRISE_DOMAIN|
							   DSOP_SCOPE_TYPE_DOWNLEVEL_JOINED_DOMAIN|
							   DSOP_SCOPE_TYPE_TARGET_COMPUTER;

		ScopeInfo[0].flScope = DSOP_SCOPE_FLAG_WANT_SID_PATH|
							   DSOP_SCOPE_FLAG_STARTING_SCOPE;

		ScopeInfo[0].FilterFlags.Uplevel.flBothModes = DSOP_FILTER_USERS;
		ScopeInfo[0].FilterFlags.Uplevel.flNativeModeOnly = 0;
		ScopeInfo[0].FilterFlags.Uplevel.flMixedModeOnly = 0;

		ScopeInfo[0].FilterFlags.flDownlevel = DSOP_DOWNLEVEL_FILTER_USERS;

		ScopeInfo[0].pwzDcName = NULL;
		ScopeInfo[0].pwzADsPath = NULL;
		ScopeInfo[0].hr = E_UNEXPECTED;

		InitInfo.cbSize = sizeof(InitInfo);
		InitInfo.flOptions = 0;
		InitInfo.pwzTargetComputer = (PWSTR)T2CW(pszMachine);
		InitInfo.cDsScopeInfos = countof(ScopeInfo);
		InitInfo.aDsScopeInfos = ScopeInfo;
		InitInfo.cAttributesToFetch = 0;
		InitInfo.apwzAttributeNames = NULL;

		hRes = spPicker->Initialize(&InitInfo);
		if (SUCCEEDED(hRes))
			hRes = spPicker->InvokeDialog(hWnd, &spDataObject);

		if (hRes != S_OK)
			return IDCANCEL;
	}

	FORMATETC FormatEtc;
	PDS_SELECTION_LIST pList;
	UINT cfFormat;

	STGMEDIUM StgMedium;
	memset(&StgMedium, 0, sizeof(StgMedium));

	if (SUCCEEDED(hRes))
	{
		cfFormat = RegisterClipboardFormat(CFSTR_DSOP_DS_SELECTION_LIST);

		FormatEtc.cfFormat = (WORD)cfFormat;
		FormatEtc.dwAspect = DVASPECT_CONTENT;
		FormatEtc.lindex = -1;
		FormatEtc.ptd = NULL;
		FormatEtc.tymed = TYMED_HGLOBAL;

		hRes = spDataObject->GetData(&FormatEtc, &StgMedium);			
	}

	if (SUCCEEDED(hRes))
	{
		_ASSERTE(StgMedium.tymed == TYMED_HGLOBAL);

		pList = (PDS_SELECTION_LIST)GlobalLock(StgMedium.hGlobal);
		_ASSERTE(pList != NULL);
		_ASSERTE(pList->cItems == 1);

		hRes = ParseUserName(pszMachine, pList->aDsSelection[0].pwzADsPath,
							 pszUser, cchUser);

		ReleaseStgMedium(&StgMedium);
	}

	if (FAILED(hRes))
		return SetLastError(hRes), -1;

	return IDOK;
}

//---------------------------------------------------------------------------
// CreateLocalFont
//
//  Creates a font based on its description in the form:
//    <face name>,[B][I],<point size>
//
//  Parameters:
//	  pszFont - pointer to a string that either contains font description
//			    or is the identifier of a string resource
//
//  Returns:
//	  font handle, if successful, NULL - otherwise.
//
EXTERN_C
HFONT
APIENTRY
CreateLocalFont(
	IN PCTSTR pszFont
	)
{
	_ASSERTE(pszFont != NULL);

	TCHAR szFont[80];
	if (HIWORD(pszFont) == 0)
	{
		if (!AtlLoadString(LOWORD(szFont), szFont, countof(szFont)))
			lstrcpy(szFont, _T("Verdana,B,12"));
	}

	// find and separate style indicator
	PTSTR pszStyle = _tcschr(szFont, _T(','));
	if (pszStyle != NULL)
		*pszStyle++ = 0;
	else
		pszStyle = _T("B");

	// find and separate size indicator
	PTSTR pszSize = _tcschr(pszStyle, _T(','));
	if (pszSize != NULL)
		*pszSize++ = 0;
	else
		pszSize = _T("12");

	// convert size into binary
	DWORD dwSize = 0;
	while (*pszSize >= _T('0') && *pszSize <= _T('9'))
		dwSize = dwSize * 10 + (*pszSize++ - _T('0'));

	LOGFONT lf;
	memset(&lf, 0, sizeof(lf));

	lf.lfCharSet = ANSI_CHARSET;
	lf.lfWeight = FW_NORMAL;

	if (_tcschr(pszStyle, _T('B')) != NULL)
		lf.lfWeight = FW_BOLD;
	if (_tcschr(pszStyle, _T('I')) != NULL)
		lf.lfItalic = TRUE;

	lstrcpyn(lf.lfFaceName, szFont, countof(lf.lfFaceName));

	// calculate height of the font based on its point size
	HDC hDC = GetDC(NULL);

	POINT apt[2];
	apt[0].x = 0;
	apt[0].y = (GetDeviceCaps(hDC, LOGPIXELSY) * dwSize) / 72;
	apt[1].x = 0;
	apt[1].y = 0;
	
	DPtoLP(hDC, apt, countof(apt));

	lf.lfHeight = -abs(apt[0].y - apt[1].y);

	ReleaseDC(NULL, hDC);

	return CreateFontIndirect(&lf);
}
