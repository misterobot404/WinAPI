// mainwnd.cpp
//
// Main application window.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "mainwnd.h"
#include "errorbox.h"
#include "svcobj.h"
#include "svcprop.h"
#include "svcwiz.h"
#include "ssdeps.h"
#include "progress.h"
#include "startarg.h"
#include "connect.h"
#include "about.h"

const TCHAR _szSettings[] = _T("Software\\RSDN\\Service Administrator")
							_T("\\Settings");

//---------------------------------------------------------------------------
// RestoreWindowPos
//
//  Restores last window position from the previous invokation.
//
//  Parameters:
//	  nShowCmd - show command
//
//  Returns:
//	  no return value.
//
void
CMainWnd::RestoreWindowPos(
	int nShowCmd
	)
{
	CRegKey key;
	LONG lRes;
	RECT rcWnd;
	RECT rcWorkArea;
	
	lRes = key.Open(HKEY_CURRENT_USER, _szSettings, KEY_READ);
	if (lRes == ERROR_SUCCESS)
	{
		if (nShowCmd == SW_SHOWNORMAL)
		{
			lRes = key.QueryValue((DWORD&)nShowCmd, _T("WindowState"));
			if (lRes != ERROR_SUCCESS)
				goto l_Show;
		}
	
		if (nShowCmd == SW_SHOWNORMAL || nShowCmd == SW_SHOWMINIMIZED)
		{
			nShowCmd = SW_SHOWNORMAL;

			lRes = key.QueryValue((DWORD&)rcWnd.left, _T("WindowLeft"));
			if (lRes != ERROR_SUCCESS)
				goto l_Show;

			lRes = key.QueryValue((DWORD&)rcWnd.top, _T("WindowTop"));
			if (lRes != ERROR_SUCCESS)
				goto l_Show;

			lRes = key.QueryValue((DWORD&)rcWnd.right, _T("WindowRight"));
			if (lRes != ERROR_SUCCESS)
				goto l_Show;

			lRes = key.QueryValue((DWORD&)rcWnd.bottom, _T("WindowBottom"));
			if (lRes != ERROR_SUCCESS)
				goto l_Show;

			// check if window will be at least partially visible
			SystemParametersInfo(SPI_GETWORKAREA, sizeof(RECT),
								 &rcWorkArea, 0);

			if (!IntersectRect(&rcWorkArea, &rcWnd, &rcWorkArea))
				goto l_Show;

			MoveWindow(&rcWnd);
		}
	}

l_Show:
	ShowWindow(nShowCmd);
}

//---------------------------------------------------------------------------
// GetStateString
//
//  Returns string describing the given service state
//
//  Parameters:
//	  dwState - service state
//
//  Returns:
//	  pointer to the string describing the given service state.
//
PCTSTR
CMainWnd::GetStateString(
	DWORD dwState
	)
{
	if (dwState == SERVICE_INVALID_VALUE)
		return &_chNil;

	dwState--;
	_ASSERTE(dwState < 7);

	PTSTR psz = m_szState[dwState];

	if (*psz == 0)
	{
		UINT nString = IDS_SERVICE_STOPPED + dwState;
		AtlLoadString(nString, psz, countof(m_szState[0]));
	}

	_ASSERTE(*psz != 0);
	return psz;
}

//---------------------------------------------------------------------------
// GetStartupTypeString
//
//  Returns string describing the given service startup type
//
//  Parameters:
//	  dwStartupType - service startup type
//
//  Returns:
//	  pointer to the string describing the given service startup type.
//
PCTSTR
CMainWnd::GetStartupTypeString(
	DWORD dwStartupType
	)
{
	if (dwStartupType == SERVICE_INVALID_VALUE)
		return &_chNil;

	dwStartupType -= 2;
	_ASSERTE(dwStartupType < 3);

	PTSTR psz = m_szStartupType[dwStartupType];

	if (*psz == 0)
	{
		UINT nString = IDS_SERVICE_AUTO_START + dwStartupType;
		AtlLoadString(nString, psz, countof(m_szStartupType[0]));
	}

	_ASSERTE(*psz != 0);
	return psz;
}

//---------------------------------------------------------------------------
// GetErrorControlString
//
//  Returns string describing the given error control type.
//
//  Parameters:
//	  dwErrorControl - service error control type
//
//  Returns:
//	  pointer to the string describing the given service error control type.
//
PCTSTR
CMainWnd::GetErrorControlString(
	DWORD dwErrorControl
	)
{
	if (dwErrorControl == SERVICE_INVALID_VALUE)
		return &_chNil;

	_ASSERTE(dwErrorControl < 4);

	PTSTR psz = m_szErrorControl[dwErrorControl];

	if (*psz == 0)
	{
		UINT nString = IDS_SERVICE_ERROR_IGNORE + dwErrorControl;
		AtlLoadString(nString,  psz, countof(m_szErrorControl[0]));
	}

	_ASSERTE(*psz != 0);
	return psz;
}

//---------------------------------------------------------------------------
// GetProcessString
//
//  Returns string describing the given service process type.
//
//  Parameters:
//	  dwServiceType - service type
//
//  Returns:
//	  pointer to the string describing the given service process type.
//
PCTSTR
CMainWnd::GetProcessString(
	DWORD dwServiceType
	)
{
	if (dwServiceType == SERVICE_INVALID_VALUE)
		return &_chNil;

	int nType = (dwServiceType & SERVICE_WIN32_SHARE_PROCESS) != 0;

	PTSTR psz = m_szProcess[nType];

	if (*psz == 0)
	{
		UINT nString = IDS_SERVICE_OWN_PROCESS + nType;
		AtlLoadString(nString, psz, countof(m_szProcess[0]));
	}

	_ASSERTE(*psz != 0);
	return psz;
}

//---------------------------------------------------------------------------
// GetInteractiveString
//
//  Returns string describing the given interactive status.
//
//  Parameters:
//	  dwServiceType - service type
//
//  Returns:
//	  pointer to the string describing the given interactive status.
//
PCTSTR
CMainWnd::GetInteractiveString(
	DWORD dwServiceType
	)
{
	if (dwServiceType == SERVICE_INVALID_VALUE)
		return &_chNil;

	int nType = (dwServiceType & SERVICE_INTERACTIVE_PROCESS) == 0;

	PTSTR psz = m_szInteractive[nType];

	if (*psz == 0)
	{
		UINT nString = IDS_SERVICE_INTERACTIVE + nType;
		AtlLoadString(nString, psz, countof(m_szInteractive[0]));
	}

	_ASSERTE(*psz != 0);
	return psz;
}

//---------------------------------------------------------------------------
// GetFailureActionString
//
//  Returns string describing the given service failure action.
//
//  Parameters:
//	  dwFailureAction - failure action
//
//  Returns:
//	  pointer to the string describing the given interactive status.
//
PCTSTR
CMainWnd::GetFailureActionString(
	DWORD dwFailureAction
	)
{
	if (dwFailureAction == SERVICE_INVALID_VALUE)
		return &_chNil;

	_ASSERTE(dwFailureAction < 4);

	PTSTR psz = m_szFailureAction[dwFailureAction];

	if (*psz == 0)
	{
		UINT nString = IDS_SC_ACTION_NONE + dwFailureAction;
		AtlLoadString(nString, psz, countof(m_szFailureAction[0]));
	}

	_ASSERTE(*psz != 0);
	return psz;
}

//---------------------------------------------------------------------------
// GetWndClassInfo
//
//  Returns window class information.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  reference to the structure describing window class.
//
CFrameWndClassInfo&
CMainWnd::GetWndClassInfo()
{
	static CFrameWndClassInfo wc = 
	{
		{ 
			sizeof(WNDCLASSEX),			// cbSize
			0,							// style
			StartWindowProc,			// lpfnWndProc
			0,							// cbClsExtra
			0,							// cbWndExtra
			0,							// hInstance
			0,							// hIcon
			0,							// hCursor
			(HBRUSH)(COLOR_3DFACE+1),	// hbrBackground
			MAKEINTRESOURCE(IDR_MAIN),	// lpszMenuName
			NULL,						// lpszClassName
			0							// hIconSm
		},
		NULL,			// m_lpszOrigName
		NULL,			// pWndProc
		IDC_ARROW,		// m_lpszCursorID
		TRUE,			// m_bSystemCursor
		0,				// m_atom
		_T(""),			// m_szAutoName
		IDR_MAIN		// m_uCommonResourceID
	};

	// load icons
	wc.m_wc.hIcon   = AtlLoadIconImage(IDR_MAIN, LR_DEFAULTCOLOR, 32, 32);
	wc.m_wc.hIconSm = AtlLoadIconImage(IDR_MAIN, LR_DEFAULTCOLOR, 16, 16);

	return wc;
}

//---------------------------------------------------------------------------
// UpdateLayout
//
//  Repositions client windows according to the new layout.
//
//  Parameters:
//	  bResizeBars - bar windows should be resized
//
//  Returns:
//	  no return value.
//
void 
CMainWnd::UpdateLayout(
	IN BOOL bResizeBars
	)
{
	RECT rect;
	GetClientRect(&rect);

	// resize toolbar
	if (::IsWindowVisible(m_hWndToolBar))
	{
		if (bResizeBars)
			::MoveWindow(m_hWndToolBar, 0, 0, rect.right, 25, TRUE);

		rect.top += 25;
	}

	// resize status bar
	if (::IsWindowVisible(m_hWndStatusBar))
	{
		if (bResizeBars)
			::SendMessage(m_hWndStatusBar, WM_SIZE, 0, 0);

		RECT rectSB;
		::GetWindowRect(m_hWndStatusBar, &rectSB);

		rect.bottom -= rectSB.bottom - rectSB.top;
	}

	// resize client window
	if (m_hWndClient != NULL)
	{
		::SetWindowPos(m_hWndClient, NULL, rect.left, rect.top,
			rect.right - rect.left, rect.bottom - rect.top,
			SWP_NOZORDER|SWP_NOACTIVATE);
	}

	// update toolbar area
	rect.top = 0;
	rect.bottom = 25;
	InvalidateRect(&rect);

	UpdateWindow();
}

//---------------------------------------------------------------------------
// OnIdle
//
//  Performs idle-time processing.
//
//  Parameters:
//    none.
//
//  Returns:
//	  TRUE for more invokations, FALSE - to stop invokations.
//
BOOL
CMainWnd::OnIdle()
{
	UIUpdateToolBar();
	return FALSE;
}

//---------------------------------------------------------------------------
// OnActivate
//
//  Handles WM_ACTIVATE message. Centers the window which is about to pop
//  above this window.
//
//  Parameters:
//    fuActive   - specifies whether the window is being activated or 
//				   deactivated
//    bMinimized - specifies whether the window is minimized
//	  hWndOther  - other window which is activated or deactivated
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActivate(
	UINT fuActive,
	BOOL bMinimized,
	HWND hWndOther
    )
{
    _UNUSED(bMinimized);

    if (fuActive == WA_INACTIVE && hWndOther != NULL)
	{
		CWindow wndActive(hWndOther);
		if (wndActive.GetParent() == m_hWnd)
			wndActive.CenterWindow(m_hWnd);
	}
}

//---------------------------------------------------------------------------
// OnContextMenu
//
//  Handles WM_CONTEXTMENU message. Displays a popup menu for the selected
//  item.
//
//  Parameters:
//    hWnd - right-clicked window handle
//    pt   - screen coordinates of the mouse pointer
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnContextMenu(
	HWND hWnd,
	CPoint pt
    )
{
	if (m_wndList.m_hWnd != hWnd)
	{
		SetMsgHandled(FALSE);
		return;
	}

	if (pt.x == -1 && pt.y == -1)
	{
		RECT rc;

		int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
		if (nSel != -1)
		{
			m_wndList.GetItemRect(nSel, &rc, LVIR_LABEL);
			pt.x = rc.left;
			pt.y = rc.bottom;
		}
		else
		{
			m_wndList.GetClientRect(&rc);
			pt.x = rc.left;
			pt.y = rc.top;
		}

		m_wndList.ClientToScreen(&pt);
	}

	CMenu menu;
	_VERIFY(menu.LoadMenu(IDR_POPUPS));

	menu.GetSubMenu(0).TrackPopupMenu(TPM_LEFTALIGN, pt.x, pt.y, 
									  m_hWnd, NULL);
}

//---------------------------------------------------------------------------
// OnCreate
//
//  Handles WM_CREATE message. Creates toolbar window and list view window
//  in the client area of the window.
//
//  Parameters:
//	  pCreateStruct - window creation data
//
//  Returns:
//    0, if successful, -1 - otherwise.
//
int
CMainWnd::OnCreate(
	LPCREATESTRUCT pCreateStruct
    )
{
    _UNUSED(pCreateStruct);

	DWORD dwStyle;

	// load color scheme sensitive bitmaps
	OnSysColorChange();

	// load UI configuration
	LoadConfig();

	// create toolbar control
	dwStyle = WS_CHILD|WS_VISIBLE|CCS_NORESIZE|TBSTYLE_TOOLTIPS|TBSTYLE_FLAT;
	if (!CreateSimpleToolBar(IDR_MAIN, dwStyle))
		return -1;

	TBBUTTONINFO tbbi;
	tbbi.cbSize = sizeof(tbbi);
	tbbi.dwMask = TBIF_STATE;
	tbbi.fsState =  TBSTATE_HIDDEN;

	CToolBarCtrl(m_hWndToolBar).SetButtonInfo(ID_ACTION_RESUME, &tbbi);

	// create status bar control
	if (!CreateSimpleStatusBar())
		return -1;

	UIAddToolBar(m_hWndToolBar);
	UISetCheck(ID_VIEW_TOOLBAR, 1);
	UISetCheck(ID_VIEW_STATUS_BAR, 1);

	UIEnable(ID_ACTION_DISCONNECT, FALSE);
	UIEnable(ID_ACTION_DELETE, FALSE);
	UIEnable(ID_ACTION_START, FALSE);
	UIEnable(ID_ACTION_START_EX, FALSE);
	UIEnable(ID_ACTION_STOP, FALSE);
	UIEnable(ID_ACTION_PAUSE, FALSE);
	UIEnable(ID_ACTION_RESUME, FALSE);
	UIEnable(ID_VIEW_REFRESH, FALSE);
	UIEnable(ID_VIEW_PROPERTIES, FALSE);

	// create list view control
	dwStyle = WS_CHILD|WS_VISIBLE|LVS_REPORT|LVS_SHAREIMAGELISTS|
			  LVS_SINGLESEL|LVS_SHOWSELALWAYS;
	m_hWndClient = m_wndList.Create(m_hWnd, NULL, NULL, dwStyle, 
									WS_EX_CLIENTEDGE, ATL_IDW_CLIENT);
	if (m_hWndClient == NULL)
		return -1;

	// set list view extended styles
	dwStyle = LVS_EX_HEADERDRAGDROP|LVS_EX_FULLROWSELECT;
	m_wndList.SetExtendedListViewStyle(dwStyle);

	// load image list and assign it to the list view control
	if (m_imlIcons.CreateFromImage(IDB_IMAGELIST, 16, 0, RGB(0xFF,0x00,0xFF),
								   IMAGE_BITMAP, LR_DEFAULTCOLOR))
		m_wndList.SetImageList(m_imlIcons, LVSIL_SMALL);

	// add columns to the list view
	int nPos = 0;
	DWORD dwMask = 1;
	for (int nCol = 0; nCol < COLUMN_MAX; nCol++)
	{
		if (dwMask & m_dwColumnSet)
		{
			InsertColumn(nCol, nPos++);
			UISetCheck(ID_VIEW_COLUMN_0 + nCol, 1);
		}

		dwMask <<= 1;
	}
	UIEnable(ID_VIEW_COLUMN_0, FALSE);

	// restore column order array
	m_wndList.SetColumnOrderArray(nPos, m_nColOrder);
	SetSortMark(m_nSortOrder);

	// add idle handle and message filter
	CMessageLoop * pLoop = _Module.GetMessageLoop();
	_ASSERTE(pLoop != NULL);

	pLoop->AddIdleHandler(this);
	pLoop->AddMessageFilter(this);

	TCHAR szMachine[80], szTitle[256];

	AtlLoadString(IDS_LOCAL_MACHINE, szMachine, countof(szMachine));
	FormatString(szTitle, countof(szTitle), MAKEINTRESOURCE(IDS_TITLE),
				 szMachine);
	SetWindowText(szTitle);

	// connect to the local computer
	if (DoConnect(NULL, NULL, NULL))
		OnViewRefresh();

    return 0;
}

//---------------------------------------------------------------------------
// OnDestroy
//
//  Handles WM_DESTROY message. The function posts WM_QUIT message into the
//  application message queue, which will cause the message loop to exit.
//
//  Parameters:
//	  none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnDestroy()
{
	int nPos = 0;
	DWORD dwMask = 1;
	for (int nCol = 0; nCol < COLUMN_MAX; nCol++)
	{
		if (dwMask & m_dwColumnSet)
			m_nColWidth[nCol] = m_wndList.GetColumnWidth(nPos++);
		dwMask <<= 1;
	}

	// save configuration
	SaveConfig();

	// disconnect from the SCM
	if (m_hSCM != NULL)
		_VERIFY(CloseServiceHandle(m_hSCM));

	// destroy image list
	m_imlIcons.Destroy();

    // post WM_QUIT message
    PostQuitMessage(0);
}

//---------------------------------------------------------------------------
// OnGetMinMaxInfo
//
//  Handles the WM_GETMINMAXINFO message. Returns minimum window tracking
//  size.
//
//  Parameters:
//	  pmmi - pointer to the MINMAXINFO structure
//
//  Returns:
//    no return value;
//
void
CMainWnd::OnGetMinMaxInfo(
	LPMINMAXINFO pmmi
    )
{
    // let default handling to occur first
    DefWindowProc();

    pmmi->ptMinTrackSize.x = 300;
	pmmi->ptMinTrackSize.y = 100;
}

//---------------------------------------------------------------------------
// OnSysColorChange
//
//  Handles WM_SYSCOLORCHANGE message. Reloads all bitmap which are dependent
//  on the system color scheme.
//
//  Parameters:
//    none.
//
//  Returns:
//	  no return value
//
void
CMainWnd::OnSysColorChange()
{
	HBITMAP hBitmap;

	// free current bitmaps
	if (m_bmSortUp.m_hBitmap != NULL)
		_VERIFY(m_bmSortUp.DeleteObject());
	if (m_bmSortDown.m_hBitmap != NULL)
		_VERIFY(m_bmSortDown.DeleteObject());

	hBitmap = CreateMappedBitmap(_Module.GetResourceInstance(), 
								 IDB_SORT_UP, 0, NULL, 0);
	_ASSERTE(hBitmap != NULL);
	m_bmSortUp.Attach(hBitmap);

	hBitmap = CreateMappedBitmap(_Module.GetResourceInstance(), 
								 IDB_SORT_DOWN, 0, NULL, 0);
	_ASSERTE(hBitmap != NULL);
	m_bmSortDown.Attach(hBitmap);

	if (m_hWndToolBar != NULL)
	{
		// reload toolbar bitmap
		CToolBarCtrl wndToolbar(m_hWndToolBar);

		TBREPLACEBITMAP tbrb;
		tbrb.hInstOld = _Module.GetResourceInstance();
		tbrb.nIDOld = IDR_MAIN;
		tbrb.hInstNew = _Module.GetResourceInstance();
		tbrb.nIDNew = IDR_MAIN;
		tbrb.nButtons = 6;

		wndToolbar.ReplaceBitmap(&tbrb);
	}

	SendMessageToDescendants(WM_SYSCOLORCHANGE);

	if (m_nSortOrder != 0)
		SetSortMark(m_nSortOrder);
}

//---------------------------------------------------------------------------
// OnList_ColumnClick
//
//  Handles LVN_COLUMNCLICK notification from the list. Sorts the list
//  accordingly to the column clicked.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CMainWnd::OnList_ColumnClick(
    LPNMHDR pNMHDR
    )
{
	NMLISTVIEW * pnmlv = (NMLISTVIEW *)pNMHDR;

	int nCol = GetLogicalColumn(pnmlv->iSubItem);

	if (nCol == abs(m_nSortOrder) - 1)
		m_nSortOrder = -m_nSortOrder;
	else
		m_nSortOrder = nCol + 1;

	m_wndList.SortItems(SortCallback, (LPARAM)this);
	SetSortMark(m_nSortOrder);

	return 0;
}

//---------------------------------------------------------------------------
// OnList_DeleteItem
//
//  Handles LVN_DELETEITEM notification from the list. Frees any memory
//  associated with the item being deleted.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CMainWnd::OnList_DeleteItem(
    LPNMHDR pNMHDR
    )
{
    NMLISTVIEW * pnmlv = (NMLISTVIEW *)pNMHDR;
	CService * pService = (CService *)pnmlv->lParam;

	_ASSERTE(pService != NULL);
	__assume(pService != NULL);

	delete pService;
    return 0;
}

//---------------------------------------------------------------------------
// OnList_ItemChanged
//
//  Handles LVN_ITEMCHANGED notification from the list. Tracks selection
//  changes in the list.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CMainWnd::OnList_ItemChanged(
    LPNMHDR pNMHDR
    )
{
	_UNUSED(pNMHDR);

	BOOL bStart = FALSE;
	BOOL bStop = FALSE;
	BOOL bPause = FALSE;
	BOOL bResume = FALSE;
	
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	if (nSel != -1)
	{
		CService * pService = GetService(nSel);
		_ASSERTE(pService != NULL);

		DWORD dwState = pService->m_dwCurrentState;
		DWORD dwControls = pService->m_dwControlsAccepted;

		bStart = dwState == SERVICE_STOPPED;
		bStop = dwState != SERVICE_STOPPED && 
				(dwControls & SERVICE_ACCEPT_STOP) != 0;
		bPause = dwState == SERVICE_RUNNING &&
				 (dwControls & SERVICE_ACCEPT_PAUSE_CONTINUE) != 0;
		bResume = dwState == SERVICE_PAUSED &&
				  (dwControls & SERVICE_ACCEPT_PAUSE_CONTINUE) != 0;

		CToolBarCtrl wndToolbar(m_hWndToolBar);

		TBBUTTONINFO tbbi;
		tbbi.cbSize = sizeof(tbbi);
		tbbi.dwMask = TBIF_STATE;

		if (dwState == SERVICE_PAUSED)
			tbbi.fsState =  TBSTATE_HIDDEN;
		else
			tbbi.fsState = TBSTATE_ENABLED;
		wndToolbar.SetButtonInfo(ID_ACTION_START, &tbbi);

		if (dwState == SERVICE_PAUSED)
			tbbi.fsState =  TBSTATE_ENABLED;
		else
			tbbi.fsState = TBSTATE_HIDDEN;
		wndToolbar.SetButtonInfo(ID_ACTION_RESUME, &tbbi);
	}

	UISetState(ID_ACTION_START, bStart ? 0 : UPDUI_DISABLED);
	UISetState(ID_ACTION_START_EX, bStart ? 0 : UPDUI_DISABLED);
	UISetState(ID_ACTION_STOP, bStop ? 0 : UPDUI_DISABLED);
	UISetState(ID_ACTION_PAUSE, bPause ? 0 : UPDUI_DISABLED);
	UISetState(ID_ACTION_RESUME, bResume ? 0 : UPDUI_DISABLED);
	UISetState(ID_ACTION_DELETE, nSel != -1 ? 0 : UPDUI_DISABLED);
	UISetState(ID_VIEW_PROPERTIES, nSel != -1 ? UPDUI_DEFAULT : UPDUI_DISABLED);

	return 0;
}

//---------------------------------------------------------------------------
// OnHeader_RClick
//
//  Handles NM_RCLICK notification from the header control. Displays a
//  context menu for column selection.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CMainWnd::OnHeader_RClick(
    LPNMHDR pNMHDR
    )
{
	_UNUSED(pNMHDR);

	POINT pt;
	_VERIFY(GetCursorPos(&pt));

	CMenu menu;
	_VERIFY(menu.LoadMenu(IDR_POPUPS));

	menu.GetSubMenu(1).TrackPopupMenu(TPM_LEFTALIGN, pt.x, pt.y, 
									  m_hWnd, NULL);

	return 1;
}

//---------------------------------------------------------------------------
// OnActionConnect
//
//  Handles "Action|Connect to another computer..." menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionConnect()
{
	CConnectDlg dlgConnect;

	if (dlgConnect.DoModal() != IDOK)
		return;

	BOOL bEnable = FALSE;
	TCHAR szDisconnect[80];
	UINT nString = IDS_DISCONNECT;

	if (DoConnect(dlgConnect.GetMachineName(), dlgConnect.GetUserName(),
				  dlgConnect.GetPassword()))
	{
		nString = IDS_DISCONNECT_FROM;
		bEnable = TRUE;

	}
	else if (m_hSCM == NULL)
	{
		// if no longer connected, try to reconnect with the local
		// machine
		DoConnect(NULL, NULL, NULL);
	}

	FormatString(szDisconnect, countof(szDisconnect),
				 MAKEINTRESOURCE(nString), m_szMachine);

	UISetText(ID_ACTION_DISCONNECT, szDisconnect);
	UIEnable(ID_ACTION_DISCONNECT, bEnable);

	OnViewRefresh();
}

//---------------------------------------------------------------------------
// OnActionDisconnect
//
//  Handles "Action|Disconnect" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionDisconnect()
{
	if (DoConnect(NULL, NULL, NULL))
	{
		TCHAR szDisconnect[80];
		AtlLoadString(IDS_DISCONNECT, szDisconnect, countof(szDisconnect));

		UISetText(ID_ACTION_DISCONNECT, szDisconnect);
		UIEnable(ID_ACTION_DISCONNECT, FALSE);

		OnViewRefresh();
	}
}

//---------------------------------------------------------------------------
// OnActionStart
//
//  Handles "Start" toolbar button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionStart()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);

	CService * pService = GetService(nSel);
	_ASSERTE(pService != NULL);

	DoStartService(pService, 0, NULL);
}

//---------------------------------------------------------------------------
// OnActionStartEx
//
//  Handles "Action|Start..." menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionStartEx()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);

	CService * pService = GetService(nSel);
	_ASSERTE(pService != NULL);

	CStartArgDlg dlgStart;
	
	if (dlgStart.DoModal() != IDOK)
		return;

	USES_CONVERSION;
	int nArgc;
	PCWSTR * pArgv;
	
	pArgv = (PCWSTR *)CommandLineToArgvW(T2CW(dlgStart.m_szCmdLine), &nArgc);
	DoStartService(pService, nArgc, pArgv);

	GlobalFree((HGLOBAL)pArgv);
}

//---------------------------------------------------------------------------
// OnActionStop
//
//  Handles "Action|Stop" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionStop()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);

	CService * pService = GetService(nSel);
	_ASSERTE(pService != NULL);

	DoStopService(pService);
}

//---------------------------------------------------------------------------
// OnActionPause
//
//  Handles "Action|Pause" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionPause()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);

	CService * pService = GetService(nSel);
	_ASSERTE(pService != NULL);

	CProgressDlg dlgProgress(this);
	dlgProgress.Create(m_hWnd);
	dlgProgress.ShowWindow(SW_SHOW);

	// simulate modal operation
	EnableWindow(FALSE);

	// pause the service asynchronously while displaying progress
	DWORD dwError = dlgProgress.DoPauseService(pService->m_szName,
										 pService->m_szDisplayName);

	EnableWindow(TRUE);
	dlgProgress.DestroyWindow();

	switch (dwError)
	{
		case ERROR_SERVICE_SPECIFIC_ERROR:
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_PAUSE_FAILED_SPECIFIC),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0,
					 pService->m_szDisplayName, 
					 dlgProgress.GetServiceSpecificError());
			break;

		case ERROR_SUCCESS:
		case ERROR_OPERATION_ABORTED:
			break;

		default:
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_PAUSE_FAILED),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
					 dwError, pService->m_szDisplayName);
			break;
	}

	OnViewRefresh();
}

//---------------------------------------------------------------------------
// OnActionResume
//
//  Handles "Action|Resume" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionResume()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);

	CService * pService = GetService(nSel);
	_ASSERTE(pService != NULL);

	CProgressDlg dlgProgress(this);
	dlgProgress.Create(m_hWnd);
	dlgProgress.ShowWindow(SW_SHOW);

	// simulate modal operation
	EnableWindow(FALSE);

	// resume the service asynchronously while displaying progress
	DWORD dwError = dlgProgress.DoResumeService(pService->m_szName,
										 pService->m_szDisplayName);

	EnableWindow(TRUE);
	dlgProgress.DestroyWindow();

	switch (dwError)
	{
		case ERROR_SERVICE_SPECIFIC_ERROR:
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_RESUME_FAILED_SPECIFIC),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0,
					 pService->m_szDisplayName, 
					 dlgProgress.GetServiceSpecificError());
			break;

		case ERROR_SUCCESS:
		case ERROR_OPERATION_ABORTED:
			break;

		default:
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_RESUME_FAILED),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
					 dwError, pService->m_szDisplayName);
			break;
	}

	OnViewRefresh();
}

//---------------------------------------------------------------------------
// OnActionInstall
//
//  Handles "Action|Install..." menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionInstall()
{
	CWizCtx ctx;
	ctx.pMainWnd = this;
	ctx.dwError = ERROR_OPERATION_ABORTED;
	ctx.bStart = FALSE;
	ctx.pService = new CService;

	if (ctx.pService == NULL)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_WIZARD_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
				 ERROR_NOT_ENOUGH_MEMORY);
		return;
	}

	ctx.pService->m_dwServiceType = 0;
	ctx.pService->m_dwStartupType = 0;
	ctx.pService->m_dwErrorControl = 0;
	ctx.pService->m_bLocalSystem = FALSE;
	ctx.pService->m_bLocalService = FALSE;
	ctx.pService->m_bNetworkService = FALSE;

	PCTSTR pszMachine = GetMachineName();

	ctx.hSCM = OpenSCManager(pszMachine, NULL, SC_MANAGER_CREATE_SERVICE);
	if (ctx.hSCM == NULL)
	{
		DWORD dwError = GetLastError();
		UINT nMessage = IDP_WIZARD_FAILED;

		if (dwError == ERROR_ACCESS_DENIED)
		{
			if (pszMachine == NULL)
				nMessage = IDP_CREATE_LOCAL_ACCESS;
			else
				nMessage = IDP_CREATE_REMOTE_ACCESS;
		}

		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(nMessage),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0,
				 pszMachine);
		return;
	}

	// create property pages
	CWelcomePage page0(&ctx);
	CPathPage page1(&ctx);
	CNamePage page2(&ctx);
	CLogonPage page3(&ctx);
	CStartupPage page4(&ctx);
	CDepPage page5(&ctx);
	CFinishPage page6(&ctx);

    // create property sheet object
    CPropertySheet sheet;

	// add property pages
	sheet.AddPage(page0.Create());
	sheet.AddPage(page1.Create());
	sheet.AddPage(page2.Create());
	sheet.AddPage(page3.Create());
	sheet.AddPage(page4.Create());
	sheet.AddPage(page5.Create());
	sheet.AddPage(page6.Create());

    // show property sheet
	sheet.m_psh.dwFlags |= PSH_WIZARD97|PSH_HEADER|PSH_WATERMARK;
	sheet.m_psh.pszbmWatermark = MAKEINTRESOURCE(IDB_WELCOME);
	sheet.m_psh.pszbmHeader = MAKEINTRESOURCE(IDB_HEADER);

    sheet.DoModal(m_hWnd);

	_VERIFY(CloseServiceHandle(ctx.hSCM));
	memset(&ctx.szPassword, 0, sizeof(ctx.szPassword));

	if (ctx.dwError == ERROR_SUCCESS)
	{
		OnViewRefresh();

		CService * pService;
		if (ctx.bStart && 
			FindServiceItem(ctx.pService->m_szName, &pService) != -1)
		{
			DoStartService(pService, 0, NULL);
		}
	}

	delete ctx.pService;
}

//---------------------------------------------------------------------------
// OnActionDelete
//
//  Handles "Action|Delete" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnActionDelete()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);

	CService * pService = GetService(nSel);
	_ASSERTE(pService != NULL);

	SC_HANDLE hService;
	DWORD dwError = ERROR_SUCCESS;
	TCHAR szTitle[80];
	TCHAR szPrompt[512];

	AtlLoadString(IDS_MESSAGE_TITLE, szTitle, countof(szTitle));

	FormatString(szPrompt, countof(szPrompt), 
				 MAKEINTRESOURCE(IDP_CONFIRM_DELETE),
				 (PCTSTR)pService->m_szDisplayName);

	if (MessageBox(szPrompt, szTitle, MB_YESNO|MB_ICONQUESTION) != IDYES)
		return;

	// if the service is currently running, stop it
	if (pService->m_dwCurrentState != SERVICE_STOPPED)
	{
		if (!DoStopService(pService))
			return;
	}

	// try to open service handle with DELETE access
	hService = OpenService(m_hSCM, pService->m_szName, DELETE);
	if (hService != NULL)
	{
		if (!DeleteService(hService))
			dwError = GetLastError();

		_VERIFY(CloseServiceHandle(hService));
	}
	else
		dwError = GetLastError();

	if (dwError != ERROR_SUCCESS)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_DELETE_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), dwError,
				 (PCTSTR)pService->m_szDisplayName);
	}
	else
		OnViewRefresh();
}

//---------------------------------------------------------------------------
// OnViewToolbar
//
//  Handles "View|Toolbar" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnViewToolbar()
{
	BOOL bNew = !::IsWindowVisible(m_hWndToolBar);

	::ShowWindow(m_hWndToolBar, bNew ? SW_SHOWNOACTIVATE : SW_HIDE);

	UISetCheck(ID_VIEW_TOOLBAR, bNew);
	UpdateLayout();
}

//---------------------------------------------------------------------------
// OnViewStatusBar
//
//  Handles "View|Status Bar" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnViewStatusBar()
{
	BOOL bNew = !::IsWindowVisible(m_hWndStatusBar);

	::ShowWindow(m_hWndStatusBar, bNew ? SW_SHOWNOACTIVATE : SW_HIDE);

	UISetCheck(ID_VIEW_STATUS_BAR, bNew);
	UpdateLayout();
}

//---------------------------------------------------------------------------
// OnViewRefresh
//
//  Handles "View|Refresh" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnViewRefresh()
{
	CWaitCursor wait;
	CService * pService;

	m_wndList.SetRedraw(FALSE);

	// mark all items for delete now
	int nCount = m_wndList.GetItemCount();
	for (int nItem = 0; nItem < nCount; nItem++)
	{
		pService = GetService(nItem);
		_ASSERTE(pService != NULL);

		pService->m_bDelete = TRUE;
	}

	BYTE bBuffer[2048];
	DWORD dwResumeHandle = 0;
	DWORD cbNeeded;
	DWORD cServices;
	BOOL bContinue;
	BOOL bSomeFailed;
	HRESULT hRes;

	do
	{
		bContinue = FALSE;
		hRes = S_OK;

		LPENUM_SERVICE_STATUS pStatus = (LPENUM_SERVICE_STATUS)bBuffer;

		// retrieve a portion of service status information
		if (!EnumServicesStatus(m_hSCM, SERVICE_WIN32, SERVICE_STATE_ALL,
								pStatus, sizeof(bBuffer), &cbNeeded,
								&cServices, &dwResumeHandle))
		{
			hRes = GetLastError();

			if (hRes != ERROR_MORE_DATA)
			{
				_RPT_API_FAILED(EnumServicesStatus);
				hRes = HRESULT_FROM_WIN32(hRes);
			}

			bContinue = TRUE;
		}

		// put all the services retrieved into the list
		for (DWORD i = 0; i < cServices; i++)
		{
			// try to find the corresponding service object in the list
			nItem = FindServiceItem(pStatus->lpServiceName, &pService);
			if (nItem != -1)
			{
				_ASSERTE(pService != NULL);
				_ASSERTE(lstrcmpi(pService->m_szName, pStatus->lpServiceName) == 0);

				// an item already exists, just update the exiting item
				hRes = pService->Update(m_hSCM, pStatus);
				if (SUCCEEDED(hRes))
					UpdateServiceItem(nItem, pService);
			}
			else
			{
				// add a new list item
				hRes = AddServiceItem(pStatus);
			}

			if (FAILED(hRes))
			{
				bSomeFailed = TRUE;
				hRes = S_OK;
			}

			// proceed to the next service
			pStatus++;
		}
	}
	while (bContinue);

	// delete all items which are still marked for delete
	nCount = m_wndList.GetItemCount();
	for (nItem = nCount - 1; nItem >= 0; nItem--)
	{
		pService = GetService(nItem);
		_ASSERTE(pService != NULL);

		if (pService->m_bDelete)
			m_wndList.DeleteItem(nItem);
	}

	// sort list items
	m_wndList.SortItems(SortCallback, (LPARAM)this);
	m_wndList.SetRedraw(TRUE);

	// report a error to the user if it took place
	if (FAILED(hRes))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_ENUM_SERVICES_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), hRes);
	}

	OnList_ItemChanged(NULL);
}

//---------------------------------------------------------------------------
// OnViewProperties
//
//  Handles "View|Properties" menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnViewProperties()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	if (nSel == -1)
		return;

	CService * pService = GetService(nSel);
	_ASSERTE(pService != NULL);

	CPropCtx ctx;
	ctx.pMainWnd = this;
	ctx.pService = pService;
	ctx.bReadOnly = FALSE;
	ctx.bRefresh = FALSE;

	// create property pages
	CGeneralPage page0(&ctx);
	CAdvancedPage page1(&ctx);
	CRecoveryPage page2(&ctx);
	CDependenciesPage page3(&ctx);
	CSecurityPage page4; page4.SetContext(&ctx);
	CNoPermPage page5(&ctx);

    // create property sheet object
    CPropertySheet sheet(pService->m_szDisplayName);

	// try to open service handle with read-write access
	ctx.hService = OpenService(m_hSCM, pService->m_szName,
							   SERVICE_QUERY_CONFIG|SERVICE_CHANGE_CONFIG);
	if (ctx.hService == NULL &&
		GetLastError() == ERROR_ACCESS_DENIED)
	{
		// try to open service handlw with read-only access
		ctx.bReadOnly = TRUE;
		ctx.hService = OpenService(m_hSCM, pService->m_szName,
								   SERVICE_QUERY_CONFIG);
	}

	// if still failed, add only security page
	if (ctx.hService != NULL)
	{
		// add property pages
		sheet.AddPage(page0.Create());
		sheet.AddPage(page1.Create());

		if (m_dwMajorVersion >= 5 && _ChangeServiceConfig2 != NULL)
			sheet.AddPage(page2.Create());

		sheet.AddPage(page3.Create());
	}
	else if (GetLastError() == ERROR_ACCESS_DENIED)
	{
		sheet.AddPage(page5.Create());
	}

	sheet.AddPage(page4.Create());

    // show property sheet
	sheet.m_psh.dwFlags |= PSH_PROPTITLE;
    sheet.DoModal(m_hWnd);

	// close service handle
	if (ctx.hService != NULL)
		_VERIFY(CloseServiceHandle(ctx.hService));

	if (ctx.bRefresh)
		OnViewRefresh();
}

//---------------------------------------------------------------------------
// OnViewColumnX
//
//  Handles column selection menu commands.
//
//  Parameters:
//    wNotifyCode - command notification code
//    wID	      - command identifier
//    hWndCtrl	  - control window handle
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnViewColumnX(
    UINT wNotifyCode,
    int wID,
    HWND hWndCtrl
    )
{
    _UNUSED(wNotifyCode);
    _UNUSED(hWndCtrl);

	_ASSERTE(wID >= ID_VIEW_COLUMN_1 && wID <= ID_VIEW_COLUMN_9);

	int nCol = wID - ID_VIEW_COLUMN_0;
	DWORD dwMask = (1 << nCol);

	if (dwMask & m_dwColumnSet)
	{
		DeleteColumn(nCol);

		if (nCol == abs(m_nSortOrder) - 1)
		{
			do 
			{
				nCol--;
				dwMask >>= 1;
			}
			while ((dwMask & m_dwColumnSet) == 0);

			if (m_nSortOrder < 0)
				m_nSortOrder = -nCol - 1;
			else
				m_nSortOrder = nCol + 1;

			m_wndList.SortItems(SortCallback, (LPARAM)this);
			SetSortMark(m_nSortOrder);
		}

		UISetCheck(wID, 0);
	}
	else
	{
		int nPos = 1;
		while (dwMask != 1)
		{
			if (dwMask & m_dwColumnSet)
				nPos++;
			dwMask >>= 1;
		}

		InsertColumn(nCol, nPos);
		UISetCheck(wID, 1);

		// insert values into new column
		int nCount = m_wndList.GetItemCount();
		for (int nItem = 0; nItem < nCount; nItem++)
		{
			CService * pService = GetService(nItem);
			_ASSERTE(pService != NULL);

			UpdateServiceItem(nItem, pService);
		}
	}
}

//---------------------------------------------------------------------------
// OnHelpAbout
//
//  Handles "Help|About..." menu command.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::OnHelpAbout()
{
	CAboutDlg dlg;
	dlg.DoModal(m_hWnd);
}

//---------------------------------------------------------------------------
// LoadConfig
//
//  Loads program configuration from the registry.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::LoadConfig()
{
	CRegKey key;
	LONG lRes;
	int nCol;

	DWORD cbValue;

	// set defaults
	m_dwColumnSet = COLUMN_DEFAULT_SET;
	if (_QueryServiceConfig2 == NULL)
		m_dwColumnSet &= ~COLUMN_DESCRIPTION;

	for (nCol = 0; nCol < COLUMN_MAX; nCol++)
	{
		m_nColWidth[nCol] = LVSCW_AUTOSIZE_USEHEADER;
		m_nColOrder[nCol] = nCol;
	}
	m_nColWidth[0] = 200;
	m_nColWidth[1] = 300;
	m_nSortOrder = 1;

	int nBuffer[COLUMN_MAX];

	lRes = key.Open(HKEY_CURRENT_USER, _szSettings, KEY_READ);
	if (lRes == ERROR_SUCCESS)
	{
		// load column width array
		cbValue = sizeof(nBuffer);
		lRes = RegQueryValueEx(key, _T("ColumnWidth"), NULL, NULL,
							   (PBYTE)nBuffer, &cbValue);
		if (lRes == ERROR_SUCCESS && cbValue == sizeof(nBuffer))
			memcpy(m_nColWidth, nBuffer, sizeof(nBuffer));

		// load column order array
		cbValue = sizeof(nBuffer);
		lRes = RegQueryValueEx(key, _T("ColumnOrder"), NULL, NULL,
							   (PBYTE)nBuffer, &cbValue);
		if (lRes == ERROR_SUCCESS && cbValue == sizeof(nBuffer))
			memcpy(m_nColOrder, nBuffer, sizeof(nBuffer));

		// load column set
		lRes = key.QueryValue(m_dwColumnSet, _T("ColumnSet"));
		if (lRes != ERROR_SUCCESS)
			m_dwColumnSet = COLUMN_DEFAULT_SET;

		// load sort order
		lRes = key.QueryValue((DWORD&)m_nSortOrder, _T("SortOrder"));
		if (lRes != ERROR_SUCCESS)
			m_nSortOrder = 1;
	}
}

//---------------------------------------------------------------------------
// SaveConfig
//
//  Saves program configuration in the registry.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CMainWnd::SaveConfig()
{
	CRegKey key;
	LONG lRes;
	int nColCount;

	// get column order
	nColCount = m_wndList.GetHeader().GetItemCount();
	_VERIFY(m_wndList.GetColumnOrderArray(nColCount, m_nColOrder));

	// get window position
	WINDOWPLACEMENT wpl;
	wpl.length = sizeof(wpl);
	_VERIFY(GetWindowPlacement(&wpl));

	lRes = key.Create(HKEY_CURRENT_USER, _szSettings, NULL, 0,
					  KEY_READ|KEY_WRITE);
	if (lRes == ERROR_SUCCESS)
	{
		// save column width array
		RegSetValueEx(key, _T("ColumnWidth"), 0, REG_BINARY,
					  (PBYTE)m_nColWidth, sizeof(m_nColWidth));

		// save column order array
		RegSetValueEx(key, _T("ColumnOrder"), 0, REG_BINARY,
					  (PBYTE)m_nColOrder, sizeof(m_nColOrder));

		// save column set
		key.SetValue(m_dwColumnSet, _T("ColumnSet"));

		// save sort order
		key.SetValue(m_nSortOrder, _T("SortOrder"));

		// save window position
		key.SetValue(wpl.rcNormalPosition.left, _T("WindowLeft"));
		key.SetValue(wpl.rcNormalPosition.top, _T("WindowTop"));
		key.SetValue(wpl.rcNormalPosition.right, _T("WindowRight"));
		key.SetValue(wpl.rcNormalPosition.bottom, _T("WindowBottom"));
		key.SetValue(wpl.showCmd, _T("WindowState"));
	}
}

//---------------------------------------------------------------------------
// InsertColumn
//
//  Inserts a column into list.
//
//  Parameters:
//	  nColumn - logical column index
//	  nPos	  - physical column position
//
//  Returns:
//	  no return value.
//
void
CMainWnd::InsertColumn(
	int nColumn,
	int nPos
	)
{
	_ASSERTE(nColumn >= 0 && nColumn < COLUMN_MAX);
	_ASSERTE(nPos <= nColumn);

	TCHAR szColumn[80];

	// load column title
	_VERIFY(AtlLoadString(IDS_COLUMN_0 + nColumn, szColumn, 
						  countof(szColumn)));

	// insert column
	m_wndList.InsertColumn(nPos, szColumn, LVCFMT_LEFT, -1, nPos);

	m_wndList.SetColumnWidth(nPos, m_nColWidth[nColumn]);
	m_nColWidth[nColumn] = m_wndList.GetColumnWidth(nPos);

	m_dwColumnSet |= (1 << nColumn);
}

//---------------------------------------------------------------------------
// DeleteColumn
//
//  Deletes the specified column.
//
//  Parameters:
//	  nColumn - logical column index
//
//  Returns:
//    no return value.
//
void
CMainWnd::DeleteColumn(
	int nColumn
	)
{
	_ASSERTE(nColumn >= 0 && nColumn < COLUMN_MAX);

	int nPos = GetPhysicalColumn(nColumn);

	m_nColWidth[nColumn] = m_wndList.GetColumnWidth(nPos);
	m_wndList.DeleteColumn(nPos);

	m_dwColumnSet &= ~(1 << nColumn);
}

//---------------------------------------------------------------------------
// GetLogicalColumn
//
//  Returns logical column index given its physical position.
//
//  Parameters:
//	  nPos - physical column index
//
//  Returns:
//	  logical column index.
//
int
CMainWnd::GetLogicalColumn(
	int nPos
	)
{
	_ASSERTE(nPos >= 0 && nPos < COLUMN_MAX);

	int nColumn = 0;
	DWORD dwMask = 1;

	while (nPos >= 0)
	{
		if (dwMask & m_dwColumnSet)
			nPos--;

		nColumn++;
		dwMask <<= 1;

		_ASSERTE(dwMask != 0);
	}

	_ASSERTE(nColumn <= COLUMN_MAX);
	return nColumn - 1;
}

//---------------------------------------------------------------------------
// GetPhysicalColumn
//
//  Returns physical column index given its logical index.
//
//  Parameters:
//	  nColumn - logical column index
//
//  Returns:
//	  physical column index.
//
int
CMainWnd::GetPhysicalColumn(
	int nColumn
	)
{
	_ASSERTE(nColumn >= 0 && nColumn < COLUMN_MAX);

	int nPos = 0;
	DWORD dwMask = 1 << nColumn;

	while (dwMask != 1)
	{
		if (dwMask & m_dwColumnSet)
			nPos++;
		dwMask >>= 1;
	}

	_ASSERTE(nPos >= 0 && nPos <= nColumn);
	return nPos;
}

//---------------------------------------------------------------------------
// SetSortMark
//
//  Sets the sort mark in the list control.
//
//  Parameters:
//	  nOrder - sort order
//
//  Returns:
//	  no return value.
//
void 
CMainWnd::SetSortMark(
	int nOrder
	)
{
	int nSubItem = GetPhysicalColumn(abs(nOrder) - 1);

	CHeaderCtrl hdr = m_wndList.GetHeader();

	int nCount = hdr.GetItemCount();
	for (int i = 0; i < nCount; i++)
	{
		HDITEM hdi;
		hdi.mask = HDI_FORMAT;

		_VERIFY(hdr.GetItem(i, &hdi));

		if (i != nSubItem)
		{
			hdi.fmt &= ~(HDF_BITMAP|HDF_BITMAP_ON_RIGHT);
		}
		else
		{
			hdi.mask |= HDI_BITMAP;
			hdi.fmt |= HDF_BITMAP|HDF_BITMAP_ON_RIGHT;
			hdi.hbm = (nOrder > 0) ? m_bmSortDown : m_bmSortUp;
		}

		_VERIFY(hdr.SetItem(i, &hdi));
	}
}

//---------------------------------------------------------------------------
// DoConnect
//
//  Establishes connection with the specified machine.
//
//  Parameters:
//	  pszMachine  - machine name
//	  pszUserName - user name
//	  pszPassword - password
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
BOOL
CMainWnd::DoConnect(
	PCTSTR pszMachine,
	PCTSTR pszUserName,
	PCTSTR pszPassword
	)
{
	DWORD dwError = ERROR_SUCCESS;
	SC_HANDLE hSCM = NULL;

	CWaitCursor wait;

	// if connecting to the same machine, first close existing connection;
	// otherwise, keep existing connection until we establish a new one
	if (lstrcmpi(m_szMachine, pszMachine) == 0)
	{
		if (m_hSCM != NULL)
			_VERIFY(CloseServiceHandle(m_hSCM));
		m_hSCM = NULL;
	}

	if (pszMachine != NULL && pszUserName != NULL)
	{
		_ASSERTE(pszPassword != NULL);

		NETRESOURCE NetRes;
		TCHAR szRemoteName[RMLEN + 1];

		FormatString(szRemoteName, RMLEN + 1, _T("%1\\IPC$"), pszMachine);

		NetRes.dwType = RESOURCETYPE_ANY;
		NetRes.lpLocalName = NULL;
		NetRes.lpRemoteName = szRemoteName;
		NetRes.lpProvider = NULL;

		// try to connect to the IPC$ resource on the remote machine
		dwError = WNetAddConnection2(&NetRes, pszPassword, pszUserName, 0);
	}

	if (dwError == ERROR_SUCCESS)
	{
		hSCM = OpenSCManager(pszMachine, NULL, 
							 SC_MANAGER_CONNECT|SC_MANAGER_ENUMERATE_SERVICE);
		if (hSCM == NULL)
			dwError = GetLastError();
	}

	if (dwError != ERROR_SUCCESS)
	{
		UINT nMessage;
		if (pszMachine == NULL)
			nMessage = IDP_LOCAL_CONNECT_FAILED;
		else
			nMessage = IDP_CONNECT_FAILED;

		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(nMessage),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), dwError,
				 pszMachine);

		return FALSE;
	}

	if (m_hSCM != NULL)
		_VERIFY(CloseServiceHandle(m_hSCM));
	m_hSCM = hSCM;

	UIEnable(ID_VIEW_REFRESH, TRUE);

	TCHAR szMachine[256];
	TCHAR szTitle[512];

	if (pszMachine != NULL)
	{
		USES_CONVERSION;
		lstrcpyn(m_szMachine, pszMachine, countof(m_szMachine));

		PWKSTA_INFO_100 pWkstaInfo;
		
		dwError = NetWkstaGetInfo((PWSTR)T2CW(pszMachine), 100, 
								   (PBYTE *)&pWkstaInfo);
		if (dwError == ERROR_SUCCESS)
		{
			m_dwMajorVersion = pWkstaInfo->wki100_ver_major;
			m_dwMinorVersion = pWkstaInfo->wki100_ver_minor;

			NetApiBufferFree(pWkstaInfo);
		}
		else
		{
			m_dwMajorVersion = 4;
			m_dwMinorVersion = 0;

			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_REMOTE_VERSION_FAILED),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0,
					 pszMachine);
		}
	}
	else
	{
		m_szMachine[0] = 0;
		m_dwMajorVersion = _osvi.dwMajorVersion;
		m_dwMinorVersion = _osvi.dwMinorVersion;

		AtlLoadString(IDS_LOCAL_MACHINE, szMachine, countof(szMachine));
		pszMachine = szMachine;
	}

	FormatString(szTitle, countof(szTitle), MAKEINTRESOURCE(IDS_TITLE),
				 pszMachine);

	SetWindowText(szTitle);
	return TRUE;
}

//---------------------------------------------------------------------------
// DoStartService
//
//  Starts the specified service.
//
//  Parameters:
//	  pService - service to start
//	  nArgc	   - number of service arguments
//	  pArgv	   - vector of service arguments
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
BOOL
CMainWnd::DoStartService(
	CService * pService,
	int nArgc,
	PCWSTR * pArgv
	)
{
	_ASSERTE(pService != NULL);

	CStartStopDlg dlgStart(this);

	// find list of services to be started
	PCTSTR pszList = dlgStart.GetAffectedList(pService, FALSE);
	if (pszList == NULL)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_START_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
				 ERROR_NOT_ENOUGH_MEMORY, pService->m_szDisplayName);
		return FALSE;
	}

	PCTSTR psz;
	if (*pszList != 0)
		psz = pszList + lstrlen(pszList) + 1;
	else
		psz = pszList;

	if (*psz != 0)
	{
		// display the list of services which will be also started
		if (dlgStart.DoModal(m_hWnd) != IDOK)
			return FALSE;
	}

	CProgressDlg dlgProgress(this);
	dlgProgress.Create(m_hWnd);
	dlgProgress.ShowWindow(SW_SHOW);

	// simulate modal operation
	EnableWindow(FALSE);

	TCHAR szDisplayName[256];
	DWORD cchName;
	DWORD dwError = ERROR_SUCCESS;
	PTSTR pszDisplayName = szDisplayName;

	// start each service in the list
	while (*psz != 0)
	{
		// get service display name
		cchName = countof(szDisplayName);
		GetServiceDisplayName(m_hSCM, pszList, szDisplayName, &cchName);

		// start the service asynchronously while displaying progress
		dwError = dlgProgress.DoStartService(pszList, szDisplayName, 
											 0, NULL);
		if (dwError != ERROR_SUCCESS)
			break;

		pszList = psz;
		psz += lstrlen(psz) + 1;
	}

	// finally start the requested service, supplying service arguments
	if (dwError == ERROR_SUCCESS)
	{
		pszDisplayName = pService->m_szDisplayName;

		// start the service asynchronously while displaying progress
		dwError = dlgProgress.DoStartService(pService->m_szName, 
											 pszDisplayName, nArgc, pArgv);
	}

	EnableWindow(TRUE);
	dlgProgress.DestroyWindow();

	switch (dwError)
	{
		case ERROR_SERVICE_SPECIFIC_ERROR:
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_START_FAILED_SPECIFIC),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0,
					 pszDisplayName, dlgProgress.GetServiceSpecificError());
			break;

		case ERROR_SUCCESS:
		case ERROR_OPERATION_ABORTED:
			break;

		default:
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_START_FAILED),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
					 dwError, pszDisplayName);
			break;
	}

	OnViewRefresh();
	return *pszList == 0;
}

//---------------------------------------------------------------------------
// DoStopService
//
//  Stops the specified service.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
BOOL
CMainWnd::DoStopService(
	CService * pService
	)
{
	_ASSERTE(pService != NULL);

	CStartStopDlg dlgStop(this);

	// find list of services to be started
	PCTSTR pszList = dlgStop.GetAffectedList(pService, TRUE);
	if (pszList == NULL)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_STOP_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
				 ERROR_NOT_ENOUGH_MEMORY, pService->m_szDisplayName);
		return FALSE;
	}

	if (*pszList != 0 && pszList[lstrlen(pszList) + 1] != 0)
	{
		// display the list of services which will be also started
		if (dlgStop.DoModal(m_hWnd) != IDOK)
			return FALSE;
	}

	CProgressDlg dlgProgress(this);
	dlgProgress.Create(m_hWnd);
	dlgProgress.ShowWindow(SW_SHOW);

	// simulate modal operation
	EnableWindow(FALSE);

	TCHAR szDisplayName[256];
	DWORD cchName;
	DWORD dwError = ERROR_SUCCESS;

	// stop each service in the list
	while (*pszList != 0)
	{
		// get service display name
		cchName = countof(szDisplayName);
		GetServiceDisplayName(m_hSCM, pszList, szDisplayName, &cchName);

		// stop the service asynchronously while displaying progress
		dwError = dlgProgress.DoStopService(pszList, szDisplayName);
		if (dwError != ERROR_SUCCESS)
			break;

		pszList += lstrlen(pszList) + 1;
	}

	EnableWindow(TRUE);
	dlgProgress.DestroyWindow();

	switch (dwError)
	{
		case ERROR_SERVICE_SPECIFIC_ERROR:
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_STOP_FAILED_SPECIFIC),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0,
					 szDisplayName, dlgProgress.GetServiceSpecificError());
			break;

		case ERROR_SUCCESS:
		case ERROR_OPERATION_ABORTED:
			break;

		default:
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_STOP_FAILED),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
					 dwError, szDisplayName);
			break;
	}

	OnViewRefresh();
	return *pszList == 0;
}

//---------------------------------------------------------------------------
// FindServiceItem
//
//  Finds a list item that corresponds to the specified service name.
//
//  Parameters:
//	  pszName   - service name
//	  ppService - pointer to a variable that receives a pointer to the
//				  corresponding service object (the reference counter of
//				  the object is not incremented)
//
//  Returns:
//	  item index, if the item was found, or -1 - otherwise.
//
int
CMainWnd::FindServiceItem(
	PCTSTR pszName,
	CService ** ppService
	)
{
	_ASSERTE(pszName != NULL);
	_ASSERTE(ppService != NULL);

	int nCount = m_wndList.GetItemCount();
	for (int nItem = 0; nItem < nCount; nItem++)
	{
		CService * pService = GetService(nItem);
		_ASSERTE(pService != NULL);

		if (lstrcmpi(pService->m_szName, pszName) == 0)
		{
			*ppService = pService;
			return nItem;
		}
	}

	*ppService = NULL;
	return -1;
}

//---------------------------------------------------------------------------
// AddsServiceItem
//
//  Adds an item for the specified service.
//
//  Parameters:
//	  pStatus - pointer to a structure describing the service
//
//  Returns:
//	  standard COM return code.
//
HRESULT
CMainWnd::AddServiceItem(
	LPENUM_SERVICE_STATUS pStatus
	)
{
	_ASSERTE(pStatus != NULL);

	CService * pService;
	int nItem;

	// create a new CService object
	pService = new CService;
	if (pService == NULL)
		return E_OUTOFMEMORY;

	// initialize the service object
	pService->Init(m_hSCM, pStatus);

	DWORD dwMask = 1;

	LVITEM lvi;
	lvi.iItem = 0;
	lvi.iSubItem = 0;
	lvi.mask = LVIF_TEXT|LVIF_IMAGE|LVIF_PARAM;
	lvi.pszText = pService->m_szDisplayName;
	lvi.iImage = 0;
	lvi.lParam = (LPARAM)pService;

	// insert a corresponding item into the list view
	nItem = m_wndList.InsertItem(&lvi);
	if (nItem == -1)
	{
		delete pService;
		return E_OUTOFMEMORY;
	}

	lvi.iItem = nItem;
	lvi.mask = LVIF_TEXT;

	// set service description
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = pService->m_pszDescription;
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service status
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = (PTSTR)GetStateString(pService->m_dwCurrentState);
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service start type
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = (PTSTR)GetStartupTypeString(pService->m_dwStartupType);
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service error control
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = (PTSTR)GetErrorControlString(pService->m_dwErrorControl);
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service process type
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = (PTSTR)GetProcessString(pService->m_dwServiceType);
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service logon account
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = pService->m_szLogon;
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service interactive status
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = (PTSTR)GetInteractiveString(pService->m_dwServiceType);
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service load order group
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = pService->m_szLoadGroup;
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service image path
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = pService->m_szImagePath;
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	return S_OK;
}

//---------------------------------------------------------------------------
// UpdateServiceItem
//
//  Updates the item corresponding to the specified service.
//
//  Parameters:
//	  nItem    - item index
//	  pService - service object
//
//  Returns:
//	  no return value.
//
void
CMainWnd::UpdateServiceItem(
	int nItem,
	CService * pService
	)
{
	_ASSERTE(nItem != -1);
	_ASSERTE(pService != NULL);
	_ASSERTE(pService == GetService(nItem));

	TCHAR szText[256];
	DWORD dwMask = 1;

	LVITEM lvi;
	lvi.iItem = nItem;
	lvi.mask = LVIF_TEXT;
	lvi.cchTextMax = countof(szText);

	// check service display name
	lvi.iSubItem = 0;
	lvi.pszText = szText;
	_VERIFY(m_wndList.GetItem(&lvi));

	lvi.pszText = pService->m_szDisplayName;
	if (lstrcmp(lvi.pszText, szText) != 0)
		_VERIFY(m_wndList.SetItem(&lvi));

	// check service description
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = pService->m_pszDescription;
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}

	// check service status
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = (PTSTR)GetStateString(pService->m_dwCurrentState);
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service start type
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = (PTSTR)GetStartupTypeString(pService->m_dwStartupType);
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service error control
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = (PTSTR)GetErrorControlString(pService->m_dwErrorControl);
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service process type
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = (PTSTR)GetProcessString(pService->m_dwServiceType);
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service logon account
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = pService->m_szLogon;
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service interactive status
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = (PTSTR)GetInteractiveString(pService->m_dwServiceType);
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service load order group
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = pService->m_szLoadGroup;
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}

	// set service image path
	dwMask <<= 1;
	if (dwMask & m_dwColumnSet)
	{
		lvi.iSubItem++;
		lvi.pszText = szText;
		_VERIFY(m_wndList.GetItem(&lvi));

		lvi.pszText = pService->m_szImagePath;
		if (lstrcmp(lvi.pszText, szText) != 0)
			_VERIFY(m_wndList.SetItem(&lvi));
	}
}

//---------------------------------------------------------------------------
// SortCallback
//
//  This function is called to compare list view items during the sort
//	process.
//
//  Parameters:
//	  lParam1    - data associated with the first item
//	  lParam2    - data associated with the second item
//	  lParamSort - contains a pointer to the CSortData structure.
//
//  Returns:
//	  less than zero, if the first item is less than the second;
//	  greater than zero, if the first item is greater than the second;
//	  zero, if the items are equal.
//
int
CALLBACK
CMainWnd::SortCallback(
	LPARAM lParam1,
	LPARAM lParam2,
	LPARAM lParamSort
	)
{
	CService * pData1 = (CService *)lParam1;
	CService * pData2 = (CService *)lParam2;
	CMainWnd * pThis = (CMainWnd *)lParamSort;

	int nOrder = pThis->m_nSortOrder; 
	int nColumn = abs(nOrder) - 1;
	PCTSTR psz1, psz2;

	switch (nColumn)
	{
		case COLUMN_DISPLAY_NAME:
			psz1 = pData1->m_szDisplayName;
			psz2 = pData2->m_szDisplayName;
			break;
		case COLUMN_DESCRIPTION:
			psz1 = pData1->m_pszDescription;
			psz2 = pData2->m_pszDescription;
			break;
		case COLUMN_STATUS:
			psz1 = pThis->GetStateString(pData1->m_dwCurrentState);
			psz2 = pThis->GetStateString(pData2->m_dwCurrentState);
			break;
		case COLUMN_STARTUP_TYPE:
			psz1 = pThis->GetStartupTypeString(pData1->m_dwStartupType);
			psz2 = pThis->GetStartupTypeString(pData2->m_dwStartupType);
			break;
		case COLUMN_ERROR_CONTROL:
			psz1 = pThis->GetErrorControlString(pData1->m_dwErrorControl);
			psz2 = pThis->GetErrorControlString(pData2->m_dwErrorControl);
			break;
		case COLUMN_PROCESS:
			psz1 = pThis->GetProcessString(pData1->m_dwServiceType);
			psz2 = pThis->GetProcessString(pData2->m_dwServiceType);
			break;
		case COLUMN_LOGON_AS:
			psz1 = pData1->m_szLogon;
			psz2 = pData2->m_szLogon;
			break;
		case COLUMN_INTERACTIVE:
			psz1 = pThis->GetInteractiveString(pData1->m_dwServiceType);
			psz2 = pThis->GetInteractiveString(pData2->m_dwServiceType);
			break;
		case COLUMN_LOAD_ORDER:
			psz1 = pData1->m_szLoadGroup;
			psz2 = pData2->m_szLoadGroup;
			break;
		case COLUMN_IMAGE_PATH:
			psz1 = pData1->m_szImagePath;
			psz2 = pData2->m_szImagePath;
			break;
		default:
			_ASSERTE(0);
			__assume(0);
	}

	int nRes = lstrcmp(psz1, psz2);
	if (nRes == 0 && nColumn != 0)
		nRes = lstrcmp(pData1->m_szDisplayName, pData2->m_szDisplayName);

	return nOrder * nRes;
}
