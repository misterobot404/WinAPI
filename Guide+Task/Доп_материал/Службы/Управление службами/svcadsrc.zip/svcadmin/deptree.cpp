// deptree.cpp
//
// Service dependency tree.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "deptree.h"
#include "mainwnd.h"
#include "svcobj.h"
#include "errorbox.h"

//---------------------------------------------------------------------------
// OnActivate
//
//  Handles WM_ACTIVATE message. Centers the window which is about to pop
//  above this window.
//
//  Parameters:
//    fuActive   - specifies whether the window is being activated or 
//				   deactivated
//    bMinimized - specifies whether the window is minimized
//	  hWndOther  - other window which is activated or deactivated
//
//  Returns:
//    no return value.
//
void
CAddDepDlg::OnActivate(
	UINT fuActive,
	BOOL bMinimized,
	HWND hWndOther
    )
{
    _UNUSED(bMinimized);

    if (fuActive == WA_INACTIVE && hWndOther != NULL)
	{
		CWindow wndActive(hWndOther);
		if (wndActive.GetParent() == m_hWnd)
			wndActive.CenterWindow(m_hWnd);
	}
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes dialog controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CAddDepDlg::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	CComboBox wndServices(GetDlgItem(IDC_SERVICES_LIST));
	CComboBox wndGroups(GetDlgItem(IDC_GROUPS_LIST));

	if (m_pszDep == NULL)
		m_pszDep = _T("\0");

	// fill services list
	int nCount = m_pMainWnd->GetServicesCount();
	for (int i = 0; i < nCount; i++)
	{
		CService * pService = m_pMainWnd->GetService(i);
		_ASSERTE(pService != NULL);

		PCTSTR psz = m_pszDep;
		while (*psz != 0)
		{
			if (lstrcmpi(psz, pService->m_szName) == 0)
				break;

			psz += lstrlen(psz) + 1;
		}

		if (*psz == 0)
			wndServices.AddString(pService->m_szDisplayName);
	}

	wndServices.SetCurSel(0);

	// fill load order groups combo box
	FillLoadOrderGroupCombo(wndGroups, m_pMainWnd->GetMachineName());

	// delete those groups which this service already depends on
	PCTSTR psz = m_pszDep;
	while (*psz != 0)
	{
		if (*psz == SC_GROUP_IDENTIFIER)
		{
			int nItem = wndGroups.FindStringExact(-1, psz + 1);
			if (nItem != -1)
				wndGroups.DeleteString(nItem);
		}
		psz += lstrlen(psz) + 1;
	}

	if (wndGroups.GetCount() > 0)
		wndGroups.SetCurSel(0);
	_VERIFY(EnableDlgItem(IDC_GROUP, wndGroups.GetCount() > 0));

	// start from service selection
	CheckRadioButton(IDC_SERVICE, IDC_GROUP, IDC_SERVICE);
	wndGroups.EnableWindow(FALSE);

	return TRUE;
}

//---------------------------------------------------------------------------
// OnOK
//
//  Handles "OK" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CAddDepDlg::OnOK()
{
	m_bGroup = IsDlgButtonChecked(IDC_GROUP);

	UINT nCtrl = m_bGroup ? IDC_GROUPS_LIST : IDC_SERVICES_LIST;

	GetDlgItemText(nCtrl, m_szName, countof(m_szName));
	EndDialog(IDOK);
}

//---------------------------------------------------------------------------
// OnOption
//
//  Handles option buttons.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value
//
void
CAddDepDlg::OnOption()
{
	EnableDlgItem(IDC_SERVICES_LIST, IsDlgButtonChecked(IDC_SERVICE));
	EnableDlgItem(IDC_GROUPS_LIST, IsDlgButtonChecked(IDC_GROUP));
}

//---------------------------------------------------------------------------
// SetRootDependencyInfo
//
//  Sets root dependency information.
//
//  Parameters:
//	  pszDeps - pointer to the null-separated list of dependencies
//
//  Returns:
//	  no return value.
//
void
CDepTree::SetRootDependencyInfo(
	PCTSTR pszDeps
	)
{
	_ASSERTE(pszDeps != NULL);

	if (InsertDependencies(pszDeps, TVI_ROOT) == 0)
	{
		TCHAR szText[80];
		AtlLoadString(IDS_NO_DEPENDENCIES, szText, countof(szText));
		_Base::InsertItem(szText, 2, 2, TVI_ROOT, TVI_LAST);
	}
}

//---------------------------------------------------------------------------
// GetRootDependencyInfo
//
//  Returns root dependency information.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  pointer to the null-separated list of dependencies; the caller should
//	  deallocate the list using free() function.
//
PTSTR
CDepTree::GetRootDependencyInfo()
{
	SC_HANDLE hSCM = m_pMainWnd->m_hSCM;
	_ASSERTE(hSCM != NULL);

	UINT cbAlloc = 256;
	PTSTR pszDep = (PTSTR)malloc(cbAlloc);
	UINT nPos = 0;

	if (pszDep == NULL)
		return NULL;

	TCHAR szItem[256];
	TCHAR szService[256];

	HTREEITEM hItem = _Base::GetChildItem(TVI_ROOT);
	while (hItem != NULL)
	{
		szItem[0] = SC_GROUP_IDENTIFIER;

		TVITEM tvi;
		tvi.hItem = hItem;
		tvi.mask = LVIF_TEXT|LVIF_PARAM;
		tvi.pszText = szItem + 1;
		tvi.cchTextMax = countof(szItem) - 1;

		_VERIFY(_Base::GetItem(&tvi));

		PCTSTR psz = NULL;
		if (tvi.lParam == 1)
		{
			psz = szItem;
		}
		else if (tvi.lParam != 0)
		{
			DWORD cchService = countof(szService);
			GetServiceKeyName(hSCM, szItem + 1, szService, &cchService);
			psz = szService;
		}

		if (psz != NULL)
		{
			UINT cch = lstrlen(psz) + 1;
			if (nPos + cch > cbAlloc)
			{
				PVOID p = realloc(pszDep, cbAlloc + 256);
				if (p == NULL)
				{
					free(pszDep);
					return NULL;
				}

				pszDep = (PTSTR)p;
				cbAlloc += 256;
			}

			lstrcpy(pszDep + nPos, psz);
			nPos += cch;
		}

		hItem = _Base::GetNextSiblingItem(hItem);
	}

	pszDep[nPos] = 0;
	return pszDep;
}

//---------------------------------------------------------------------------
// AddDependency
//
//  Invokes Add Dependency dialog.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, if a dependency was added, FALSE - otherwise.
//
BOOL
CDepTree::AddDependency()
{
	CAddDepDlg dlgAdd;
	dlgAdd.m_pMainWnd = m_pMainWnd;
	dlgAdd.m_pszDep = GetRootDependencyInfo();

	if (dlgAdd.m_pszDep == NULL)
	{
		ErrorBox(GetParent(), _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_ADDDEP_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
				 ERROR_NOT_ENOUGH_MEMORY);
		return FALSE;
	}

	BOOL bDummyItem = *dlgAdd.m_pszDep == 0;
	int nRet = dlgAdd.DoModal();

	free((PTSTR)dlgAdd.m_pszDep);

	if (nRet != IDOK)
		return FALSE;

	// delete the dummy "no dependencies" item
	if (bDummyItem)
		_Base::DeleteItem(_Base::GetChildItem(TVI_ROOT));

	DWORD dwFlag = dlgAdd.m_bGroup ? ISI_GROUP : ISI_DISPLAY_NAME;
	InsertServiceItem(dlgAdd.m_szName, TVI_ROOT, dwFlag);

	return TRUE;
}

//---------------------------------------------------------------------------
// RemoveDependency
//
//  Removes the currently selected dependency.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, if other dependencies are present, FALSE - otherwise.
//
BOOL
CDepTree::RemoveDependency()
{
	HTREEITEM hItem = _Base::GetSelectedItem();
	_ASSERTE(hItem != NULL);

	HTREEITEM hNext = _Base::GetNextSiblingItem(hItem);
	if (hNext == NULL)
		hNext = _Base::GetPrevSiblingItem(hItem);

	_Base::DeleteItem(hItem);

	if (hNext != NULL)
	{
		_Base::SetItemState(hNext, TVIS_SELECTED, TVIS_SELECTED);
		return TRUE;
	}

	TCHAR szText[80];
	AtlLoadString(IDS_NO_DEPENDENCIES, szText, countof(szText));
	_Base::InsertItem(szText, 2, 2, TVI_ROOT, TVI_LAST);

	return FALSE;
}

//---------------------------------------------------------------------------
// OnDeleteItem
//
//  Handles TVN_DELETEITEM notification. Frees any memory associated with
//  the item being deleted.
//
//  Parameters:
//	  pNMHDR  - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CDepTree::OnDeleteItem(
    LPNMHDR pNMHDR
    )
{
	NMTREEVIEW * pnmtv = (NMTREEVIEW *)pNMHDR;
	_ASSERTE(pnmtv != NULL);

	LPARAM lParam = pnmtv->itemOld.lParam;

	if (lParam == 0 || lParam == 1)
		return 0;

	free((PVOID)lParam);
	return 0;
}

//---------------------------------------------------------------------------
// OnGetDispInfo
//
//  Handles TVN_GETDISPINFO notification. Returns the number of children for
//  the items.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CDepTree::OnGetDispInfo(
    LPNMHDR pNMHDR
    )
{
	NMTVDISPINFO * pnmtvdi = (NMTVDISPINFO *)pNMHDR;
	_ASSERTE(pnmtvdi != NULL);

	pnmtvdi->item.cChildren = 0;

	LPARAM lParam = pnmtvdi->item.lParam;
	if (lParam == 0)
		return 0;

	if (lParam != 1)
	{
		PTSTR pszDep = ((LPQUERY_SERVICE_CONFIG)lParam)->lpDependencies;
		if (pszDep == NULL || *pszDep == 0)
			return 0;
	}

	pnmtvdi->item.cChildren = 1;
	return 0;
}

//---------------------------------------------------------------------------
// OnItemExpanding
//
//  Handles TVN_ITEMEXPANDING notification. Inserts children items as needed.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CDepTree::OnItemExpanding(
    LPNMHDR pNMHDR
    )
{
	NMTREEVIEW * pnmtv = (NMTREEVIEW *)pNMHDR;
	_ASSERTE(pnmtv != NULL);

	if (pnmtv->action != TVE_EXPAND)
		return 0;

	if (pnmtv->itemNew.state & TVIS_EXPANDEDONCE)
		return 0;
	
	LPARAM lParam = pnmtv->itemNew.lParam;
	if (lParam == 0)
		return 0;

	TVITEM tvi;
	tvi.hItem = pnmtv->itemNew.hItem;

	if (lParam != 1)
	{
		PCTSTR pszDep = ((LPQUERY_SERVICE_CONFIG)lParam)->lpDependencies;
		tvi.cChildren = InsertDependencies(pszDep, tvi.hItem);
	}
	else
	{
		TCHAR szGroup[256];
		
		tvi.mask = TVIF_TEXT;
		tvi.pszText = szGroup;
		tvi.cchTextMax = countof(szGroup);

		_VERIFY(_Base::GetItem(&tvi));

		tvi.cChildren = 0;

		int nCount = m_pMainWnd->GetServicesCount();
		for (int i = 0; i < nCount; i++)
		{
			CService * pService = m_pMainWnd->GetService(i);
			_ASSERTE(pService != NULL);

			if (lstrcmpi(pService->m_szLoadGroup, szGroup) == 0)
			{
				InsertServiceItem(pService->m_szName, tvi.hItem, 
								  ISI_SERVICE);
				tvi.cChildren++;
			}
		}
	}

	tvi.mask = TVIF_CHILDREN|TVIF_STATE;
	tvi.state = TVIS_EXPANDEDONCE;
	tvi.stateMask = TVIS_EXPANDEDONCE;

	_VERIFY(_Base::SetItem(&tvi));
	return 0;
}

//---------------------------------------------------------------------------
// InsertDependencies
//
//  Inserts dependencies under the specified tree view item.
//
//  Parameters:
//    pszDep  - dependencies list
//	  hParent - parent item
//
//  Returns:
//	  the number of dependencies inserted.
//
UINT
CDepTree::InsertDependencies(
	PCTSTR pszDep,
	HTREEITEM hParent
	)
{
	_ASSERTE(hParent != NULL);

	if (pszDep == NULL || *pszDep == 0)
		return 0;

	CWaitCursor wait;

	PCTSTR pszService;
	UINT cInserted = 0;

	while (*pszDep != 0)
	{
		pszService = pszDep;
		pszDep += lstrlen(pszDep) + 1;

		if (*pszService == SC_GROUP_IDENTIFIER)
		{
			if (!InsertServiceItem(pszService + 1, hParent, ISI_GROUP))
				continue;
		}
		else
		{
			if (!InsertServiceItem(pszService, hParent, ISI_SERVICE))
				continue;
		}

		cInserted++;
	}

	return cInserted;
}

//---------------------------------------------------------------------------
// InsertServiceItem
//
//  Insert a service or group into the list of dependencies.
//
//  Parameters:
//	  pszService - service or group name
//	  hParent	 - parent item
//	  dwFlags    - flags
//
//  Returns:
//	  TRUE, if successful, FALSE - otherwise.
//
BOOL
CDepTree::InsertServiceItem(
	PCTSTR pszService,
	HTREEITEM hParent,
	DWORD dwFlags
	)
{
	SC_HANDLE hSCM = m_pMainWnd->m_hSCM;
	_ASSERTE(hSCM != NULL);

	TVINSERTSTRUCT tvis;
	tvis.hParent = hParent;
	tvis.hInsertAfter = TVI_SORT;
	tvis.item.mask = TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE|
					 TVIF_PARAM|TVIF_CHILDREN;
	tvis.item.cChildren = I_CHILDRENCALLBACK;

	TCHAR szService[256];

	if (dwFlags == ISI_GROUP)
	{
		tvis.item.iImage = 1;
		tvis.item.iSelectedImage = 1;
		tvis.item.pszText = (PTSTR)pszService;
		tvis.item.lParam = 1;
	}
	else
	{
		if (dwFlags == ISI_DISPLAY_NAME)
		{
			DWORD cchService = countof(szService);
			szService[0] = 0;
		
			// when connected to NT4 computer, this call returns failure
			// but still retrieves the correct service key name
			GetServiceKeyName(hSCM, pszService, szService, &cchService);

			if (szService[0] == 0)
				return FALSE;

			pszService = szService;
		}

		SC_HANDLE hService;
		DWORD cbNeeded;
		LPQUERY_SERVICE_CONFIG pConfig;
		DWORD dwError;

		hService = OpenService(hSCM, pszService, SERVICE_QUERY_CONFIG);
		if (hService == NULL)
			return FALSE;

		if (!QueryServiceConfig(hService, NULL, 0, &cbNeeded))
		{
			dwError = GetLastError();

			if (dwError != ERROR_INSUFFICIENT_BUFFER)
			{
				_VERIFY(CloseServiceHandle(hService));
				return FALSE;
			}
		}

		pConfig = (LPQUERY_SERVICE_CONFIG)malloc(cbNeeded);
		if (pConfig == NULL)
		{
			_VERIFY(CloseServiceHandle(hService));
			return FALSE;
		}

		if (!QueryServiceConfig(hService, pConfig, cbNeeded, &cbNeeded))
		{
			free(pConfig);
			_VERIFY(CloseServiceHandle(hService));
			return FALSE;
		}

		tvis.item.iImage = 0;
		tvis.item.iSelectedImage = 0;
		tvis.item.pszText = pConfig->lpDisplayName;
		tvis.item.lParam = (LPARAM)pConfig;
	}

	_VERIFY(_Base::InsertItem(&tvis));
	return TRUE;
}
