// svcobj.h
//
// Service object.
//
// $Id: $
//

#ifndef __svcobj_h_included
#define __svcobj_h_included

#define SERVICE_INVALID_VALUE		0xFFFFFFFF

class CService
{
  public:

	CService()
		{ memset(this, 0, sizeof(*this)); 
	      m_pszDescription = (PTSTR)&_chNil; }

	~CService()
		{ if (m_pActions != NULL) free(m_pActions);	
		  if (m_pszDescription != (PTSTR)&_chNil) free(m_pszDescription); }

	typedef LPSERVICE_FAILURE_ACTIONS	PSFA;
	typedef LPSERVICE_DESCRIPTION		PSD;

	// public data
	TCHAR		m_szName[256];				// service name
	TCHAR		m_szDisplayName[256];		// service display name
	PTSTR		m_pszDescription;			// service description
	TCHAR		m_szLoadGroup[256];			// load order group
	TCHAR		m_szImagePath[MAX_PATH];	// executable path
	TCHAR		m_szLogon[DNLEN+UNLEN+2];	// logon account
	DWORD		m_dwCurrentState;			// current state
	DWORD		m_dwControlsAccepted;		// controls accepted
	DWORD		m_dwStartupType;			// startup type
	DWORD		m_dwServiceType;			// service type
	DWORD		m_dwErrorControl;			// error control
	BYTE		m_bLocalSystem;				// local system account
	BYTE		m_bLocalService;			// local service account
	BYTE		m_bNetworkService;			// network service account
	BYTE		m_bDelete;					// marked for delete
	PSFA		m_pActions;					// failure actions

  public:

	HRESULT Init(SC_HANDLE hSCM, LPENUM_SERVICE_STATUS pStatus);
	HRESULT Update(SC_HANDLE hSCM, LPENUM_SERVICE_STATUS pStatus);

  protected:

	// helper functions
	HRESULT QueryConfig(SC_HANDLE hService);
	HRESULT QueryDescription(SC_HANDLE hService);
	HRESULT QueryFailureActions(SC_HANDLE hService);

};

#endif // __svcobj_h_included
