// errorbox.cpp
//
// Implementation of the ErrorBox and ErrorBoxV functions.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "errorbox.h"

//---------------------------------------------------------------------------
// ErrorBox, ErrorBoxV
//
//  Display an error message, using given string and the error code to desc-
//  ribe the error. The string can contain substitute parameters in style of
//  FormatMessage.
//
//  The message is displayed as follows
//
//  +---------------------------------------------------------+
//  |  <the string with parameters substituted> 	          |
//  |							                              |
//  |  <system message for the error with given code>	      |
//  +---------------------------------------------------------+
//
//  Parameters:
//    hWnd		- handle to a window  that will be passed  to the MessageBox,
//				  can be NULL
//    hInstance - handle to a  module,	containing resources;  this parameter
//				  can be NULL only  if both pszString and pszTitle do not re-
//				  fer to the resources
//    pszString - describes the error from the application point of view, for
//				  example, "Cannot open script file". If HIWORD(pszString) is
//				  zero, then LOWORD(pszString) contains the identifier of the
//				  string in the module resources,  otherwise pszString should
//				  point to the actual string.
//    pszTitle	- specifies the title of the message box. If HIWORD(pszTitle)
//				  is zero,  then LOWORD(pszTitle) contains  the identifier of
//				  the string in the module resources, otherwise pszTitle must
//				  point to the actual string.  If this parameter is NULL, the
//				  system default title will be used ("Error")
//    dwError	- Win32 error code,  which will be used  to obtain the system
//				  error message, for example, "The system cannot find the fi-
//				  le specified". If this parameter is zero,  the system error
//				  message will not be displayed
//    ..., va	- additional arguments to be substituted in the format string
//
//  Returns:
//    IDOK if successful, -1 in the case of error.
//
EXTERN_C
int
CDECL
ErrorBoxA(
    IN HWND hWnd,
    IN HINSTANCE hInstance,
    IN PCSTR pszString,
    IN PCSTR pszTitle,
    IN DWORD dwError,
    ...
    )
{
    va_list va;
    va_start(va, dwError);

    int nRet = ErrorBoxVA(hWnd, hInstance, pszString, 
						  pszTitle, dwError, &va);

    va_end(va);
    return nRet;
}

EXTERN_C
int
CDECL
ErrorBoxW(
    IN HWND hWnd,
    IN HINSTANCE hInstance,
    IN PCWSTR pszString,
    IN PCWSTR pszTitle,
    IN DWORD dwError,
    ...
    )
{
    va_list va;
    va_start(va, dwError);

    int nRet = ErrorBoxVW(hWnd, hInstance, pszString, 
						  pszTitle, dwError, &va);

    va_end(va);
    return nRet;
}

EXTERN_C
int
APIENTRY
ErrorBoxVA(
    IN HWND hWnd,
    IN HINSTANCE hInstance,
    IN PCSTR pszString,
    IN PCSTR pszTitle,
    IN DWORD dwError,
    IN va_list * va
    )
{
    _ASSERTE(hWnd == NULL || IsWindow(hWnd));
    _ASSERTE(pszString != NULL);

    CHAR szTitle[256];
    CHAR szFormat[1024];
    CHAR szMessage[2048];

    // load and format application string
    if (HIWORD(pszString) == 0)
    {
		_VERIFY(LoadStringA(hInstance, LOWORD(pszString), szFormat, 
							countof(szFormat)));
		pszString = szFormat;
    }

    _ASSERTE(_CrtIsValidPointer(pszString, sizeof(TCHAR), 0));

    int len = FormatMessageA(FORMAT_MESSAGE_FROM_STRING, pszString, 0, 0,
							 szMessage, countof(szMessage) - 2, va);

    if (dwError != 0)
    {
		// add two line breaks
		szMessage[len++] = _T('\n');
		szMessage[len++] = _T('\n');
		szMessage[len] = 0;

		// format system error message
		if (!FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwError, 0, 
							szMessage + len, countof(szMessage) - len, NULL))
		{	    
			// there is no system message - display "Unknown error: <number>"
			LoadStringA(_Module.GetResourceInstance(), IDS_UNKNOWN_ERROR, 
						szFormat, countof(szFormat));

			FormatMessageA(FORMAT_MESSAGE_FROM_STRING|
						   FORMAT_MESSAGE_ARGUMENT_ARRAY,
						   szFormat, 0, 0, szMessage + len, 
						   countof(szMessage) - len, (va_list *)&dwError);
		}
    }

    // load title
    if (pszTitle != NULL && HIWORD(pszTitle) == 0)
    {
		_VERIFY(LoadStringA(hInstance, LOWORD(pszTitle), szTitle, 
							countof(szTitle)));
		pszTitle = szTitle;
    }

    _ASSERTE(pszTitle == NULL || 
			 _CrtIsValidPointer(pszTitle, sizeof(CHAR), 0));

    // display the message box
    return MessageBoxA(hWnd, szMessage, pszTitle, MB_OK|MB_ICONSTOP);
}

EXTERN_C
int
APIENTRY
ErrorBoxVW(
    IN HWND hWnd,
    IN HINSTANCE hInstance,
    IN PCWSTR pszString,
    IN PCWSTR pszTitle,
    IN DWORD dwError,
    IN va_list * va
    )
{
    _ASSERTE(hWnd == NULL || IsWindow(hWnd));
    _ASSERTE(pszString != NULL);

    WCHAR szTitle[256];
    WCHAR szFormat[1024];
    WCHAR szMessage[2048];

    // load and format application string
    if (HIWORD(pszString) == 0)
    {
		_VERIFY(LoadStringW(hInstance, LOWORD(pszString), szFormat, 
							countof(szFormat)));
		pszString = szFormat;
    }

    _ASSERTE(_CrtIsValidPointer(pszString, sizeof(TCHAR), 0));

    int len = FormatMessageW(FORMAT_MESSAGE_FROM_STRING, pszString, 0, 0,
							 szMessage, countof(szMessage) - 2, va);

    if (dwError != 0)
    {
		// add two line breaks
		szMessage[len++] = _T('\n');
		szMessage[len++] = _T('\n');
		szMessage[len] = 0;

		// format system error message
		if (!FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwError, 0, 
							szMessage + len, countof(szMessage) - len, NULL))
		{	    
			// there is no system message - display "Unknown error: <number>"
			LoadStringW(_Module.GetResourceInstance(), IDS_UNKNOWN_ERROR, 
						szFormat, countof(szFormat));

			FormatMessageW(FORMAT_MESSAGE_FROM_STRING|
						   FORMAT_MESSAGE_ARGUMENT_ARRAY,
						   szFormat, 0, 0, szMessage + len, 
						   countof(szMessage) - len, (va_list *)&dwError);
		}
    }

    // load title
    if (pszTitle != NULL && HIWORD(pszTitle) == 0)
    {
		_VERIFY(LoadStringW(hInstance, LOWORD(pszTitle), szTitle,
							countof(szTitle)));
		pszTitle = szTitle;
    }

    _ASSERTE(pszTitle == NULL || 
			 _CrtIsValidPointer(pszTitle, sizeof(CHAR), 0));

    // display the message box
    return MessageBoxW(hWnd, szMessage, pszTitle, MB_OK|MB_ICONSTOP);
}
