// svcprop.cpp
//
// Service property pages.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "svcprop.h"
#include "mainwnd.h"
#include "svcobj.h"
#include "errorbox.h"

//---------------------------------------------------------------------------
// OnApply
//
//  Called when Apply or OK button is pressed and something was changed
//	on the property page.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to dismiss property sheet, FALSE - to have it to stay.
//
BOOL
CGeneralPage::OnApply()
{
	if (!m_bDirty)
		return TRUE;

	_ASSERTE(!m_pCtx->bReadOnly);

	SC_HANDLE hService = m_pCtx->hService;
	_ASSERTE(hService != NULL);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	TCHAR szDisplayName[256];
	PTSTR pszDescription = (PTSTR)&_chNil;
	TCHAR szImagePath[MAX_PATH];
	DWORD dwStartType;
	DWORD dwServiceType = pService->m_dwServiceType;

	// get string values
	GetDlgItemText(IDC_DISPLAY_NAME, szDisplayName, countof(szDisplayName));
	GetDlgItemText(IDC_IMAGE_PATH, szImagePath, countof(szImagePath));

	_ASSERTE(szDisplayName[0] != 0);

	// determine new service type
	dwServiceType &= ~SERVICE_WIN32;
	if (IsDlgButtonChecked(IDC_OWN_PROCESS))
		dwServiceType |= SERVICE_WIN32_OWN_PROCESS;
	if (IsDlgButtonChecked(IDC_SHARE_PROCESS))
		dwServiceType |= SERVICE_WIN32_SHARE_PROCESS;

	// determine new startup type
	int nSel = m_wndStartupType.GetCurSel();
	_ASSERTE(nSel != -1);
	dwStartType = m_wndStartupType.GetItemData(nSel);

	// set startup type and display name
	if (!ChangeServiceConfig(hService, dwServiceType, dwStartType,
							 SERVICE_NO_CHANGE, szImagePath, NULL, NULL,
							 NULL, NULL, NULL, szDisplayName))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), GetLastError());
		return FALSE;
	}

	// reflect new values in the service object
	lstrcpyn(pService->m_szDisplayName, szDisplayName, 
			 countof(pService->m_szDisplayName));
	lstrcpyn(pService->m_szImagePath, szImagePath,
			 countof(pService->m_szImagePath));

	pService->m_dwServiceType = dwServiceType;
	pService->m_dwStartupType = dwStartType;

	m_pCtx->bRefresh = TRUE;

	// set service description
	if (_ChangeServiceConfig2 != NULL &&
		pMainWnd->m_dwMajorVersion >= 5)
	{
		CWindow wndDesc = GetDlgItem(IDC_DESCRIPTION);
		int len = wndDesc.GetWindowTextLength();

		if (len != 0)
		{
			pszDescription = (PTSTR)malloc((len + 1) * sizeof(TCHAR));
			if (pszDescription == NULL)
			{
				ErrorBox(m_hWnd, _Module.GetResourceInstance(),
						 MAKEINTRESOURCE(IDP_APPLY_FAILED),
						 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
						 ERROR_NOT_ENOUGH_MEMORY);
				return FALSE;
			}

			wndDesc.GetWindowText(pszDescription, len + 1);
		}

		SERVICE_DESCRIPTION Desc;
		Desc.lpDescription = pszDescription;

		if (!_ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, 
								   &Desc))
		{
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_APPLY_FAILED),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), GetLastError());
			return FALSE;
		}

		// reflect new value in the service object
		if (pService->m_pszDescription != (PTSTR)&_chNil)
			free(pService->m_pszDescription);
		pService->m_pszDescription = pszDescription;
	}

	m_bDirty = FALSE;
	return TRUE;
}

//---------------------------------------------------------------------------
// OnKillActive
//
//  Called when the page is about to loose focus. Performs validation of
//	user-entered data.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow switch to another page, FALSE - to prohibit it.
//
BOOL
CGeneralPage::OnKillActive()
{
	CWindow wndDisplayName(GetDlgItem(IDC_DISPLAY_NAME));

	if (wndDisplayName.GetWindowTextLength() == 0)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_NULL_DISPLAY_NAME),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0);

		wndDisplayName.SetFocus();
		return FALSE;
	}

	CWindow wndImagePath(GetDlgItem(IDC_IMAGE_PATH));

	if (wndImagePath.GetWindowTextLength() == 0)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_COMMAND_LINE_EMPTY),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0);

		wndImagePath.SetFocus();
		return FALSE;
	}

	return TRUE;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CGeneralPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	m_wndStartupType = GetDlgItem(IDC_STARTUP_TYPE);
	_ASSERTE(m_wndStartupType.m_hWnd != NULL);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	// initialize edit fields
	_VERIFY(SetDlgItemText(IDC_NAME, pService->m_szName));
	_VERIFY(SetDlgItemText(IDC_DISPLAY_NAME, pService->m_szDisplayName));
	_VERIFY(SetDlgItemText(IDC_DESCRIPTION, pService->m_pszDescription));
	_VERIFY(SetDlgItemText(IDC_IMAGE_PATH, pService->m_szImagePath));

	// select appropriate service type
	UINT nCheck = 0;
	if (pService->m_dwServiceType & SERVICE_WIN32_OWN_PROCESS)
		nCheck = IDC_OWN_PROCESS;
	if (pService->m_dwServiceType & SERVICE_WIN32_SHARE_PROCESS)
		nCheck = IDC_SHARE_PROCESS;

	_ASSERTE(nCheck != 0);
	_VERIFY(CheckRadioButton(IDC_OWN_PROCESS, IDC_SHARE_PROCESS, nCheck));

	// fill startup type combo box with values
	DWORD dwStartupTypes[3] = {
		SERVICE_AUTO_START,
		SERVICE_DEMAND_START,
		SERVICE_DISABLED
	};
	
	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	int nItem, nSel = -1;
	for (int i = 0; i < countof(dwStartupTypes); i++)
	{
		PCTSTR psz = pMainWnd->GetStartupTypeString(dwStartupTypes[i]);

		nItem = m_wndStartupType.AddString(psz);
		m_wndStartupType.SetItemData(nItem, dwStartupTypes[i]);

		if (pService->m_dwStartupType == dwStartupTypes[i])
			nSel = nItem;
	}

	_ASSERTE(nSel != -1);
	m_wndStartupType.SetCurSel(nSel);

	BOOL bReadOnly = m_pCtx->bReadOnly;

	_VERIFY(EnableDlgItem(IDC_DISPLAY_NAME, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_DESCRIPTION, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_BROWSE, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_IMAGE_PATH, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_STARTUP_TYPE, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_OWN_PROCESS, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_SHARE_PROCESS, !bReadOnly));

	if (_ChangeServiceConfig2 == NULL ||
		pMainWnd->m_dwMajorVersion < 5)
		_VERIFY(EnableDlgItem(IDC_DESCRIPTION, FALSE));

	if (!bReadOnly)
	{
		// set edit fields limits
		SendDlgItemMessage(IDC_DISPLAY_NAME, EM_LIMITTEXT, 255);
		SendDlgItemMessage(IDC_IMAGE_PATH, EM_LIMITTEXT, MAX_PATH - 1);
	}

	m_bDirty = FALSE;
	return TRUE;
}

//---------------------------------------------------------------------------
// OnBrowse
//
//  Handles "Browse..." button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CGeneralPage::OnBrowse()
{
	TCHAR szImagePath[MAX_PATH];
	TCHAR szFilter[256];

	GetDlgItemText(IDC_IMAGE_PATH, szImagePath, countof(szImagePath));
	LoadFilterString(IDS_IMAGE_FILTER, szFilter, countof(szFilter));

	CFileDialog dlgOpen(TRUE, _T("exe"), szImagePath, 
					    OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,
						szFilter, m_hWnd);

	if (dlgOpen.DoModal() == IDOK)
		SetDlgItemText(IDC_IMAGE_PATH, dlgOpen.m_szFileName);
}

//---------------------------------------------------------------------------
// OnApply
//
//  Called when Apply or OK button is pressed and something was changed
//	on the property page.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to dismiss property sheet, FALSE - to have it to stay.
//
BOOL
CAdvancedPage::OnApply()
{
	if (!m_bDirty)
		return TRUE;

	_ASSERTE(!m_pCtx->bReadOnly);

	SC_HANDLE hService = m_pCtx->hService;
	_ASSERTE(hService != NULL);

	CService * pService = (CService *)m_pCtx->pService;
	_ASSERTE(pService != NULL);

	CMainWnd * pMainWnd = (CMainWnd *)m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	DWORD dwServiceType = pService->m_dwServiceType;
	DWORD dwErrorControl;
	TCHAR szUserName[UNLEN + 3];
	TCHAR szPassword[PWLEN + 1];
	TCHAR szLoadGroup[256];
	PCTSTR pszUserName = szUserName;

	BOOL bLocalSystem = IsDlgButtonChecked(IDC_LOCALSYSTEM);
	BOOL bLocalService = IsDlgButtonChecked(IDC_LOCALSERVICE);
	BOOL bNetworkService = IsDlgButtonChecked(IDC_NETWORKSERVICE);

	if (bLocalSystem)
	{
		// decide whether the service is interactive
		if (IsDlgButtonChecked(IDC_INTERACTIVE))
			dwServiceType |= SERVICE_INTERACTIVE_PROCESS;
		else
			dwServiceType &= ~SERVICE_INTERACTIVE_PROCESS;

		lstrcpy(szUserName, _szLocalSystem);
	}
	else if (bLocalService)
	{
		lstrcpy(szUserName, _szLocalService);
	}
	else if (bNetworkService)
	{
		lstrcpy(szUserName, _szNetworkService);
	}
	else
	{
		// this service cannot be interactive
		dwServiceType &= ~SERVICE_INTERACTIVE_PROCESS;

		// retrieve the user name and password
		GetDlgItemText(IDC_USERNAME, szUserName + 2, countof(szUserName) - 2);
		GetDlgItemText(IDC_PASSWORD, szPassword, countof(szPassword));
		_ASSERTE(szUserName[2] != 0);

		// check if the domain name is explicitly specified
		if (_tcschr(szUserName + 2, _T('\\')) == NULL)
		{
			szUserName[0] = _T('.');
			szUserName[1] = _T('\\');
		}
		else
			pszUserName = szUserName + 2;
	}

	// retrieve load order group
	GetDlgItemText(IDC_LOAD_GROUP, szLoadGroup, countof(szLoadGroup));

	// retrieve error control
	int nSel = m_wndErrorControl.GetCurSel();
	_ASSERTE(nSel != -1);
	dwErrorControl = m_wndErrorControl.GetItemData(nSel);

	// update configuration
	BOOL bOk = ChangeServiceConfig(hService, dwServiceType, 
								   SERVICE_NO_CHANGE, dwErrorControl, NULL,
								   szLoadGroup, NULL, NULL, pszUserName, 
								   szPassword, NULL);

	memset(szPassword, 0, sizeof(szPassword));

	if (!bOk)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), GetLastError());
		return FALSE;
	}

	if (!bLocalSystem && !bLocalService && !bNetworkService)
	{
		HRESULT hRes;

		// grant privilege to this account
		hRes = GrantPrivilege(pMainWnd->GetMachineName(), pszUserName,
							  SE_SERVICE_LOGON_NAME);
		if (FAILED(hRes))
		{
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_SERVICE_LOGON_NOT_GRANTED),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0, pszUserName);
		}
		else if (hRes == S_OK)
		{
			TCHAR szTitle[80];
			TCHAR szMessage[512];

			AtlLoadString(IDS_MESSAGE_TITLE, szTitle, countof(szTitle));
			FormatString(szMessage, countof(szMessage), 
						 MAKEINTRESOURCE(IDP_SERVICE_LOGON_GRANTED),
						 pszUserName);

			MessageBox(szMessage, szTitle, MB_OK|MB_ICONINFORMATION);
		}
	}

	lstrcpyn(pService->m_szLogon, szUserName, 
			 countof(pService->m_szLogon));
	lstrcpyn(pService->m_szLoadGroup, szLoadGroup,
			 countof(pService->m_szLoadGroup));

	pService->m_bLocalSystem = (BYTE)bLocalSystem;
	pService->m_bLocalService = (BYTE)bLocalService;
	pService->m_bNetworkService = (BYTE)bNetworkService;
	pService->m_dwServiceType = dwServiceType;
	pService->m_dwErrorControl = dwErrorControl;

	m_pCtx->bRefresh = TRUE;
	m_bPassword = m_bDirty = FALSE;

	return TRUE;
}

//---------------------------------------------------------------------------
// OnKillActive
//
//  Called when the page is about to loose focus. Performs validation of
//	user-entered data.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow switch to another page, FALSE - to prohibit it.
//
BOOL
CAdvancedPage::OnKillActive()
{
	BOOL bThisAccount = IsDlgButtonChecked(IDC_THISACCOUNT);
	if (!bThisAccount || !m_bPassword)
		return TRUE;

	CWindow wndUserName(GetDlgItem(IDC_USERNAME));

	// check that the user name is specified
	if (wndUserName.GetWindowTextLength() == 0)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_USERNAME_EMPTY),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0);

		wndUserName.SetFocus();
		return FALSE;
	}

	TCHAR szPassword[PWLEN + 1];
	TCHAR szConfirm[PWLEN + 1];

	// check that two password copies match
	GetDlgItemText(IDC_PASSWORD, szPassword, countof(szPassword));
	GetDlgItemText(IDC_CONFIRM, szConfirm, countof(szConfirm));

	BOOL bMatch = lstrcmp(szPassword, szConfirm) == 0;

	memset(szPassword, 0, sizeof(szPassword));
	memset(szConfirm, 0, sizeof(szConfirm));

	if (!bMatch)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_PASSWORD_MISMATCH),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0);

		CWindow(GetDlgItem(IDC_PASSWORD)).SetFocus();
		return FALSE;
	}

	return TRUE;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CAdvancedPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	m_wndLoadGroup = GetDlgItem(IDC_LOAD_GROUP);
	m_wndErrorControl = GetDlgItem(IDC_ERROR_CONTROL);

	_ASSERTE(m_wndLoadGroup.m_hWnd != NULL);
	_ASSERTE(m_wndErrorControl.m_hWnd != NULL);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	BOOL bReadOnly = m_pCtx->bReadOnly;
	UINT nOption = 0;

	// initialize edit fields
	if (pService->m_bLocalSystem)
	{
		BOOL bInteractive = 
			(pService->m_dwServiceType & SERVICE_INTERACTIVE_PROCESS) != 0;
		CheckDlgButton(IDC_INTERACTIVE, bInteractive);

		nOption = IDC_LOCALSYSTEM;
	}
	else if (pService->m_bLocalService)
	{
		nOption = IDC_LOCALSERVICE;
	}
	else if (pService->m_bNetworkService)
	{
		nOption = IDC_NETWORKSERVICE;
	}
	else
	{
		_VERIFY(SetDlgItemText(IDC_USERNAME, pService->m_szLogon));
		_VERIFY(SetDlgItemText(IDC_PASSWORD, _T("0123456789")));
		_VERIFY(SetDlgItemText(IDC_CONFIRM, _T("9876543210")));

		nOption = IDC_THISACCOUNT;
	}

	CheckRadioButton(IDC_LOCALSYSTEM, IDC_NETWORKSERVICE, nOption);

	if (!bReadOnly)
	{
		OnAccount_Clicked();
	}
	else
	{
		_VERIFY(EnableDlgItem(IDC_INTERACTIVE, FALSE));
		_VERIFY(EnableDlgItem(IDC_USERNAME, FALSE));
		_VERIFY(EnableDlgItem(IDC_PASSWORD, FALSE));
		_VERIFY(EnableDlgItem(IDC_CONFIRM, FALSE));
		_VERIFY(EnableDlgItem(IDC_BROWSE, FALSE));
	}

	// fill error control combo box
	DWORD dwErrorControl[4] = {
		SERVICE_ERROR_IGNORE,
		SERVICE_ERROR_NORMAL,
		SERVICE_ERROR_SEVERE,
		SERVICE_ERROR_CRITICAL
	};
	
	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	int nItem, nSel = -1;
	for (int i = 0; i < countof(dwErrorControl); i++)
	{
		PCTSTR psz = pMainWnd->GetErrorControlString(dwErrorControl[i]);

		nItem = m_wndErrorControl.AddString(psz);
		m_wndErrorControl.SetItemData(nItem, dwErrorControl[i]);

		if (pService->m_dwErrorControl == dwErrorControl[i])
			nSel = nItem;
	}

	_ASSERTE(nSel != -1);
	m_wndErrorControl.SetCurSel(nSel);

	// fill load order group combo
	FillLoadOrderGroupCombo(m_wndLoadGroup, pMainWnd->GetMachineName());

	nSel = -1;
	nItem = m_wndLoadGroup.GetCount();

	TCHAR szItem[256];
	for (i = 0; i < nItem; i++)
	{
		m_wndLoadGroup.GetLBText(i, szItem);
		if (lstrcmpi(szItem, pService->m_szLoadGroup) == 0)
			nSel = i;
	}

	if (nSel != -1)
		m_wndLoadGroup.SetCurSel(nSel);
	else
		m_wndLoadGroup.SetWindowText(pService->m_szLoadGroup);

	_VERIFY(EnableDlgItem(IDC_LOCALSYSTEM, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_THISACCOUNT, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_LOAD_GROUP, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_ERROR_CONTROL, !bReadOnly));

	if (pMainWnd->m_dwMajorVersion > 5 ||
		pMainWnd->m_dwMajorVersion == 5 && pMainWnd->m_dwMinorVersion >= 1)
	{
		_VERIFY(EnableDlgItem(IDC_LOCALSERVICE, !bReadOnly));
		_VERIFY(EnableDlgItem(IDC_NETWORKSERVICE, !bReadOnly));
	}
	else
	{
		_VERIFY(EnableDlgItem(IDC_LOCALSERVICE, FALSE));
		_VERIFY(EnableDlgItem(IDC_NETWORKSERVICE, FALSE));
	}

	if (!bReadOnly)
	{
		// set edit fields limits
		SendDlgItemMessage(IDC_USERNAME, EM_LIMITTEXT, UNLEN);
		SendDlgItemMessage(IDC_PASSWORD, EM_LIMITTEXT, PWLEN);
		SendDlgItemMessage(IDC_CONFIRM, EM_LIMITTEXT, PWLEN);
	}

	m_bPassword = m_bDirty = FALSE;
	return TRUE;
}

//---------------------------------------------------------------------------
// OnAccount_Clicked
//
//  Handles account selection options.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CAdvancedPage::OnAccount_Clicked()
{
	BOOL bLocalSystem = IsDlgButtonChecked(IDC_LOCALSYSTEM);
	_VERIFY(EnableDlgItem(IDC_INTERACTIVE, bLocalSystem));

	BOOL bThisAccount = IsDlgButtonChecked(IDC_THISACCOUNT);

	_VERIFY(EnableDlgItem(IDC_USERNAME, bThisAccount));
	_VERIFY(EnableDlgItem(IDC_PASSWORD, bThisAccount));
	_VERIFY(EnableDlgItem(IDC_CONFIRM, bThisAccount));

	bThisAccount = bThisAccount && _osvi.dwMajorVersion >= 5;
	_VERIFY(EnableDlgItem(IDC_BROWSE, bThisAccount));

	SetModified();
}

//---------------------------------------------------------------------------
// OnBrowse
//
//  Handles "Browse..." button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CAdvancedPage::OnBrowse()
{
	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	TCHAR szUserName[DNLEN + UNLEN + 2];

	int nRet = BrowseForUser(m_hWnd, pMainWnd->GetMachineName(), szUserName, 
							 countof(szUserName));
	if (nRet == -1)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_BROWSE_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), GetLastError());
	}
	else if (nRet == IDOK)
		SetDlgItemText(IDC_USERNAME, szUserName);
}

//---------------------------------------------------------------------------
// OnActivate
//
//  Handles WM_ACTIVATE message. Centers the window which is about to pop
//  above this window.
//
//  Parameters:
//    fuActive   - specifies whether the window is being activated or 
//				   deactivated
//    bMinimized - specifies whether the window is minimized
//	  hWndOther  - other window which is activated or deactivated
//
//  Returns:
//    no return value.
//
void
CActionDlg::OnActivate(
	UINT fuActive,
	BOOL bMinimized,
	HWND hWndOther
    )
{
    _UNUSED(bMinimized);

    if (fuActive == WA_INACTIVE && hWndOther != NULL)
	{
		CWindow wndActive(hWndOther);
		if (wndActive.GetParent() == m_hWnd)
			wndActive.CenterWindow(m_hWnd);
	}
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes dialog controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CActionDlg::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	UINT nOption = 0;
	switch (m_nType)
	{
		case SC_ACTION_NONE:
			nOption = IDC_NO_ACTION;
			break;
		case SC_ACTION_RESTART:	
			nOption = IDC_RESTART_SERVICE;
			break;
		case SC_ACTION_REBOOT:
			nOption = IDC_REBOOT;
			break;
		case SC_ACTION_RUN_COMMAND:
			nOption = IDC_PROGRAM;
			break;
		default:
			_ASSERTE(0);
			__assume(0);
	}
	_ASSERTE(nOption != 0);

	CheckRadioButton(IDC_NO_ACTION, IDC_PROGRAM, nOption);
	SetDlgItemText(IDC_DELAY, m_szDelay);

	SendDlgItemMessage(IDC_DELAY, EM_LIMITTEXT, countof(m_szDelay));
	return TRUE;
}

//---------------------------------------------------------------------------
// OnDelay_KillFocus
//
//  Handles EN_KILLFOCUS notification from the delay edit box. Normalizes
//	the time displayed in the edit box.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CActionDlg::OnDelay_KillFocus()
{
	DWORD dwInterval;
	TCHAR szOriginal[40];
	TCHAR szNormalized[40];

	GetDlgItemText(IDC_DELAY, szOriginal, countof(szOriginal));

	if (ParseTimeInterval(szOriginal, &dwInterval))
	{
		FormatTimeInterval(dwInterval, szNormalized, countof(szNormalized));

		if (lstrcmp(szOriginal, szNormalized) != 0)
			SetDlgItemText(IDC_DELAY, szNormalized);
	}
}

//---------------------------------------------------------------------------
// OnOK
//
//  Handles "OK" button.
//
//  Parameters:
//	  none.
//
//  Returns:
//    no return value.
//
void
CActionDlg::OnOK()
{
	if (IsDlgButtonChecked(IDC_NO_ACTION))
		m_nType = SC_ACTION_NONE;
	else if (IsDlgButtonChecked(IDC_RESTART_SERVICE))
		m_nType = SC_ACTION_RESTART;
	else if (IsDlgButtonChecked(IDC_REBOOT))
		m_nType = SC_ACTION_REBOOT;
	else
		m_nType = SC_ACTION_RUN_COMMAND;

	GetDlgItemText(IDC_DELAY, m_szDelay, countof(m_szDelay));

	// validate delay
	DWORD dwDelay;
	if (!ParseTimeInterval(m_szDelay, &dwDelay))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_INVALID_INTERVAL),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0);
	}
	else
	{
		FormatTimeInterval(dwDelay, m_szDelay, countof(m_szDelay));
		EndDialog(IDOK);
	}
}

//---------------------------------------------------------------------------
// OnApply
//
//  Called when Apply or OK button is pressed and something was changed
//	on the property page.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to dismiss property sheet, FALSE - to have it to stay.
//
BOOL
CRecoveryPage::OnApply()
{
	if (!m_bDirty)
		return TRUE;

	_ASSERTE(!m_pCtx->bReadOnly);
	_ASSERTE(_ChangeServiceConfig2 != NULL);

	SC_HANDLE hService = m_pCtx->hService;
	_ASSERTE(hService != NULL);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	CWindow wndCmdLine(GetDlgItem(IDC_COMMAND_LINE));
	CWindow wndMessage(GetDlgItem(IDC_MESSAGE));

	int nCount = m_wndList.GetItemCount();
	UINT cchCmdLine = 1;
	UINT cchMessage = 1;

	if (wndCmdLine.IsWindowEnabled())
		cchCmdLine = wndCmdLine.GetWindowTextLength() + 1;
	if (wndMessage.IsWindowEnabled())
		cchMessage = wndMessage.GetWindowTextLength() + 1;

	DWORD cbAlloc = sizeof(SERVICE_FAILURE_ACTIONS) +
					nCount * sizeof(SC_ACTION) +
					cchCmdLine * sizeof(TCHAR) +
					cchMessage * sizeof(TCHAR);

	LPSERVICE_FAILURE_ACTIONS pActions = 
		(LPSERVICE_FAILURE_ACTIONS)malloc(cbAlloc);
	if (pActions == NULL)
	{
		ErrorBox(m_wndList, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
				 ERROR_NOT_ENOUGH_MEMORY);
		return FALSE;
	}

	memset(pActions, 0, cbAlloc);

	pActions->cActions = nCount;
	pActions->lpsaActions = (LPSC_ACTION)(pActions + 1);
	pActions->lpCommand = (PTSTR)(pActions->lpsaActions + nCount);
	pActions->lpRebootMsg = pActions->lpCommand + cchCmdLine;

	TCHAR szDelay[40];
	LVITEM lvi;

	BOOL bHaveRestart = FALSE;

	// fill actions array
	for (int i = 0; i < nCount; i++)
	{
		lvi.iItem = i;
		lvi.iSubItem = 0;
		lvi.mask = LVIF_PARAM;

		_VERIFY(m_wndList.GetItem(&lvi));

		pActions->lpsaActions[i].Type = (SC_ACTION_TYPE)lvi.lParam;
		if (lvi.lParam == SC_ACTION_RESTART)
			bHaveRestart = TRUE;

		lvi.iSubItem = 2;
		lvi.mask = LVIF_TEXT;
		lvi.pszText = szDelay;
		lvi.cchTextMax = countof(szDelay);

		_VERIFY(m_wndList.GetItem(&lvi));

		_VERIFY(ParseTimeInterval(szDelay, &pActions->lpsaActions[i].Delay));
		pActions->lpsaActions[i].Delay *= 1000;
	}

	if (wndCmdLine.IsWindowEnabled())
		wndCmdLine.GetWindowText(pActions->lpCommand, cchCmdLine);
	if (wndMessage.IsWindowEnabled())
		wndMessage.GetWindowText(pActions->lpRebootMsg, cchMessage);
	
	if (IsDlgButtonChecked(IDC_RESET_COUNT))
	{
		GetDlgItemText(IDC_RESET_DELAY, szDelay, countof(szDelay));
		_VERIFY(ParseTimeInterval(szDelay, &pActions->dwResetPeriod));
	}
	else
		pActions->dwResetPeriod = INFINITE;
		
	if (bHaveRestart)
	{
		// we need a handle with SERVICE_START access right
		hService = OpenService(pMainWnd->m_hSCM, pService->m_szName,
							   SERVICE_ALL_ACCESS);
		if (hService == NULL)
		{
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_APPLY_FAILED),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), GetLastError());

			free(pActions);
			return FALSE;
		}
	}

	BOOL bShutdownPrivilege = FALSE;

	// we need to enable SeShutdownPrivilege
	if (wndMessage.IsWindowEnabled())
		AdjustPrivilege(SE_SHUTDOWN_NAME, TRUE, TRUE, &bShutdownPrivilege);

	if (!_ChangeServiceConfig2(hService, SERVICE_CONFIG_FAILURE_ACTIONS,
							   pActions))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), GetLastError());

		// restore SeShutdownPrivilege
		if (wndMessage.IsWindowEnabled())
			AdjustPrivilege(SE_SHUTDOWN_NAME, bShutdownPrivilege, TRUE, FALSE);

		if (bHaveRestart)
			_VERIFY(CloseServiceHandle(hService));

		free(pActions);
		return FALSE;
	}

	// restore SeShutdownPrivilege
	if (wndMessage.IsWindowEnabled())
		AdjustPrivilege(SE_SHUTDOWN_NAME, bShutdownPrivilege, TRUE, FALSE);

	if (bHaveRestart)
		_VERIFY(CloseServiceHandle(hService));

	free(pService->m_pActions);
	pService->m_pActions = pActions;

	m_bDirty = FALSE;
	return TRUE;
}

//---------------------------------------------------------------------------
// OnKillActive
//
//  Called when the page is about to loose focus. Performs validation of
//	user-entered data.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow switch to another page, FALSE - to prohibit it.
//
BOOL
CRecoveryPage::OnKillActive()
{
	CWindow wndCmdLine(GetDlgItem(IDC_COMMAND_LINE));

	// check the command line
	if (wndCmdLine.IsWindowEnabled() &&
		wndCmdLine.GetWindowTextLength() == 0)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_COMMAND_LINE_EMPTY),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0);

		wndCmdLine.SetFocus();
		return FALSE;
	}

	if (IsDlgButtonChecked(IDC_RESET_COUNT))
	{
		CWindow wndResetDelay(GetDlgItem(IDC_RESET_DELAY));
		TCHAR szInterval[40];
		DWORD dwInterval;

		// check the time interval
		wndResetDelay.GetWindowText(szInterval, countof(szInterval));
		if (!ParseTimeInterval(szInterval, &dwInterval))
		{
			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_INVALID_INTERVAL),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0);

			wndResetDelay.SetFocus();
			return FALSE;
		}
	}

	return TRUE;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CRecoveryPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	m_wndList = GetDlgItem(IDC_ACTIONS);
	_ASSERTE(m_wndList.m_hWnd != NULL);

	m_wndList.SetExtendedListViewStyle(LVS_EX_FULLROWSELECT);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	CService::PSFA pActions = pService->m_pActions;
	_ASSERTE(pActions != NULL);

	// add columns to the list
	TCHAR szBuffer[80];

	_VERIFY(AtlLoadString(IDS_ACTIONS_FAILURE, szBuffer, countof(szBuffer)));
	m_wndList.InsertColumn(0, szBuffer, LVCFMT_LEFT, -1, 0);

	_VERIFY(AtlLoadString(IDS_ACTIONS_ACTION, szBuffer, countof(szBuffer)));
	m_wndList.InsertColumn(1, szBuffer, LVCFMT_LEFT, -1, 1);

	_VERIFY(AtlLoadString(IDS_ACTIONS_DELAY, szBuffer, countof(szBuffer)));
	m_wndList.InsertColumn(2, szBuffer, LVCFMT_LEFT, -1, 2);

	// fill list view with failure actions
	for (DWORD i = 0; i < pActions->cActions; i++)
	{
		int nType = pActions->lpsaActions[i].Type;

		_itot10(i + 1, szBuffer);

		m_wndList.InsertItem(LVIF_TEXT|LVIF_PARAM, i, szBuffer,
							 0, 0, -1, nType);

		m_wndList.SetItem(i, 1, LVIF_TEXT, 
						  pMainWnd->GetFailureActionString(nType), 
						  -1, 0, 0, 0);

		FormatTimeInterval(pActions->lpsaActions[i].Delay / 1000,
						   szBuffer, countof(szBuffer));
		m_wndList.SetItem(i, 2, LVIF_TEXT, szBuffer, -1, 0, 0, 0);
	}

	// autosize list columns
	m_wndList.SetColumnWidth(0, LVSCW_AUTOSIZE_USEHEADER);
	m_wndList.SetColumnWidth(1, LVSCW_AUTOSIZE_USEHEADER);
	m_wndList.SetColumnWidth(2, LVSCW_AUTOSIZE_USEHEADER);

	// reserve some space for the scroll bar
	int cx = m_wndList.GetColumnWidth(2);
	cx -= GetSystemMetrics(SM_CXVSCROLL);
	m_wndList.SetColumnWidth(2, cx);

	// initialize text fields
	if (pActions->lpRebootMsg != NULL)
		_VERIFY(SetDlgItemText(IDC_MESSAGE, pActions->lpRebootMsg));
	if (pActions->lpCommand != NULL)
		_VERIFY(SetDlgItemText(IDC_COMMAND_LINE, pActions->lpCommand));

	// hide Browse button in remote operation
	if (pMainWnd->GetMachineName() != NULL)
		ShowDlgItem(IDC_BROWSE, SW_HIDE);

	BOOL bReadOnly = m_pCtx->bReadOnly;
	_VERIFY(EnableDlgItem(IDC_RESET_COUNT, !bReadOnly));

	if (pActions->dwResetPeriod != INFINITE)
	{
		CheckDlgButton(IDC_RESET_COUNT, 1);

		FormatTimeInterval(pActions->dwResetPeriod, szBuffer, countof(szBuffer));
		_VERIFY(SetDlgItemText(IDC_RESET_DELAY, szBuffer));

		_VERIFY(EnableDlgItem(IDC_RESET_DELAY, !bReadOnly));
	}
	else
	{
		_VERIFY(EnableDlgItem(IDC_RESET_DELAY, FALSE));
	}

	// enable controls
	SetListButtons();
	CheckActionTypes();

	CWindow(GetDlgItem(IDC_COMMAND_LINE)).SendMessage(EM_LIMITTEXT, MAX_PATH);
	CWindow(GetDlgItem(IDC_MESSAGE)).SendMessage(EM_LIMITTEXT, 1023);
	CWindow(GetDlgItem(IDC_RESET_DELAY)).SendMessage(EM_LIMITTEXT, 40);

	m_bDirty = FALSE;
	return TRUE;
}

//---------------------------------------------------------------------------
// OnActions_DblClk
//
//  Handles LVN_DBLCLK notification from the list. Displays recovery actions
//  dialog for the selected item.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CRecoveryPage::OnActions_DblClk(
    LPNMHDR pNMHDR
    )
{
	_UNUSED(pNMHDR);

	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	if (nSel != -1)
		OnChange();
	return 0;
}

//---------------------------------------------------------------------------
// OnAdd
//
//  Handles "Add..." button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CRecoveryPage::OnAdd()
{
	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	CActionDlg dlgAction;
	dlgAction.m_nType = SC_ACTION_RESTART;

	FormatTimeInterval(60, dlgAction.m_szDelay, 
					   countof(dlgAction.m_szDelay));

	if (dlgAction.DoModal() == IDOK)
	{
		UINT nType = dlgAction.m_nType;

		int nCount = m_wndList.GetItemCount();

		TCHAR szOrder[10];
		_itot10(nCount + 1, szOrder);

		LVITEM lvi;
		lvi.iItem = nCount;
		lvi.iSubItem = 0;
		lvi.mask = LVIF_TEXT|LVIF_PARAM;
		lvi.pszText = szOrder;
		lvi.lParam = nType;

		m_wndList.InsertItem(&lvi);

		lvi.mask = LVIF_TEXT;
		lvi.iSubItem = 1;
		lvi.pszText = (PTSTR)pMainWnd->GetFailureActionString(nType);
		_VERIFY(m_wndList.SetItem(&lvi));

		lvi.iSubItem = 2;
		lvi.pszText = dlgAction.m_szDelay;
		_VERIFY(m_wndList.SetItem(&lvi));

		CheckActionTypes();
		SetListButtons();
		SetModified();
	}
}

//---------------------------------------------------------------------------
// OnRemove
//
//  Handles "OnRemove" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CRecoveryPage::OnRemove()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);
	m_wndList.DeleteItem(nSel);

	LVITEM lvi;
	int nCount = m_wndList.GetItemCount();

	CWindow wndRemove(GetDlgItem(IDC_REMOVE));
	if (nCount > 0)
	{
		lvi.mask = LVIF_STATE;
		lvi.iItem = (nCount == nSel) ? nCount - 1 : nSel;
		lvi.iSubItem = 0;
		lvi.state = LVIS_SELECTED|LVIS_FOCUSED;
		lvi.stateMask = LVIS_SELECTED|LVIS_FOCUSED;

		_VERIFY(m_wndList.SetItem(&lvi));

		wndRemove.SetFocus();
	}
	else
	{
		wndRemove.ModifyStyle(BS_DEFPUSHBUTTON, BS_PUSHBUTTON);
		CWindow(GetDlgItem(IDC_ADD)).SetFocus();
	}

	TCHAR szItem[8];
	lvi.mask = LVIF_TEXT;
	lvi.pszText = szItem;

	for (; nSel < nCount; nSel++)
	{
		_itot10(nSel + 1, szItem);
		lvi.iItem = nSel;
		_VERIFY(m_wndList.SetItem(&lvi));
	}

	CheckActionTypes();
	SetModified();
}

//---------------------------------------------------------------------------
// OnChange
//
//  Handles "Change..." button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CRecoveryPage::OnChange()
{
	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);

	CActionDlg dlgAction;

	LVITEM lvi;
	lvi.mask = LVIF_PARAM;
	lvi.iItem = nSel;
	lvi.iSubItem = 0;

	_VERIFY(m_wndList.GetItem(&lvi));

	dlgAction.m_nType = (UINT)lvi.lParam;

	lvi.mask = LVIF_TEXT;
	lvi.iSubItem = 2;
	lvi.pszText = dlgAction.m_szDelay;
	lvi.cchTextMax = countof(dlgAction.m_szDelay);

	_VERIFY(m_wndList.GetItem(&lvi));
	
	if (dlgAction.DoModal() == IDOK)
	{
		UINT nType = dlgAction.m_nType;

		lvi.iSubItem = 1;
		lvi.pszText = (PTSTR)pMainWnd->GetFailureActionString(nType);
		_VERIFY(m_wndList.SetItem(&lvi));

		lvi.iSubItem = 2;
		lvi.pszText = dlgAction.m_szDelay;
		_VERIFY(m_wndList.SetItem(&lvi));

		lvi.mask = LVIF_PARAM;
		lvi.iSubItem = 0;
		lvi.lParam = nType;
		_VERIFY(m_wndList.SetItem(&lvi));

		CheckActionTypes();
		SetModified();
	}
}

//---------------------------------------------------------------------------
// OnUp
//
//  Handles "Up" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CRecoveryPage::OnUp()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);
	_ASSERTE(nSel > 0);

	TCHAR szOrder[10];
	TCHAR szAction[80];
	TCHAR szDelay[40];
	UINT nType;

	LVITEM lvi;
	lvi.iItem = nSel;
	lvi.mask = LVIF_PARAM;
	
	lvi.iSubItem = 0;
	_VERIFY(m_wndList.GetItem(&lvi));
	nType = (UINT)lvi.lParam;

	lvi.mask = LVIF_TEXT;
	lvi.iSubItem = 1;
	lvi.pszText = szAction;
	lvi.cchTextMax = countof(szAction);
	_VERIFY(m_wndList.GetItem(&lvi));

	lvi.iSubItem = 2;
	lvi.pszText = szDelay;
	lvi.cchTextMax = countof(szDelay);
	_VERIFY(m_wndList.GetItem(&lvi));

	m_wndList.DeleteItem(nSel);

	_itot10(nSel, szOrder);

	lvi.mask = LVIF_TEXT|LVIF_PARAM|LVIF_STATE;
	lvi.iItem = nSel - 1;
	lvi.iSubItem = 0;
	lvi.pszText = szOrder;
	lvi.state = LVIS_SELECTED|LVIS_FOCUSED;
	lvi.stateMask = LVIS_SELECTED|LVIS_FOCUSED;
	lvi.lParam = (LPARAM)nType;

	m_wndList.InsertItem(&lvi);

	lvi.mask = LVIF_TEXT;
	lvi.iSubItem = 1;
	lvi.pszText = szAction;
	_VERIFY(m_wndList.SetItem(&lvi));

	lvi.iSubItem = 2;
	lvi.pszText = szDelay;
	_VERIFY(m_wndList.SetItem(&lvi));

	_itot10(nSel + 1, szOrder);

	lvi.iItem = nSel;
	lvi.iSubItem = 0;
	lvi.pszText = szOrder;
	_VERIFY(m_wndList.SetItem(&lvi));

	CWindow wndUp(GetDlgItem(IDC_UP));
	if (nSel > 1)
	{
		wndUp.SetFocus();
	}
	else
	{
		wndUp.ModifyStyle(BS_DEFPUSHBUTTON, BS_PUSHBUTTON);
		CWindow(GetDlgItem(IDC_ADD)).SetFocus();
	}

	SetModified();
}

//---------------------------------------------------------------------------
// OnDown
//
//  Handles "Down" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CRecoveryPage::OnDown()
{
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	_ASSERTE(nSel != -1);
	_ASSERTE(nSel < m_wndList.GetItemCount() - 1);

	TCHAR szOrder[10];
	TCHAR szAction[80];
	TCHAR szDelay[40];
	UINT nType;

	LVITEM lvi;
	lvi.iItem = nSel;
	lvi.mask = LVIF_PARAM;
	
	lvi.iSubItem = 0;
	_VERIFY(m_wndList.GetItem(&lvi));
	nType = (UINT)lvi.lParam;

	lvi.mask = LVIF_TEXT;
	lvi.iSubItem = 1;
	lvi.pszText = szAction;
	lvi.cchTextMax = countof(szAction);
	_VERIFY(m_wndList.GetItem(&lvi));

	lvi.iSubItem = 2;
	lvi.pszText = szDelay;
	lvi.cchTextMax = countof(szDelay);
	_VERIFY(m_wndList.GetItem(&lvi));

	m_wndList.DeleteItem(nSel);

	_itot10(nSel + 2, szOrder);

	lvi.mask = LVIF_TEXT|LVIF_PARAM|LVIF_STATE;
	lvi.iItem = nSel + 1;
	lvi.iSubItem = 0;
	lvi.pszText = szOrder;
	lvi.state = LVIS_SELECTED|LVIS_FOCUSED;
	lvi.stateMask = LVIS_SELECTED|LVIS_FOCUSED;
	lvi.lParam = (LPARAM)nType;

	m_wndList.InsertItem(&lvi);

	lvi.mask = LVIF_TEXT;
	lvi.iSubItem = 1;
	lvi.pszText = szAction;
	_VERIFY(m_wndList.SetItem(&lvi));

	lvi.iSubItem = 2;
	lvi.pszText = szDelay;
	_VERIFY(m_wndList.SetItem(&lvi));

	_itot10(nSel + 1, szOrder);

	lvi.iItem = nSel;
	lvi.iSubItem = 0;
	lvi.pszText = szOrder;
	_VERIFY(m_wndList.SetItem(&lvi));

	CWindow wndDown(GetDlgItem(IDC_DOWN));
	if (nSel < m_wndList.GetItemCount() - 2)
	{
		wndDown.SetFocus();
	}
	else
	{
		wndDown.ModifyStyle(BS_DEFPUSHBUTTON, BS_PUSHBUTTON);
		CWindow(GetDlgItem(IDC_ADD)).SetFocus();
	}

	SetModified();
}

//---------------------------------------------------------------------------
// OnBrowse
//
//  Handles "Browse..." button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CRecoveryPage::OnBrowse()
{
	TCHAR szImagePath[MAX_PATH];
	TCHAR szFilter[256];

	GetDlgItemText(IDC_IMAGE_PATH, szImagePath, countof(szImagePath));
	LoadFilterString(IDS_IMAGE_FILTER, szFilter, countof(szFilter));

	CFileDialog dlgOpen(TRUE, _T("exe"), szImagePath, 
					    OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,
						szFilter, m_hWnd);

	if (dlgOpen.DoModal() == IDOK)
		SetDlgItemText(IDC_COMMAND_LINE, dlgOpen.m_szFileName);
}

//---------------------------------------------------------------------------
// OnResetDelay_KillFocus
//
//  Handles EN_KILLFOCUS notification from the reset count delay edit box.
//  Normalizes the time displayed in the edit box.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CRecoveryPage::OnResetDelay_KillFocus()
{
	DWORD dwInterval;
	TCHAR szOriginal[40];
	TCHAR szNormalized[40];

	GetDlgItemText(IDC_RESET_DELAY, szOriginal, countof(szOriginal));

	if (ParseTimeInterval(szOriginal, &dwInterval))
	{
		FormatTimeInterval(dwInterval, szNormalized, countof(szNormalized));

		if (lstrcmp(szOriginal, szNormalized) != 0)
			SetDlgItemText(IDC_RESET_DELAY, szNormalized);
	}
}

//---------------------------------------------------------------------------
// OnResetCount_Clicked
//
//  Handles "Reset count after" check box.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CRecoveryPage::OnResetCount_Clicked()
{
	EnableDlgItem(IDC_RESET_DELAY, IsDlgButtonChecked(IDC_RESET_COUNT));
	SetModified();
}

//---------------------------------------------------------------------------
// SetListButtons
//
//  Enables and disables buttons associated with the actions list according
//  to the current selection in the list.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  no return value.
//
void
CRecoveryPage::SetListButtons()
{
	BOOL bReadOnly = m_pCtx->bReadOnly;

	_VERIFY(EnableDlgItem(IDC_ADD, !bReadOnly));
	
	int nSel = m_wndList.GetNextItem(-1, LVNI_SELECTED);
	if (nSel == -1)
	{
		// disable all buttons except Add button
		_VERIFY(EnableDlgItem(IDC_REMOVE, FALSE));
		_VERIFY(EnableDlgItem(IDC_CHANGE, FALSE));
		_VERIFY(EnableDlgItem(IDC_UP, FALSE));
		_VERIFY(EnableDlgItem(IDC_DOWN, FALSE));
	}
	else
	{
		int nCount = m_wndList.GetItemCount();
		_VERIFY(EnableDlgItem(IDC_REMOVE, !bReadOnly));
		_VERIFY(EnableDlgItem(IDC_CHANGE, !bReadOnly));
		_VERIFY(EnableDlgItem(IDC_UP, nSel > 0 && !bReadOnly));
		_VERIFY(EnableDlgItem(IDC_DOWN, nSel < nCount - 1 && !bReadOnly));
	}
}

//---------------------------------------------------------------------------
// CheckActionTypes
//
//  Checks which action types are represented in the list and enables or
//  disables the controls accordingly
//
//  Parameters:
//	  none.
//
//  Returns:
//	  no return value.
//
void
CRecoveryPage::CheckActionTypes()
{
	BOOL bReadOnly = m_pCtx->bReadOnly;
	BOOL bHaveProgram = FALSE;
	BOOL bHaveReboot = FALSE;

	int nCount = m_wndList.GetItemCount();
	for (int i = 0; i < nCount; i++)
	{
		UINT nType = (UINT)m_wndList.GetItemData(i);

		if (nType == SC_ACTION_RUN_COMMAND)
			bHaveProgram = TRUE;
		if (nType == SC_ACTION_REBOOT)
			bHaveReboot = TRUE;
	}

	_VERIFY(EnableDlgItem(IDC_COMMAND_LINE, bHaveProgram && !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_BROWSE, bHaveProgram && !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_MESSAGE, bHaveReboot && !bReadOnly));
}

//---------------------------------------------------------------------------
// OnApply
//
//  Called when Apply or OK button is pressed and something was changed
//	on the property page.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to dismiss property sheet, FALSE - to have it to stay.
//
BOOL
CDependenciesPage::OnApply()
{
	if (!m_bDirty)
		return TRUE;

	_ASSERTE(!m_pCtx->bReadOnly);

	SC_HANDLE hService = m_pCtx->hService;
	_ASSERTE(hService != NULL);

	PTSTR pszDep = m_wndDepends.GetRootDependencyInfo();
	if (pszDep == NULL)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
				 ERROR_NOT_ENOUGH_MEMORY);
		return FALSE;
	}

	if (!ChangeServiceConfig(hService, SERVICE_NO_CHANGE, SERVICE_NO_CHANGE,
							 SERVICE_NO_CHANGE, NULL, NULL, NULL, pszDep,
							 NULL, NULL, NULL))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE),
				 GetLastError());

		free(pszDep);
		return FALSE;
	}

	free(pszDep);

	m_bDirty = FALSE;
	return TRUE;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CDependenciesPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	m_wndDepends.SetMainWnd(pMainWnd);
	m_wndDepends.SubclassWindow(GetDlgItem(IDC_DEPENDS_TREE));
	m_wndDepends.SetImageList(pMainWnd->GetImageList(), TVSIL_NORMAL);

	m_wndNeeded = GetDlgItem(IDC_NEEDED_TREE);
	m_wndNeeded.SetImageList(pMainWnd->GetImageList(), TVSIL_NORMAL);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	FormatDlgItem(m_hWnd, IDC_DEPENDS_ON, NULL, 
				  (PCTSTR)pService->m_szDisplayName);
	FormatDlgItem(m_hWnd, IDC_NEEDED_BY, NULL, 
				  (PCTSTR)pService->m_szDisplayName);

	BOOL bReadOnly = m_pCtx->bReadOnly;

	_VERIFY(EnableDlgItem(IDC_ADD, !bReadOnly));
	_VERIFY(EnableDlgItem(IDC_REMOVE, FALSE));

	// insert top-level dependencies
	InsertTopLevelDependencies();

	// insert top-level service dependents
	if (InsertServiceDependents(pService->m_szName, TVI_ROOT) == 0)
	{
		TCHAR szText[80];
		AtlLoadString(IDS_NO_DEPENDENTS, szText, countof(szText));
		m_wndNeeded.InsertItem(szText, 2, 2, TVI_ROOT, TVI_LAST);
	}

	m_bDirty = FALSE;
	return TRUE;
}

//---------------------------------------------------------------------------
// OnDepends_SelChanged
//
//  Handles TVN_SELCHANGED notification from the dependencies tree. Enables
//  Remove button for top-level items in the tree.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CDependenciesPage::OnDepends_SelChanged(
    LPNMHDR pNMHDR
    )
{
	NMTREEVIEW * pnmtv = (NMTREEVIEW *)pNMHDR;
	_ASSERTE(pnmtv != NULL);

	if (m_pCtx->bReadOnly)
		return 0;

	BOOL bEnable = (pnmtv->itemNew.lParam != 0) &&
				   m_wndDepends.GetParentItem(pnmtv->itemNew.hItem) == NULL;

	EnableDlgItem(IDC_REMOVE, bEnable);
	return 0;
}

//---------------------------------------------------------------------------
// OnNeeded_DeleteItem
//
//  Handles TVN_DELETEITEM notification from the dependents tree. Frees
//	any memory associated with the item being deleted.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CDependenciesPage::OnNeeded_DeleteItem(
    LPNMHDR pNMHDR
    )
{
	NMTREEVIEW * pnmtv = (NMTREEVIEW *)pNMHDR;
	_ASSERTE(pnmtv != NULL);

	PVOID pData = (PVOID)pnmtv->itemOld.lParam;
	if (pData != NULL)
		free(pData);

	return 0;
}

//---------------------------------------------------------------------------
// OnNeeded_GetDispInfo
//
//  Handles TVN_GETDISPINFO notification from the dependents tree. Returns
//	the number of children for tree view items.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CDependenciesPage::OnNeeded_GetDispInfo(
    LPNMHDR pNMHDR
    )
{
	NMTVDISPINFO * pnmtvdi = (NMTVDISPINFO *)pNMHDR;
	_ASSERTE(pnmtvdi != NULL);

	pnmtvdi->item.cChildren = 1;
	return 0;
}

//---------------------------------------------------------------------------
// OnNeeded_ItemExpanding
//
//  Handles TVN_ITEMEXPANDING notification from the dependents tree.
//  Inserts children items as needed.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CDependenciesPage::OnNeeded_ItemExpanding(
    LPNMHDR pNMHDR
    )
{
	NMTREEVIEW * pnmtv = (NMTREEVIEW *)pNMHDR;
	_ASSERTE(pnmtv != NULL);

	if (pnmtv->action != TVE_EXPAND)
		return 0;

	if (pnmtv->itemNew.state & TVIS_EXPANDEDONCE)
		return 0;
	
	PTSTR pszService = (PTSTR)pnmtv->itemNew.lParam;
	if (pszService == NULL)
		return 0;

	TVITEM tvi;
	tvi.hItem = pnmtv->itemNew.hItem;
	tvi.mask = TVIF_CHILDREN|TVIF_STATE;
	tvi.cChildren = InsertServiceDependents(pszService, tvi.hItem);
	tvi.state = TVIS_EXPANDEDONCE;
	tvi.stateMask = TVIS_EXPANDEDONCE;

	_VERIFY(m_wndNeeded.SetItem(&tvi));	 

	return 0;
}

//---------------------------------------------------------------------------
// OnAdd
//
//  Handles "Add..." button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CDependenciesPage::OnAdd()
{
	m_wndDepends.AddDependency();
	SetModified();
}

//---------------------------------------------------------------------------
// OnRemove
//
//  Handles "OnRemove" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CDependenciesPage::OnRemove()
{
	CWindow wndRemove(GetDlgItem(IDC_REMOVE));

	if (!m_wndDepends.RemoveDependency())
	{
		wndRemove.ModifyStyle(BS_DEFPUSHBUTTON, BS_PUSHBUTTON);
		wndRemove.EnableWindow(FALSE);

		CWindow(GetDlgItem(IDC_ADD)).SetFocus();
	}
	else
	{
		wndRemove.SetFocus();
	}

	SetModified();
}

//---------------------------------------------------------------------------
// InsertTopLevelDependencies
//
//  Inserts top-level service dependencies.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  number of dependencies inserted.
//
void
CDependenciesPage::InsertTopLevelDependencies()
{
	SC_HANDLE hService = m_pCtx->hService;
	_ASSERTE(hService != NULL);

	DWORD cbNeeded;
	LPQUERY_SERVICE_CONFIG pConfig;

	if (!QueryServiceConfig(hService, NULL, 0, &cbNeeded))
	{
		if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
			return;
	}

	pConfig = (LPQUERY_SERVICE_CONFIG)_alloca(cbNeeded);
	_ASSERTE(pConfig != NULL);

	if (QueryServiceConfig(hService, pConfig, cbNeeded, &cbNeeded))
		m_wndDepends.SetRootDependencyInfo(pConfig->lpDependencies);
}

//---------------------------------------------------------------------------
// InsertServiceDependents
//
//  Inserts dependent services under the specified tree view item.
//
//  Parameters:
//	  pszService - name of the service which dependents to enumerate
//	  hParent	 - parent item handle
//
//  Returns:
//	  number of items inserted.
//
UINT
CDependenciesPage::InsertServiceDependents(
	PCTSTR pszService,
	HTREEITEM hParent
	)
{
	_ASSERTE(pszService != NULL);
	_ASSERTE(hParent != NULL);

	CWaitCursor wait;

	SC_HANDLE hSCM = m_pCtx->pMainWnd->m_hSCM;
	_ASSERTE(hSCM != NULL);

	SC_HANDLE hService = OpenService(hSCM, pszService, 
									 SERVICE_ENUMERATE_DEPENDENTS);
	if (hService == NULL)
		return 0;

	DWORD cbNeeded;
	DWORD cServices;

	if (!EnumDependentServices(hService, SERVICE_STATE_ALL, NULL, 0,
							   &cbNeeded, &cServices))
	{
		if (GetLastError() != ERROR_MORE_DATA)
		{
			_VERIFY(CloseServiceHandle(hService));
			return 0;
		}
	}

	LPENUM_SERVICE_STATUS pStatus =
		(LPENUM_SERVICE_STATUS)malloc(cbNeeded);
	if (pStatus == NULL)
	{
		_VERIFY(CloseServiceHandle(hService));
		return 0;
	}

	if (!EnumDependentServices(hService, SERVICE_STATE_ALL, pStatus, 
							   cbNeeded, &cbNeeded, &cServices))
	{
		free(pStatus);
		_VERIFY(CloseServiceHandle(hService));
		return 0;
	}

	_VERIFY(CloseServiceHandle(hService));

	TVINSERTSTRUCT tvis;
	tvis.hParent = hParent;
	tvis.hInsertAfter = TVI_SORT;
	tvis.item.mask = TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE|
					 TVIF_PARAM|TVIF_CHILDREN;
	tvis.item.iImage = 0;
	tvis.item.iSelectedImage = 0;
	tvis.item.cChildren = I_CHILDRENCALLBACK;

	for (DWORD i = 0; i < cServices; i++)
	{
		tvis.item.pszText = pStatus[i].lpDisplayName;
		tvis.item.lParam = (LPARAM)_tcsdup(pStatus[i].lpServiceName);

		_VERIFY(m_wndNeeded.InsertItem(&tvis));
	}

	free(pStatus);
	return (UINT)cServices;
}


#define SERVICE_GENERIC_READ	(STANDARD_RIGHTS_READ			| \
								 SERVICE_QUERY_CONFIG			| \
								 SERVICE_QUERY_STATUS			| \
								 SERVICE_INTERROGATE			| \
								 SERVICE_ENUMERATE_DEPENDENTS)

#define SERVICE_GENERIC_WRITE	(STANDARD_RIGHTS_WRITE			| \
								 SERVICE_CHANGE_CONFIG)

#define SERVICE_GENERIC_EXECUTE (STANDARD_RIGHTS_EXECUTE		| \
								 SERVICE_START					| \
								 SERVICE_STOP					| \
								 SERVICE_PAUSE_CONTINUE			| \
								 SERVICE_USER_DEFINED_CONTROL)

const SI_ACCESS _AccessRights[] = {
	// general access rights
	{ &GUID_NULL, 
	  SERVICE_GENERIC_READ,
	  MAKEINTRESOURCEW(IDS_GENERIC_READ),
	  SI_ACCESS_GENERAL
	},
	{ &GUID_NULL,
	  SERVICE_GENERIC_WRITE,
	  MAKEINTRESOURCEW(IDS_GENERIC_WRITE),
	  SI_ACCESS_GENERAL
	},
	{ &GUID_NULL,
	  SERVICE_GENERIC_EXECUTE,
	  MAKEINTRESOURCEW(IDS_GENERIC_EXECUTE),
	  SI_ACCESS_GENERAL
	},
	{ &GUID_NULL,
	  DELETE,
	  MAKEINTRESOURCEW(IDS_DELETE),
	  SI_ACCESS_GENERAL
	},
	{ &GUID_NULL,
	  SERVICE_ALL_ACCESS,
	  MAKEINTRESOURCEW(IDS_GENERIC_ALL),
	  SI_ACCESS_GENERAL
	},
	// specific access rights
	{ &GUID_NULL,
	  SERVICE_QUERY_CONFIG,
	  MAKEINTRESOURCEW(IDS_SERVICE_QUERY_CONFIG),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  SERVICE_CHANGE_CONFIG,
	  MAKEINTRESOURCEW(IDS_SERVICE_CHANGE_CONFIG),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  SERVICE_QUERY_STATUS,
	  MAKEINTRESOURCEW(IDS_SERVICE_QUERY_STATUS),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  SERVICE_ENUMERATE_DEPENDENTS,
	  MAKEINTRESOURCEW(IDS_SERVICE_ENUMERATE_DEPENDENTS),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  SERVICE_START,
	  MAKEINTRESOURCEW(IDS_SERVICE_START),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  SERVICE_STOP,
	  MAKEINTRESOURCEW(IDS_SERVICE_STOP),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  SERVICE_PAUSE_CONTINUE,
	  MAKEINTRESOURCEW(IDS_SERVICE_PAUSE_CONTINUE),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  SERVICE_INTERROGATE,
	  MAKEINTRESOURCEW(IDS_SERVICE_INTERROGATE),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  SERVICE_USER_DEFINED_CONTROL,
	  MAKEINTRESOURCEW(IDS_SERVICE_USER_DEFINED_CONTROL),
	  SI_ACCESS_SPECIFIC
	},
	// standard access rights
	{ &GUID_NULL,
	  DELETE,
	  MAKEINTRESOURCEW(IDS_DELETE),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  READ_CONTROL,
	  MAKEINTRESOURCEW(IDS_READ_CONTROL),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  WRITE_DAC,
	  MAKEINTRESOURCEW(IDS_WRITE_DAC),
	  SI_ACCESS_SPECIFIC
	},
	{ &GUID_NULL,
	  WRITE_OWNER,
	  MAKEINTRESOURCEW(IDS_WRITE_OWNER),
	  SI_ACCESS_SPECIFIC
	}
};

const GENERIC_MAPPING _GenericMapping = {
	SERVICE_GENERIC_READ,
	SERVICE_GENERIC_WRITE,
	SERVICE_GENERIC_EXECUTE,
	SERVICE_ALL_ACCESS
};


//---------------------------------------------------------------------------
// Create
//
//  Creates property page.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  property page handle.
//
HPROPSHEETPAGE
CSecurityPageImpl::Create()
{
	HINSTANCE hAclUI = LoadLibrary(_T("aclui.dll"));
	if (hAclUI != NULL)
		return CreateSecurityPage(this);
	else
		return _Base::Create();
}

//---------------------------------------------------------------------------
// GetObjectInformation
//
//  Returns information about the object being edited.
//
//  Parameters:
//	  pObjectInfo - pointer to a structure that receives object information
//
//  Returns:
//	  standard COM return code.
//
STDMETHODIMP
CSecurityPageImpl::GetObjectInformation(
	OUT PSI_OBJECT_INFO pObjectInfo
	)
{
	DWORD dwFlags;
	USES_CONVERSION;

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	// open service handle
	if (m_hService == NULL)
		OpenServiceHandle(pService->m_szName);

	// basic set of flags
	dwFlags = SI_EDIT_PERMS|SI_EDIT_OWNER|SI_ADVANCED|SI_NO_ACL_PROTECT|
			  SI_NO_TREE_APPLY;

	// check if the DACL is read-only
	if ((m_dwAllowed & WRITE_DAC) == 0)
		dwFlags |= SI_READONLY;

	// check if we can take ownership of this object
	if ((m_dwAllowed & WRITE_OWNER) == 0)
		dwFlags |= SI_OWNER_READONLY;

	// add Audit page if we can access SACL
	if ((m_dwAllowed & ACCESS_SYSTEM_SECURITY) != 0)
		dwFlags |= SI_EDIT_AUDITS;

	pObjectInfo->dwFlags = dwFlags;
	pObjectInfo->hInstance = _Module.GetResourceInstance();
	pObjectInfo->pszObjectName = T2W(pService->m_szDisplayName);
	pObjectInfo->pszServerName = (PWSTR)T2CW(pMainWnd->GetMachineName());
	pObjectInfo->pszPageTitle = NULL;

	return S_OK;
}

//---------------------------------------------------------------------------
// GetSecurity
//
//  Retrieves the security descriptor of the object being edited.
//
//  Parameters:
//	  SecurityInformation  - specifies which information to include into the
//						     security descriptor
//	  ppSecurityDescriptor - pointer to a variable that receives a pointer
//							 to the security descriptor
//	  bDefault			   - specifies whether the default security
//							 descriptor should be retrieved
//
//  Returns:
//	  standard COM return code.
//
STDMETHODIMP
CSecurityPageImpl::GetSecurity(
	IN SECURITY_INFORMATION SecurityInformation,
	OUT PSECURITY_DESCRIPTOR * ppSecurityDescriptor,
	IN BOOL bDefault
	)
{
	_UNUSED(bDefault);

	if (ppSecurityDescriptor == NULL)
		return E_POINTER;
	if (m_hService == NULL)
		return E_ACCESSDENIED;

	return GetServiceSecurity(m_hService, SecurityInformation,
							  ppSecurityDescriptor);
}

//---------------------------------------------------------------------------
// SetSecurity
//
//  Sets the security descriptor of the object being edited.
//
//  Parameters:
//	  SecurityInformation  - specifies which information to set
//	  pSecurityDescriptor - pointer to the security descriptor
//
//  Returns:
//	  standard COM return code.
//
STDMETHODIMP
CSecurityPageImpl::SetSecurity(
	IN SECURITY_INFORMATION SecurityInformation,
	IN PSECURITY_DESCRIPTOR pSecurityDescriptor
	)
{
	if (pSecurityDescriptor == NULL)
		return E_POINTER;

	HRESULT hRes = S_OK;

	if (!SetServiceObjectSecurity(m_hService, SecurityInformation,
								  pSecurityDescriptor))
		hRes = HRESULT_FROM_WIN32(GetLastError());

	m_pCtx->bRefresh = TRUE;
	return hRes;
}

//---------------------------------------------------------------------------
// GetAccessRights
//
//  Returns information about the access rights supported by the object 
//  being edited. 
//
//  Parameters:
//	  pObjectType	  - identifies type of the object which access rights
//						are being requested
//	  dwFlags		  - identifies the page being initialized
//	  ppAccess		  - pointer to a variable that receives a pointer to
//						an array of SI_ACCESS structures
//	  pcAccess		  - pointer to a variable that receives the number of
//						items in the array
//	  piDefaultAccess - pointer to a variable that receives the index of
//						the default access rights item in the array
//
//  Returns:
//	  standard COM error code.
//
STDMETHODIMP
CSecurityPageImpl::GetAccessRights(
	IN const GUID * pObjectType,
	IN DWORD dwFlags,
	OUT PSI_ACCESS * ppAccess,
	OUT PULONG pcAccess,
	OUT PULONG piDefaultAccess
	)
{
	_UNUSED(pObjectType);
	_UNUSED(dwFlags);

	if (ppAccess == NULL ||
		pcAccess == NULL ||
		piDefaultAccess == NULL)
		return E_POINTER;
	
	*ppAccess = (PSI_ACCESS)_AccessRights;
	*pcAccess = countof(_AccessRights);
	*piDefaultAccess = 0;

	return S_OK;
}

//---------------------------------------------------------------------------
// MapGeneric
//
//  Maps generic access rights into specific access rights.
//
//  Parameters:
//    pObjectType - specifies object type
//	  pAceFlags   - pointer to the AceFlags member of the ACE_HEADER struc-
//					ture from the ACE whose access mask is being mapped
//    pMask		  - pointer to a variable containing generic access mask to
//					map
// 
//  Returns:
//	  standard COM error code.
//
STDMETHODIMP
CSecurityPageImpl::MapGeneric(
	IN const GUID * pObjectType,
	IN PUCHAR pAceFlags,
	IN OUT PACCESS_MASK pMask
	)
{
	_UNUSED(pObjectType);
	_UNUSED(pAceFlags);

	if (pMask == NULL)
		return E_POINTER;

	MapGenericMask(pMask, (PGENERIC_MAPPING)&_GenericMapping);
	return S_OK;
}

//---------------------------------------------------------------------------
// GetInheritTypes
//
//  Returns information about how the object's ACEs can be inherited by
//  child objects.
//
//  Parameters:
//    ppInheritType - pointer to a variable that receives a pointer to an
//					  array of SI_INHERIT_TYPE structures
//	  pcInheritType - pointer to a variable that receives the number of items
//					  in the array
//
//  Returns:
//    standard COM return code.
//
STDMETHODIMP
CSecurityPageImpl::GetInheritTypes(
	OUT PSI_INHERIT_TYPE * ppInheritType,
	OUT PULONG pcInheritType
	)
{
	if (ppInheritType == NULL ||
		pcInheritType == NULL)
		return E_POINTER;

	*ppInheritType = NULL;
	*pcInheritType = 0;

	return S_OK;
}

//---------------------------------------------------------------------------
// PropertySheetPageCallback
//
//  Notifies the application that an access control editor property page is
//  being created or destroyed.
//
//  Parameters:
//    hWnd  - property page window handle
//	  uMsg  - notification message
//	  nType - type of the page being created or destroyed
//
//  Returns:
//	  standard COM return code.
//
STDMETHODIMP
CSecurityPageImpl::PropertySheetPageCallback(
	HWND hWnd,
	UINT uMsg,
	SI_PAGE_TYPE nType
	)
{
	_UNUSED(hWnd);
	_UNUSED(uMsg);
	_UNUSED(nType);

	return S_OK;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CSecurityPageImpl::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	if (FAILED(OpenServiceHandle(pService->m_szName)))
	{
		EnableDlgItem(IDC_DACL, FALSE);
		EnableDlgItem(IDC_SACL, FALSE);
		EnableDlgItem(IDC_OWNER, FALSE);
	}
	else
	{
		EnableDlgItem(IDC_DACL, m_dwAllowed & (READ_CONTROL|WRITE_DAC));
		EnableDlgItem(IDC_SACL, m_dwAllowed & ACCESS_SYSTEM_SECURITY);
		EnableDlgItem(IDC_OWNER, m_dwAllowed & (READ_CONTROL|WRITE_OWNER));
	}

	return TRUE;
}

//---------------------------------------------------------------------------
// OnDacl
//
//  Handles "Permissions" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CSecurityPageImpl::OnDacl()
{
	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	HRESULT hRes = S_OK;
	DWORD dwStatus = ERROR_SUCCESS;
	PSECURITY_DESCRIPTOR pSecDesc = NULL;
	PACLDLGCONTROL pAclDlgControl = NULL;
	PACLEDITCONTROL pAclEditControl = NULL;
	USES_CONVERSION;

	for (;;)
	{
		// retrieve DACL information
		hRes = GetServiceSecurity(m_hService, 
								  DACL_SECURITY_INFORMATION|
								  OWNER_SECURITY_INFORMATION|
								  GROUP_SECURITY_INFORMATION,
								  &pSecDesc);
		if (FAILED(hRes))
			break;

		hRes = E_OUTOFMEMORY;

		// prepate ACLDLGCONTROL structure
		pAclDlgControl = GetAclDlgControl();
		if (pAclDlgControl == NULL)
			break;

		// prepare ACLEDITCONTROL structure
		pAclEditControl = GetAclEditControl(FALSE);
		if (pAclEditControl == NULL)
			break;

		// invoke DACL editor
		m_dwInfo = DACL_SECURITY_INFORMATION;
		hRes = SedDiscretionaryAclEditor(m_hWnd, 
						_Module.GetResourceInstance(), NULL, pAclDlgControl,
						pAclEditControl, T2W(pService->m_szDisplayName),
						EditCallback, this,  pSecDesc,
						(m_dwAllowed & READ_CONTROL) == 0,
						(m_dwAllowed & WRITE_DAC) == 0, &dwStatus, NULL);

		if (hRes != ERROR_SUCCESS)
			hRes = HRESULT_FROM_WIN32(hRes);

		break;
	}

	if (pSecDesc != NULL)
		LocalFree((HLOCAL)pSecDesc);
	if (pAclDlgControl != NULL)
		free(pAclDlgControl);
	if (pAclEditControl != NULL)
		free(pAclEditControl);

	if (FAILED(hRes))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_DACL_EDITOR_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), hRes);
	}
	else if (dwStatus != ERROR_SUCCESS)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_DACL_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), dwStatus);
	}
}

//---------------------------------------------------------------------------
// OnSacl
//
//  Handles "Audit" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CSecurityPageImpl::OnSacl()
{
	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	HRESULT hRes = S_OK;
	DWORD dwStatus = ERROR_SUCCESS;
	PSECURITY_DESCRIPTOR pSecDesc = NULL;
	PACLDLGCONTROL pAclDlgControl = NULL;
	PACLEDITCONTROL pAclEditControl = NULL;
	USES_CONVERSION;

	for (;;)
	{
		// retrieve SACL information
		hRes = GetServiceSecurity(m_hService, 
								  SACL_SECURITY_INFORMATION,
								  &pSecDesc);
		if (FAILED(hRes))
			break;

		hRes = E_OUTOFMEMORY;

		// prepate ACLDLGCONTROL structure
		pAclDlgControl = GetAclDlgControl();
		if (pAclDlgControl == NULL)
			break;

		// this is kinda hack, but I don't know  how to force the old-style
		// SACL editor to correctly show entries with SERVICE_ALL_ACCESS
		// mask; may be I'll come up with a solution later
		GENERIC_MAPPING Mapping = _GenericMapping;
		Mapping.GenericAll |= SYNCHRONIZE;
		pAclDlgControl->GenericAccessMap = &Mapping;
		pAclDlgControl->SpecificAccessMap = &Mapping;

		// prepare ACLEDITCONTROL structure
		pAclEditControl = GetAclEditControl(TRUE);
		if (pAclEditControl == NULL)
			break;

		// invoke SACL editor
		m_dwInfo = SACL_SECURITY_INFORMATION;
		hRes = SedSystemAclEditor(m_hWnd, _Module.GetResourceInstance(),
						NULL, pAclDlgControl,  pAclEditControl, 
						T2W(pService->m_szDisplayName),  EditCallback,
						this,  pSecDesc,  
						(m_dwAllowed & ACCESS_SYSTEM_SECURITY) == 0, 
						&dwStatus, NULL);

		if (hRes != ERROR_SUCCESS)
			hRes = HRESULT_FROM_WIN32(hRes);
		
		break;
	}

	if (pSecDesc != NULL)
		LocalFree((HLOCAL)pSecDesc);
	if (pAclDlgControl != NULL)
		free(pAclDlgControl);
	if (pAclEditControl != NULL)
		free(pAclEditControl);

	if (FAILED(hRes))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_SACL_EDITOR_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), hRes);
	}
	else if (dwStatus != ERROR_SUCCESS)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_SACL_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), dwStatus);
	}
}

//---------------------------------------------------------------------------
// OnOwner
//
//  Handles "Owner" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CSecurityPageImpl::OnOwner()
{
	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	HRESULT hRes = S_OK;
	DWORD dwStatus = ERROR_SUCCESS;
	PSECURITY_DESCRIPTOR pSecDesc = NULL;
	PACLDLGCONTROL pAclDlgControl = NULL;
	USES_CONVERSION;

	for (;;)
	{
		// retrieve owner information
		hRes = GetServiceSecurity(m_hService, 
								  OWNER_SECURITY_INFORMATION,
								  &pSecDesc);
		if (hRes != E_ACCESSDENIED && FAILED(hRes))
			break;

		hRes = E_OUTOFMEMORY;

		// prepate ACLDLGCONTROL structure
		pAclDlgControl = GetAclDlgControl();
		if (pAclDlgControl == NULL)
			break;

		WCHAR szServiceObject[80];
		LoadStringW(_Module.GetResourceInstance(), IDS_SERVICE_OBJECT,
					szServiceObject, countof(szServiceObject));

		// invoke take ownership dialog
		m_dwInfo = OWNER_SECURITY_INFORMATION;
		hRes = SedTakeOwnership(m_hWnd, _Module.GetResourceInstance(), NULL, 
						szServiceObject, T2W(pService->m_szDisplayName),
						TRUE, EditCallback, this, pSecDesc, 
						(m_dwAllowed & READ_CONTROL) == 0, NULL,
						&dwStatus, pAclDlgControl->HelpInfo, NULL);

		if (hRes != ERROR_SUCCESS)
			hRes = HRESULT_FROM_WIN32(hRes);
		break;
	}

	if (pSecDesc != NULL)
		LocalFree((HLOCAL)pSecDesc);
	if (pAclDlgControl != NULL)
		free(pAclDlgControl);

	if (FAILED(hRes))
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_OWNER_EDITOR_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), hRes);
	}
	else if (dwStatus != ERROR_SUCCESS &&
			 dwStatus != ERROR_FILE_NOT_FOUND)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_OWNER_APPLY_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), dwStatus);
	}
}

//---------------------------------------------------------------------------
// OpenServiceHandle
//
//  Opens service handle with maximum allowed access.
//
//  Parameters:
//    pszService - service name
//
//  Returns:
//	  standard COM return code.
//
HRESULT
CSecurityPageImpl::OpenServiceHandle(
	PCTSTR pszService
	)
{
	_ASSERTE(m_hService == NULL);

	m_dwAllowed = 0;

	SC_HANDLE hSCM = m_pCtx->pMainWnd->m_hSCM;
	_ASSERTE(hSCM != NULL);

	HRESULT hRes = S_OK;
	SC_HANDLE hService;
	BOOL bStatus = FALSE;

	// first, open service with READ_CONTROL access, so we can query
	// its security descriptor
	hService = OpenService(hSCM, pszService, READ_CONTROL);
	if (hService != NULL)
	{
		PSECURITY_DESCRIPTOR pSecDesc = NULL;

		// obtain service security descriptor
		hRes = GetServiceSecurity(hService, OWNER_SECURITY_INFORMATION|
											GROUP_SECURITY_INFORMATION|
											DACL_SECURITY_INFORMATION,
								  &pSecDesc);

		_VERIFY(CloseServiceHandle(hService));

		if (FAILED(hRes))
			return hRes;

		HANDLE hToken;

		// obtain an impersonation token
		_VERIFY(ImpersonateSelf(SecurityImpersonation));

		if (!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY, FALSE, &hToken))
		{
			hRes = HRESULT_FROM_WIN32(GetLastError());
			LocalFree((HLOCAL)pSecDesc);
			return hRes;
		}

		_VERIFY(RevertToSelf());

		BYTE PrivSet[256];
		DWORD cbPrivSet = sizeof(PrivSet);

		// use AccessCheck to determine maximum allowed permissions
		if (!AccessCheck(pSecDesc, hToken, MAXIMUM_ALLOWED,
						 (PGENERIC_MAPPING)&_GenericMapping,
						 (PPRIVILEGE_SET)&PrivSet, &cbPrivSet,
						 &m_dwAllowed, &bStatus))
			hRes = HRESULT_FROM_WIN32(GetLastError());

		if (!bStatus)
			hRes = HRESULT_FROM_WIN32(GetLastError());

		_VERIFY(CloseHandle(hToken));
		LocalFree((HLOCAL)pSecDesc);

		if (FAILED(hRes))
			return hRes;
	}

	BOOL bSecurity = FALSE;
	BOOL bOwnership = FALSE;
	BOOL bForcedOwnership = FALSE;

	// if we have SE_SECURITY_NAME privilege, then also request
	// ACCESS_SYSTEM_SECURITY access right
	if (IsPrivilege(SE_SECURITY_NAME))
	{
		AdjustPrivilege(SE_SECURITY_NAME, TRUE, FALSE, &bSecurity);
		m_dwAllowed |= ACCESS_SYSTEM_SECURITY;
	}

	// if we don't have WRITE_OWNER access, but have SE_TAKE_OWNERSHIP_NAME
	// privilege, then we can get WRITE_OWNER access anyway by enabling
	// this privilege
	if ((m_dwAllowed & WRITE_OWNER) == 0 &&
		IsPrivilege(SE_TAKE_OWNERSHIP_NAME))
	{
		AdjustPrivilege(SE_TAKE_OWNERSHIP_NAME, TRUE, FALSE, &bOwnership);
		m_dwAllowed |= WRITE_OWNER;
		bForcedOwnership = TRUE;
	}
 
	// open the service with maximum allowed rights
	m_hService = OpenService(hSCM, pszService, m_dwAllowed);
	if (m_hService == NULL)
		hRes = HRESULT_FROM_WIN32(GetLastError());

	if (bForcedOwnership)
		AdjustPrivilege(SE_TAKE_OWNERSHIP_NAME, bOwnership, FALSE, NULL);

	if (m_dwAllowed & ACCESS_SYSTEM_SECURITY)
		AdjustPrivilege(SE_SECURITY_NAME, bStatus, FALSE, NULL);
	
	return hRes;
}

//---------------------------------------------------------------------------
// GetServiceSecurity
//
//  Retrieves the security descriptor of the service object.
//
//  Parameters:
//	  hService			  - service handle
//	  SecurityInformation - specifies which information to include in the
//						    security descriptor
//	  ppSecDesc			  - pointer to a variable that receives the security
//							descriptor
//
//  Returns:
//	  standard COM return code.
//
HRESULT
CSecurityPageImpl::GetServiceSecurity(
	SC_HANDLE hService,
	SECURITY_INFORMATION SecurityInformation,
	PSECURITY_DESCRIPTOR * ppSecDesc
	)
{
	DWORD dwError;
	DWORD cbNeeded;
	SECURITY_DESCRIPTOR SecDesc;
	PSECURITY_DESCRIPTOR pSecDesc = &SecDesc;

	// determine how much space we need to allocate
	if (!QueryServiceObjectSecurity(hService, SecurityInformation,
									pSecDesc, 0, &cbNeeded))
	{
		dwError = GetLastError();
		if (dwError != ERROR_INSUFFICIENT_BUFFER)
			return HRESULT_FROM_WIN32(dwError);
	}

	// allocate memory for the security descriptor
	pSecDesc = (PSECURITY_DESCRIPTOR)LocalAlloc(LMEM_FIXED, cbNeeded);
	if (pSecDesc == NULL)
		return E_OUTOFMEMORY;

	// query security information
	if (!QueryServiceObjectSecurity(hService, SecurityInformation,
									pSecDesc, cbNeeded, &cbNeeded))
	{
		dwError = GetLastError();
		LocalFree((HLOCAL)pSecDesc);
		return HRESULT_FROM_WIN32(dwError);
	}

	*ppSecDesc = pSecDesc;
	return S_OK;
}

//---------------------------------------------------------------------------
// GetAclDlgControl
//
//  Creates ACLDLGCONTROL structure.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  pointer to ACLDLGCONTROL structure if successful, or NULL - otherwise.
//
PACLDLGCONTROL
CSecurityPageImpl::GetAclDlgControl()
{
	PACLDLGCONTROL pCtl;

	// determine how much space we have to allocate
	DWORD cb = sizeof(ACLDLGCONTROL) + 
			   sizeof(ACLHELPCONTROL) +
			   80 + 80 + MAX_PATH;

	pCtl = (PACLDLGCONTROL)malloc(cb);
	if (pCtl != NULL)
	{
		memset(pCtl, 0, sizeof(pCtl));

		PACLHELPCONTROL pHelpCtl = (PACLHELPCONTROL)(pCtl + 1);
		PWSTR pszText = (PWSTR)(pHelpCtl + 1);

		pCtl->Version = 0x101;
		pCtl->GenericAccessMap = (PGENERIC_MAPPING)&_GenericMapping;
		pCtl->SpecificAccessMap = (PGENERIC_MAPPING)&_GenericMapping;
		pCtl->HelpInfo = pHelpCtl;

		pCtl->SpecialAccess = pszText;
		pszText += LoadStringW(_Module.GetResourceInstance(), 
							   IDS_SPECIAL_ACCESS, pszText, 80) + 1;

		pCtl->DialogTitle = pszText;
		pszText += LoadStringW(_Module.GetResourceInstance(), 
							   IDS_SERVICE_OBJECT, pszText, 80) + 1;

		pCtl->SubReplaceTitle = NULL;
		pCtl->SubReplaceConfirmation = NULL;

		pHelpCtl->HelpFile = pszText;
		*pszText = 0;
	}

	return pCtl;
}

//---------------------------------------------------------------------------
// GetAclEditControl
//
//  Creates ACLEDITCONTROL structure.
//
//  Parameters:
//	  bAudit - audit dialog flag
//
//  Returns:
//	  pointer to ACLEDITCONTROL structure if successful, or NULL - otherwise.
//
PACLEDITCONTROL
CSecurityPageImpl::GetAclEditControl(
	BOOL bAudit
	)
{
	PACLEDITCONTROL pCtl;

	// determine how much space we have to allocate
	DWORD cb = sizeof(ACLEDITCONTROL) + 
			   countof(_AccessRights) * (sizeof(ACLEDITENTRY) + 80);

	pCtl = (PACLEDITCONTROL)malloc(cb);
	if (pCtl != NULL)
	{
		memset(pCtl, 0, cb);

		pCtl->Entries = (PACLEDITENTRY)(pCtl + 1);

		PACLEDITENTRY pEntries = pCtl->Entries;
		PWSTR pszName = (PWSTR)(pEntries + countof(_AccessRights));

		int iEntry = 0;
		for (int i = 0; i < countof(_AccessRights); i++)
		{
			DWORD dwFlags = _AccessRights[i].dwFlags;
			ACCESS_MASK dwAccess = _AccessRights[i].mask;
			_ASSERTE(dwAccess != 0);

			if (bAudit)
			{
				if (dwFlags & SI_ACCESS_GENERAL)
				{
					if (dwAccess != _GenericMapping.GenericRead &&
						dwAccess != _GenericMapping.GenericWrite &&
						dwAccess != _GenericMapping.GenericExecute)
						continue;
				}
				else if (dwFlags & SI_ACCESS_SPECIFIC)
				{
					// pass this only if it does not fit into one of three
					// generics
					if (dwAccess & (SERVICE_GENERIC_READ |
									SERVICE_GENERIC_WRITE |
									SERVICE_GENERIC_EXECUTE))
						continue;
				}
				
				pEntries[iEntry].Type = 5;
			}
			else
			{
				if (dwAccess == SERVICE_ALL_ACCESS)
					dwAccess = GENERIC_ALL;

				if (dwFlags & SI_ACCESS_SPECIFIC)
					pEntries[iEntry].Type = 2;
				else if (dwFlags & SI_ACCESS_GENERAL)
					pEntries[iEntry].Type = 1;
			}

			pEntries[iEntry].AccessMask = dwAccess;
			pEntries[iEntry].Name = pszName;

			pszName += LoadStringW(_Module.GetResourceInstance(), 
								   LOWORD(_AccessRights[i].pszName),
								   pszName, 80) + 1;

			PWSTR psz = pEntries[iEntry].Name;
			do
			{
				psz = wcschr(psz, L'&');
				if (psz != NULL)
					*psz++ = L'/';
			}
			while (psz != NULL);

			iEntry++;
		}

		pCtl->NumberOfEntries = iEntry;
	}

	return pCtl;
}

//---------------------------------------------------------------------------
// EditCallback
//
//  Applies modified security descriptor.
//
//  Parameters:
//	  pContext  - context pointer
//	  pSecDesc  - pointer to the security descriptor
//	  pdwStatus - pointer to a variable that receives operation status
//
//  Returns:
//    Win32 error code.
//
DWORD 
CALLBACK
CSecurityPageImpl::EditCallback(
	PVOID, 
	PVOID, 
	PVOID pContext, 
	PSECURITY_DESCRIPTOR pSecDesc, 
	PVOID,
	PVOID, 
	PVOID,
	PDWORD pdwStatus
	)
{
	CSecurityPageImpl * pThis = (CSecurityPageImpl *)pContext;
	_ASSERTE(pThis != NULL);

	if (!SetServiceObjectSecurity(pThis->m_hService, pThis->m_dwInfo, 
								  pSecDesc))
		*pdwStatus = GetLastError();

	pThis->m_pCtx->bRefresh = TRUE;
	return ERROR_SUCCESS;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CNoPermPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	SetDlgItemText(IDC_NAME, pService->m_szName);
	SetDlgItemText(IDC_DISPLAY_NAME, pService->m_szDisplayName);

	return TRUE;
}
