// errorbox.h
//
// ErrorBox and ErrorBoxV functions.
//
// $Id: $
//

#ifndef __errorbox_h_included
#define __errorbox_h_included

EXTERN_C
int
CDECL
ErrorBoxA(
    IN HWND hWnd,
    IN HINSTANCE hInstance,
    IN PCSTR pszString,
    IN PCSTR pszTitle,
    IN DWORD dwError,
    ...
    );

EXTERN_C
int
APIENTRY
ErrorBoxVA(
    IN HWND hWnd,
    IN HINSTANCE hInstance,
    IN PCSTR pszString,
    IN PCSTR pszTitle,
    IN DWORD dwError,
    IN va_list * va
    );
    
EXTERN_C
int
CDECL
ErrorBoxW(
    IN HWND hWnd,
    IN HINSTANCE hInstance,
    IN PCWSTR pszString,
    IN PCWSTR pszTitle,
    IN DWORD dwError,
    ...
    );

EXTERN_C
int
APIENTRY
ErrorBoxVW(
    IN HWND hWnd,
    IN HINSTANCE hInstance,
    IN PCWSTR pszString,
    IN PCWSTR pszTitle,
    IN DWORD dwError,
    IN va_list * va
    );

#ifdef _UNICODE
#   define ErrorBox     ErrorBoxW
#   define ErrorBoxV    ErrorBoxVW
#else
#   define ErrorBox     ErrorBoxA
#   define ErrorBoxV    ErrorBoxVA
#endif

#endif // __errorbox_h_included
