// progress.cpp
//
// Progress dialog.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "progress.h"
#include "mainwnd.h"

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CProgressDlg::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
	)
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	// initialize progress control
	SendDlgItemMessage(IDC_PROGRESS, PBM_SETRANGE, 0, MAKELPARAM(0, 100));
	SendDlgItemMessage(IDC_PROGRESS, PBM_SETPOS, 0, 0);

	return TRUE;
}

//---------------------------------------------------------------------------
// OnTimer
//
//  Handles WM_TIMER message. Updates progress control.
//
//  Parameters:
//	  uTimerId - timer identifier
//	  pProc	   - pointer to timer procedure
//
//  Returns:
//	  no return value
//
void
CProgressDlg::OnTimer(
	UINT uTimerId,
	PVOID pProc
	)
{
	_UNUSED(uTimerId);
	_UNUSED(pProc);

	DWORD dwPos = (GetTickCount() - m_dwStartTime) * 100;
	dwPos /= (m_dwFinishTime - m_dwStartTime);

	if (dwPos > 100)
		dwPos = 100;

	if (dwPos > (DWORD)SendDlgItemMessage(IDC_PROGRESS, PBM_GETPOS))
		SendDlgItemMessage(IDC_PROGRESS, PBM_SETPOS, dwPos);
}

//---------------------------------------------------------------------------
// DoIt
//
//  Starts a thread to asyncronously perform a service control operation.
//
//  Parameters:
//	  pszName		 - service name
//	  pszDisplayName - service display name
//	  nOperation	 - operation name string
//	  pProc		     - specifies the procedure to execute
//
//  Returns:
//	  Win32 error code.
//
DWORD
CProgressDlg::DoIt(
	PCTSTR pszName, 
	PCTSTR pszDisplayName, 
	UINT nOperation,
	DWORD (CProgressDlg::* pProc)()
	)
{
	_ASSERTE(pszName != NULL);
	_ASSERTE(pszDisplayName != NULL);
	_ASSERTE(nOperation != 0);
	_ASSERTE(pProc != NULL);
	_ASSERTE(m_hWnd != NULL);
	
	// set operation name
	FormatDlgItem(m_hWnd, IDC_MESSAGE, MAKEINTRESOURCE(nOperation));

	// set service name
	SetDlgItemText(IDC_DISPLAY_NAME, pszDisplayName);

	// remember service name
	m_pszName = pszName;

	// create stop event, if necessary
	if (m_hStop == NULL)
	{
		m_hStop = CreateEvent(NULL, TRUE, FALSE, NULL);
		if (m_hStop == NULL)
			return GetLastError();
	}
	else
		_VERIFY(ResetEvent(m_hStop));

	CThreadData data;
	HANDLE hThread;
	DWORD dwThreadId;

	// prepare thread creation data
	data.pThis = this;
	data.pProc = pProc;

	// record time when the operation starts
	m_dwStartTime = GetTickCount();
	m_dwFinishTime = m_dwStartTime + 60000;

	// set progress to zero
	SendDlgItemMessage(IDC_PROGRESS, PBM_SETPOS, 0, 0);

	// start a thread to asynchronously perform the operation
	hThread = CreateThread(NULL, 0, StaticThreadProc, &data, 0, &dwThreadId);
	if (hThread == NULL)
		return GetLastError();

	// set a timer to update progress control
	SetTimer(1, 500);

	// wait until the thread completes while processing messages
	_VERIFY(AtlWaitWithMessageLoop(hThread));

	// set progress to 100
	SendDlgItemMessage(IDC_PROGRESS, PBM_SETPOS, 100, 0);

	// close thread handle and return
	_VERIFY(CloseHandle(hThread));
	return m_dwError;
}

#pragma warning(disable: 4035)

//---------------------------------------------------------------------------
// StaticThreadProc
//
//  This is the common thread entry point, which unpacks thread parameters
//	and invokes appropriate function.
//
//  Parameters:
//	  pParam - contains a pointer to CThreadData structure
//
//  Returns:
//	  this function does not return, exiting the thread with ExitThread
//	  function.
//
__noreturn
DWORD
CALLBACK
CProgressDlg::StaticThreadProc(
	PVOID pParam
	)
{
	CThreadData * pData = (CThreadData *)pParam;
	_ASSERTE(_CrtIsValidPointer(pParam, sizeof(CThreadData), 1));

	CProgressDlg * pThis = pData->pThis;
	_ASSERTE(pThis != NULL);

	// invoke function
	pThis->m_dwError = (pThis->*(pData->pProc))();

	// exit thread
	ExitThread(pThis->m_dwError);

	_ASSERTE(0);
	__assume(0);
}

#pragma warning(default: 4035)

//---------------------------------------------------------------------------
// StartServiceThread
//
//  Starts a service.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  Win32 error code.
//
DWORD
CProgressDlg::StartServiceThread()
{
	SC_HANDLE hService;
	SERVICE_STATUS ServiceStatus;
	DWORD dwError;

	// open service handle with SERVICE_START access
	hService = OpenService(m_pMainWnd->m_hSCM, m_pszName, 
						   SERVICE_START|SERVICE_QUERY_STATUS);
	if (hService == NULL)
		return GetLastError();

	// try to start the service
	if (StartServiceW(hService, m_nArgc, m_pArgv))
	{
		if (QueryServiceStatus(hService, &ServiceStatus))
			dwError = WaitService(hService, &ServiceStatus, SERVICE_RUNNING);
		else
			dwError = GetLastError();
	}
	else
		dwError = GetLastError();

	_VERIFY(CloseServiceHandle(hService));
	return dwError;
}

//---------------------------------------------------------------------------
// StopServiceThread
//
//  Stops a service.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  Win32 error code.
//
DWORD
CProgressDlg::StopServiceThread()
{
	SC_HANDLE hService;
	SERVICE_STATUS ServiceStatus;
	DWORD dwError;

	// open service handle with SERVICE_STOP access
	hService = OpenService(m_pMainWnd->m_hSCM, m_pszName, 
						   SERVICE_STOP|SERVICE_QUERY_STATUS);
	if (hService == NULL)
		return GetLastError();

	// try to stop the service
	if (!ControlService(hService, SERVICE_CONTROL_STOP, &ServiceStatus))
		dwError = GetLastError();
	else
		dwError = WaitService(hService, &ServiceStatus, SERVICE_STOPPED);

	_VERIFY(CloseServiceHandle(hService));
	return dwError;
}

//---------------------------------------------------------------------------
// PauseServiceThread
//
//  Pauses a service.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  Win32 error code.
//
DWORD
CProgressDlg::PauseServiceThread()
{
	SC_HANDLE hService;
	SERVICE_STATUS ServiceStatus;
	DWORD dwError;

	// open service handle with SERVICE_PAUSE_CONTINUE access
	hService = OpenService(m_pMainWnd->m_hSCM, m_pszName, 
						   SERVICE_PAUSE_CONTINUE|SERVICE_QUERY_STATUS);
	if (hService == NULL)
		return GetLastError();

	// try to stop the service
	if (!ControlService(hService, SERVICE_CONTROL_PAUSE, &ServiceStatus))
		dwError = GetLastError();
	else
		dwError = WaitService(hService, &ServiceStatus, SERVICE_PAUSED);

	_VERIFY(CloseServiceHandle(hService));
	return dwError;
}

//---------------------------------------------------------------------------
// ResumeServiceThread
//
//  Resumes a service.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  Win32 error code.
//
DWORD
CProgressDlg::ResumeServiceThread()
{
	SC_HANDLE hService;
	SERVICE_STATUS ServiceStatus;
	DWORD dwError;

	// open service handle with SERVICE_PAUSE_CONTINUE access
	hService = OpenService(m_pMainWnd->m_hSCM, m_pszName, 
						   SERVICE_PAUSE_CONTINUE|SERVICE_QUERY_STATUS);
	if (hService == NULL)
		return GetLastError();

	// try to stop the service
	if (!ControlService(hService, SERVICE_CONTROL_CONTINUE, &ServiceStatus))
		dwError = GetLastError();
	else
		dwError = WaitService(hService, &ServiceStatus, SERVICE_RUNNING);

	_VERIFY(CloseServiceHandle(hService));
	return dwError;
}

//---------------------------------------------------------------------------
// WaitService
//
//  Waits until the service reaches the specified state.
//
//  Parameters:
//	  hService     - service handle
//	  pStatus      - service status information
//	  dwFinalState - final state
//
//  Returns:
//	  Win32 error code.
//
DWORD
CProgressDlg::WaitService(
	SC_HANDLE hService,
	LPSERVICE_STATUS pStatus,
	DWORD dwFinalState
	)
{
	DWORD dwCheckPoint;
	DWORD dwWait;
	DWORD dwError;

	dwCheckPoint = pStatus->dwCheckPoint;
	dwError = ERROR_SUCCESS;
	dwWait = pStatus->dwWaitHint;

	// some services do not set wait hint, so specify at least
	// one second waiting
	if (dwWait == 0)
		dwWait = 1000;

	// add this value on top of total operation time
	InterlockedExchange((LPLONG)&m_dwFinishTime, GetTickCount() + dwWait);

	// wait until service completely stops
	while (pStatus->dwCurrentState != dwFinalState)
	{
		if (WaitForSingleObject(m_hStop, 1000) == WAIT_OBJECT_0)
		{
			dwError = ERROR_OPERATION_ABORTED;
			break;
		}

		// request service status
		if (!QueryServiceStatus(hService, pStatus))
		{
			dwError = GetLastError();
			break;
		}

		// check if no error has occured
		if (pStatus->dwWin32ExitCode != ERROR_SUCCESS)
		{
			dwError = pStatus->dwWin32ExitCode;
			m_dwSpecificError = pStatus->dwServiceSpecificExitCode;
			break;
		}

		// if checkpoint was changed, then update wait hint value
		if (pStatus->dwCheckPoint != dwCheckPoint)
		{
			dwCheckPoint = pStatus->dwCheckPoint;
			dwWait = pStatus->dwWaitHint;

			// some services do not set wait hint, so specify at least
			// one second waiting
			if (dwWait == 0)
				dwWait = 1000;

			// add this value on top of total operation time
			InterlockedExchangeAdd((LPLONG)&m_dwFinishTime, dwWait);
		}
	}

	return dwError;
}
