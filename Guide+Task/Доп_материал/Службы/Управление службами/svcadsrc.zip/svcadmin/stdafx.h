// stdafx.h
//
// $Id: $
//

#define STRICT
#define _CRTDBG_MAP_ALLOC
#define _ATL_SINGLE_THREADED
#define _WIN32_WINNT		0x0400
#define _WIN32_IE		0x0400
#define _ATL_NO_MP_HEAP
#define _ATL_NO_REBAR_SUPPORT
#define _UNICODE
#define UNICODE
#define INLINE_HRESULT_FROM_WIN32

#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <tchar.h>
#include <aclapi.h>
#include <aclui.h>
#include <sddl.h>
#include <lm.h>
#include <objsel.h>
#include <ntsecapi.h>

#include <limits.h>
#include <malloc.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#pragma intrinsic(memset, memcmp, memcpy, abs)

#define _ATL_DISABLE_DEPRECATED
#include <atlbase.h>

#if _ATL_VER >= 0x0700
#	define _ATL_TMP_IMPL1
#	define BEGIN_MSG_MAP_EX BEGIN_MSG_MAP
#endif

#if (_ATL_VER >= 0x700) && defined(_DEBUG)
#	undef ATLTRACE2
#	define ATLTRACE2  _Atl70TraceFix

inline void _cdecl _Atl70TraceFix(DWORD_PTR dwCategory, UINT nLevel, LPCSTR pszFormat, ...)
{
	va_list ptr;
	va_start(ptr, pszFormat);
	ATL::CTrace::s_trace.TraceV(NULL, -1, atlTraceGeneral, nLevel, pszFormat, ptr);
	va_end(ptr);
}
inline void _cdecl _Atl70TraceFix(DWORD_PTR dwCategory, UINT nLevel, LPCWSTR pszFormat, ...)
{
	va_list ptr;
	va_start(ptr, pszFormat);
	ATL::CTrace::s_trace.TraceV(NULL, -1, atlTraceGeneral, nLevel, pszFormat, ptr);
	va_end(ptr);
}
#endif

#include <atlapp.h>

extern CAppModule _Module;

#include <atlcom.h>
#include <atlwin.h>

#include <atlframe.h>
#include <atldlgs.h>
#include <atlctrls.h>
#include <atlctrlx.h>
#include <atlmisc.h>
#include <atluser.h>
#include <atlcrack.h>

#define CMD_SIMPLE(id, code, func) \
	if (uMsg == WM_COMMAND && code == HIWORD(wParam) && id == LOWORD(wParam)) \
	{ \
		SetMsgHandled(TRUE); \
		func(); \
		lResult = 0; \
		if(IsMsgHandled()) \
			return TRUE; \
	}

#define CMD_ID_SIMPLE(id, func) \
	if (uMsg == WM_COMMAND && id == LOWORD(wParam)) \
	{ \
		SetMsgHandled(TRUE); \
		func(); \
		lResult = 0; \
		if(IsMsgHandled()) \
			return TRUE; \
	}

#include "alexfstd.h"
#include "acledit.h"

#if _ATL_VER >= 0x0700
#	define AtlLoadString	ATL::AtlLoadString
#endif
