// welcmwiz.cpp
//
// Welcome wizard page.
//
// $Id: $
//

#include "stdafx.h"
#include "resource.h"
#include "svcadmin.h"
#include "svcwiz.h"
#include "mainwnd.h"
#include "svcobj.h"
#include "errorbox.h"

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CWelcomePage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	HFONT hFont = CreateLocalFont(MAKEINTRESOURCE(IDS_WIZARD_FONT));
	_ASSERTE(hFont != NULL);

	SendDlgItemMessage(IDC_HEADER, WM_SETFONT, (WPARAM)hFont, 0);
	m_fntHeader.Attach(hFont);

	return TRUE;
}

//---------------------------------------------------------------------------
// OnSetActive
//
//  This function is called before the page is made visible.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow activation of this page, FALSE - to prevent it.
//
BOOL
CPathPage::OnSetActive()
{
	DWORD dwButtons = PSWIZB_BACK;

	if (CWindow(GetDlgItem(IDC_IMAGE_PATH)).GetWindowTextLength() > 0)
		dwButtons |= PSWIZB_NEXT;

	SetWizardButtons(dwButtons);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnWizardNext
//
//  This function is called when the Next button is pressed.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  zero, to allow page change;
//	  -1, to prevent page change;
//	  positive value, to jump to the specific page.
//
int
CPathPage::OnWizardNext()
{
	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	pService->m_dwServiceType &= ~(SERVICE_WIN32_OWN_PROCESS|
								   SERVICE_WIN32_SHARE_PROCESS);

	TCHAR szImagePath[MAX_PATH];
	GetDlgItemText(IDC_IMAGE_PATH, szImagePath, countof(szImagePath));

	// store selected parameters
	lstrcpyn(pService->m_szImagePath, szImagePath,
			 countof(pService->m_szImagePath));

	if (IsDlgButtonChecked(IDC_OWN_PROCESS))
		pService->m_dwServiceType |= SERVICE_WIN32_OWN_PROCESS;
	else
		pService->m_dwServiceType |= SERVICE_WIN32_SHARE_PROCESS;

	return 0;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CPathPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	// load alert bitmap
	OnSysColorChange();

	// hide Browse button and display alternate prompt for remote
	// operation
	if (pMainWnd->GetMachineName() != NULL)
	{
		_VERIFY(ShowDlgItem(IDC_BROWSE, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_PATH_PROMPT_LOCAL, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_PATH_PROMPT_REMOTE, SW_SHOW));
	}

	CheckRadioButton(IDC_OWN_PROCESS, IDC_SHARE_PROCESS, IDC_OWN_PROCESS);

	// set edit limits
	SendDlgItemMessage(IDC_IMAGE_PATH, EM_LIMITTEXT, MAX_PATH - 1);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnSysColorChange
//
//  Handles WM_SYSCOLORCHANGE message. Reloads alert bitmap.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  no return value.
//
void
CPathPage::OnSysColorChange()
{
	if (m_bmpAlert.m_hBitmap != NULL)
		m_bmpAlert.DeleteObject();

	COLORMAP ColorMap;
	ColorMap.from = RGB(0xFF,0x00,0xFF);
	ColorMap.to = GetSysColor(COLOR_3DFACE);

	m_bmpAlert = CreateMappedBitmap(_Module.GetResourceInstance(),
									IDB_ALERT, 0, &ColorMap, 1);

	SendDlgItemMessage(IDC_ALERT, STM_SETIMAGE, IMAGE_BITMAP,
					   (LPARAM)(HBITMAP)m_bmpAlert);

	SetMsgHandled(FALSE);
}

//---------------------------------------------------------------------------
// OnBrowse
//
//  Handles "Browse..." button.
//
//  Parameters:
//	  none.
//
//  Returns:
//    no return value.
//
void
CPathPage::OnBrowse()
{
	TCHAR szImagePath[MAX_PATH];
	TCHAR szFilter[256];

	GetDlgItemText(IDC_IMAGE_PATH, szImagePath, countof(szImagePath));
	LoadFilterString(IDS_IMAGE_FILTER, szFilter, countof(szFilter));

	CFileDialog dlgOpen(TRUE, _T("exe"), szImagePath, 
					    OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,
						szFilter, m_hWnd);

	if (dlgOpen.DoModal() == IDOK)
		SetDlgItemText(IDC_IMAGE_PATH, dlgOpen.m_szFileName);
}

//---------------------------------------------------------------------------
// OnSetActive
//
//  This function is called before the page is made visible.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow activation of this page, FALSE - to prevent it.
//
BOOL
CNamePage::OnSetActive()
{
	DWORD dwButtons = PSWIZB_BACK;

	if (CWindow(GetDlgItem(IDC_NAME)).GetWindowTextLength() > 0 &&
		CWindow(GetDlgItem(IDC_DISPLAY_NAME)).GetWindowTextLength() > 0)
		dwButtons |= PSWIZB_NEXT;

	SetWizardButtons(dwButtons);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnWizardNext
//
//  This function is called when the Next button is pressed.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  zero, to allow page change;
//	  -1, to prevent page change;
//	  positive value, to jump to the specific page.
//
int
CNamePage::OnWizardNext()
{
	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	TCHAR szName[256];
	TCHAR szDisplayName[256];
	PTSTR pszDescription = (PTSTR)&_chNil;

	GetDlgItemText(IDC_NAME, szName, countof(szName));
	GetDlgItemText(IDC_DISPLAY_NAME, szDisplayName, countof(szDisplayName));

	// check the validity of the service name
	if (_tcschr(szName, _T('/')) != NULL ||
		_tcschr(szName, _T('\\')) != NULL)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_INVALID_NAME),
				 MAKEINTRESOURCE(IDS_INSTALL_WIZARD), 0);

		CWindow(GetDlgItem(IDC_NAME)).SetFocus();
		return -1;
	}

	BOOL bNameUsed = FALSE;
	BOOL bDisplayNameUsed = FALSE;

	// check that neither name nor display name is already used
	int nCount = pMainWnd->GetServicesCount();
	for (int i = 0; i < nCount; i++)
	{
		CService * pService = pMainWnd->GetService(i);
		_ASSERTE(pService != NULL);

		if (lstrcmpi(pService->m_szName, szName) == 0)
			bNameUsed = TRUE;
		if (lstrcmpi(pService->m_szDisplayName, szDisplayName) == 0)
			bDisplayNameUsed = TRUE;
	}

	if (bNameUsed)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_DUPLICATE_NAME),
				 MAKEINTRESOURCE(IDS_INSTALL_WIZARD), 0);

		CWindow(GetDlgItem(IDC_NAME)).SetFocus();
		return -1;
	}

	if (bDisplayNameUsed)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_DUPLICATE_DISPLAY_NAME),
				 MAKEINTRESOURCE(IDS_INSTALL_WIZARD), 0);

		CWindow(GetDlgItem(IDC_DISPLAY_NAME)).SetFocus();
		return -1;
	}

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	// store selected parameters
	lstrcpyn(pService->m_szName, szName, 
			 countof(pService->m_szName));
	lstrcpyn(pService->m_szDisplayName, szDisplayName,
			 countof(pService->m_szDisplayName));

	CWindow wndDesc = GetDlgItem(IDC_DESCRIPTION);
	int len = wndDesc.GetWindowTextLength();

	if (len != 0)
	{
		pszDescription = (PTSTR)malloc((len + 1) * sizeof(TCHAR));
		if (pszDescription == NULL)
			return 0;	// just fail silently

		wndDesc.GetWindowText(pszDescription, len + 1);
	}

	if (pService->m_pszDescription != (PTSTR)&_chNil)
		free(pService->m_pszDescription);
	pService->m_pszDescription = pszDescription;

	return 0;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CNamePage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	// set edit limits
	SendDlgItemMessage(IDC_NAME, EM_LIMITTEXT, 256);
	SendDlgItemMessage(IDC_DISPLAY_NAME, EM_LIMITTEXT, 256);

	// hide description related controls if we have no function to
	// set the description
	if (pMainWnd->m_dwMajorVersion < 5 ||
		_ChangeServiceConfig2 == NULL)
	{
		_VERIFY(ShowDlgItem(IDC_DESCRIPTION_INTRO, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_DESCRIPTION_LABEL, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_DESCRIPTION, SW_HIDE));
	}

	return TRUE;
}

//---------------------------------------------------------------------------
// OnSetActive
//
//  This function is called before the page is made visible.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow activation of this page, FALSE - to prevent it.
//
BOOL
CLogonPage::OnSetActive()
{
	DWORD dwButtons = PSWIZB_BACK;

	// if This account option is selected, then enable Next button only
	// if the account name field has some text
	if (IsDlgButtonChecked(IDC_THISACCOUNT))
	{
		if (CWindow(GetDlgItem(IDC_USERNAME)).GetWindowTextLength() > 0)
			dwButtons |= PSWIZB_NEXT;
	}
	else
		dwButtons |= PSWIZB_NEXT;

	SetWizardButtons(dwButtons);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	if ((pService->m_dwServiceType & SERVICE_WIN32_SHARE_PROCESS) != 0 &&
		pMainWnd->m_dwMajorVersion <= 4)
	{
		// check and disable LocalSystem option
		CheckRadioButton(IDC_LOCALSYSTEM, IDC_NETWORKSERVICE, IDC_LOCALSYSTEM);
		_VERIFY(EnableDlgItem(IDC_LOCALSYSTEM, FALSE));

		// hide all other options
		_VERIFY(ShowDlgItem(IDC_THISACCOUNT, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_LOCALSERVICE, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_NETWORKSERVICE, SW_HIDE));

		_VERIFY(ShowDlgItem(IDC_USERNAME, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_PASSWORD, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_CONFIRM, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_BROWSE, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_PASSWORD_LABEL, SW_HIDE));
		_VERIFY(ShowDlgItem(IDC_CONFIRM_LABEL, SW_HIDE));

		if (pMainWnd->GetMachineName() == NULL)
			_VERIFY(ShowDlgItem(IDC_NT4_NOTICE_LOCAL, SW_SHOW));
		else
			_VERIFY(ShowDlgItem(IDC_NT4_NOTICE_REMOTE, SW_SHOW));
	}
	else
	{
		_VERIFY(EnableDlgItem(IDC_LOCALSYSTEM, TRUE));
		_VERIFY(ShowDlgItem(IDC_THISACCOUNT, SW_SHOW));

		_VERIFY(ShowDlgItem(IDC_USERNAME, SW_SHOW));
		_VERIFY(ShowDlgItem(IDC_PASSWORD, SW_SHOW));
		_VERIFY(ShowDlgItem(IDC_CONFIRM, SW_SHOW));
		_VERIFY(ShowDlgItem(IDC_BROWSE, SW_SHOW));
		_VERIFY(ShowDlgItem(IDC_PASSWORD_LABEL, SW_SHOW));
		_VERIFY(ShowDlgItem(IDC_CONFIRM_LABEL, SW_SHOW));

		if (pMainWnd->GetMachineName() == NULL)
			_VERIFY(ShowDlgItem(IDC_NT4_NOTICE_LOCAL, SW_HIDE));
		else
			_VERIFY(ShowDlgItem(IDC_NT4_NOTICE_REMOTE, SW_HIDE));

		// hide LocalService and NetworkService options if not running
		// Windows XP
		if (pMainWnd->m_dwMajorVersion < 5 || 
			pMainWnd->m_dwMajorVersion == 5 && pMainWnd->m_dwMinorVersion < 1)
		{
			ShowDlgItem(IDC_LOCALSERVICE, SW_HIDE);
			ShowDlgItem(IDC_NETWORKSERVICE, SW_HIDE);
		}
	}

	return TRUE;
}

//---------------------------------------------------------------------------
// OnWizardNext
//
//  This function is called when the Next button is pressed.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  zero, to allow page change;
//	  -1, to prevent page change;
//	  positive value, to jump to the specific page.
//
int
CLogonPage::OnWizardNext()
{
	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	pService->m_bLocalSystem = FALSE;
	pService->m_bLocalService = FALSE;
	pService->m_bNetworkService = FALSE;
	pService->m_dwServiceType &= ~SERVICE_INTERACTIVE_PROCESS;

	if (IsDlgButtonChecked(IDC_THISACCOUNT))
	{
		TCHAR szUserName[UNLEN + 3];
		TCHAR szPassword[PWLEN + 1];
		TCHAR szConfirm[PWLEN + 1];

		// retrive user password
		GetDlgItemText(IDC_USERNAME, szUserName + 2, countof(szUserName) - 2);

		// check that two password copies match
		GetDlgItemText(IDC_PASSWORD, szPassword, countof(szPassword));
		GetDlgItemText(IDC_CONFIRM, szConfirm, countof(szConfirm));

		BOOL bMatch = lstrcmp(szPassword, szConfirm) == 0;
		if (!bMatch)
		{
			memset(szConfirm, 0, sizeof(szConfirm));
			memset(szPassword, 0, sizeof(szPassword));

			ErrorBox(m_hWnd, _Module.GetResourceInstance(),
					 MAKEINTRESOURCE(IDP_PASSWORD_MISMATCH),
					 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), 0);

			CWindow(GetDlgItem(IDC_PASSWORD)).SetFocus();
			return -1;
		}

		PTSTR pszUserName = szUserName + 2;
		if (_tcschr(pszUserName, _T('\\')) == NULL)
		{
			szUserName[0] = _T('.');
			szUserName[1] = _T('\\');
			pszUserName = szUserName;
		}

		// remember user name and password entered
		lstrcpyn(pService->m_szLogon, pszUserName,
				 countof(pService->m_szLogon));
		lstrcpyn(m_pCtx->szPassword, szPassword,
				 countof(m_pCtx->szPassword));

		memset(szConfirm, 0, sizeof(szConfirm));
		memset(szPassword, 0, sizeof(szPassword));
	}
	else if (IsDlgButtonChecked(IDC_LOCALSYSTEM))
	{
		pService->m_bLocalSystem = TRUE;
		lstrcpyn(pService->m_szLogon, _szLocalSystem, 
				 countof(pService->m_szLogon));

		if (IsDlgButtonChecked(IDC_INTERACTIVE))
			pService->m_dwServiceType |= SERVICE_INTERACTIVE_PROCESS;
	}
	else if (IsDlgButtonChecked(IDC_LOCALSERVICE))
	{
		pService->m_bLocalService = TRUE;
		lstrcpyn(pService->m_szLogon, _szLocalService, 
				 countof(pService->m_szLogon));
	}
	else if (IsDlgButtonChecked(IDC_NETWORKSERVICE))
	{
		pService->m_bNetworkService = TRUE;
		lstrcpyn(pService->m_szLogon, _szNetworkService, 
				 countof(pService->m_szLogon));
	}
	else
		_ASSERTE(0);

	return 0;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CLogonPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	// start from LocalSystem account
	CheckRadioButton(IDC_LOCALSYSTEM, IDC_NETWORKSERVICE, IDC_LOCALSYSTEM);

	_VERIFY(EnableDlgItem(IDC_USERNAME, FALSE));
	_VERIFY(EnableDlgItem(IDC_PASSWORD, FALSE));
	_VERIFY(EnableDlgItem(IDC_CONFIRM, FALSE));
	_VERIFY(EnableDlgItem(IDC_BROWSE, FALSE));

	FormatDlgItem(m_hWnd, IDC_NT4_NOTICE_REMOTE, NULL, 
				  pMainWnd->GetMachineName());

	return TRUE;
}

//---------------------------------------------------------------------------
// OnAccount_Clicked
//
//  Handles account selection options.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CLogonPage::OnAccount_Clicked()
{
	BOOL bLocalSystem = IsDlgButtonChecked(IDC_LOCALSYSTEM);
	_VERIFY(EnableDlgItem(IDC_INTERACTIVE, bLocalSystem));

	BOOL bThisAccount = IsDlgButtonChecked(IDC_THISACCOUNT);

	_VERIFY(EnableDlgItem(IDC_USERNAME, bThisAccount));
	_VERIFY(EnableDlgItem(IDC_PASSWORD, bThisAccount));
	_VERIFY(EnableDlgItem(IDC_CONFIRM, bThisAccount));

	bThisAccount = bThisAccount && _osvi.dwMajorVersion >= 5;
	_VERIFY(EnableDlgItem(IDC_BROWSE, bThisAccount));

	OnSetActive();
}

//---------------------------------------------------------------------------
// OnBrowse
//
//  Handles "Browse..." button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CLogonPage::OnBrowse()
{
	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	TCHAR szUserName[DNLEN + UNLEN + 2];

	int nRet = BrowseForUser(m_hWnd, pMainWnd->GetMachineName(), szUserName, 
							 countof(szUserName));
	if (nRet == -1)
	{
		ErrorBox(m_hWnd, _Module.GetResourceInstance(),
				 MAKEINTRESOURCE(IDP_BROWSE_FAILED),
				 MAKEINTRESOURCE(IDS_MESSAGE_TITLE), GetLastError());
	}
	else if (nRet == IDOK)
		SetDlgItemText(IDC_USERNAME, szUserName);
}

//---------------------------------------------------------------------------
// OnSetActive
//
//  This function is called before the page is made visible.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow activation of this page, FALSE - to prevent it.
//
BOOL
CStartupPage::OnSetActive()
{
	SetWizardButtons(PSWIZB_BACK|PSWIZB_NEXT);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnWizardNext
//
//  This function is called when the Next button is pressed.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  zero, to allow page change;
//	  -1, to prevent page change;
//	  positive value, to jump to the specific page.
//
int
CStartupPage::OnWizardNext()
{
	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	int nSel = m_wndStartupType.GetCurSel();
	_ASSERTE(nSel != -1);

	pService->m_dwStartupType = (DWORD)m_wndStartupType.GetItemData(nSel);

	nSel = m_wndErrorControl.GetCurSel();
	_ASSERTE(nSel != -1);

	pService->m_dwErrorControl = (DWORD)m_wndErrorControl.GetItemData(nSel);
	return 0;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CStartupPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	m_wndStartupType = GetDlgItem(IDC_STARTUP_TYPE);
	m_wndErrorControl = GetDlgItem(IDC_ERROR_CONTROL);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	int i, nItem;


	// fill startup type combo box
	DWORD dwStartupTypes[3] = {
		SERVICE_AUTO_START,
		SERVICE_DEMAND_START,
		SERVICE_DISABLED
	};
	
	for (i = 0; i < countof(dwStartupTypes); i++)
	{
		PCTSTR psz = pMainWnd->GetStartupTypeString(dwStartupTypes[i]);

		nItem = m_wndStartupType.AddString(psz);
		m_wndStartupType.SetItemData(nItem, dwStartupTypes[i]);
	}

	m_wndStartupType.SetCurSel(1);
	OnStartupType_SelChange();

	// fill error control combo box
	DWORD dwErrorControl[4] = {
		SERVICE_ERROR_IGNORE,
		SERVICE_ERROR_NORMAL,
		SERVICE_ERROR_SEVERE,
		SERVICE_ERROR_CRITICAL
	};
	
	for (i = 0; i < countof(dwErrorControl); i++)
	{
		PCTSTR psz = pMainWnd->GetErrorControlString(dwErrorControl[i]);

		nItem = m_wndErrorControl.AddString(psz);
		m_wndErrorControl.SetItemData(nItem, dwErrorControl[i]);
	}

	m_wndErrorControl.SetCurSel(0);
	OnErrorControl_SelChange();

	return TRUE;
}

//---------------------------------------------------------------------------
// OnStartupType_SelChange
//
//  Called when selection changes in the startup type combo box.
//
//  Parameters:
//	  none.
//
//	Returns:
//	  no return value.
//
void
CStartupPage::OnStartupType_SelChange()
{
	int nItem = m_wndStartupType.GetCurSel();
	_ASSERTE(nItem != -1);

	DWORD dwType = (DWORD)m_wndStartupType.GetItemData(nItem);

	TCHAR szInfo[512];
	AtlLoadString(IDS_SERVICE_AUTO_START_INFO + dwType - 2,
				  szInfo, countof(szInfo));

	SetDlgItemText(IDC_STARTUP_TYPE_INFO, szInfo);
}

//---------------------------------------------------------------------------
// OnErrorControl_SelChange
//
//  Called when selection changes in the error control combo box.
//
//  Parameters:
//	  none.
//
//	Returns:
//	  no return value.
//
void
CStartupPage::OnErrorControl_SelChange()
{
	int nItem = m_wndErrorControl.GetCurSel();
	_ASSERTE(nItem != -1);

	DWORD dwType = (DWORD)m_wndErrorControl.GetItemData(nItem);

	TCHAR szInfo[512];
	AtlLoadString(IDS_SERVICE_ERROR_IGNORE_INFO + dwType,
				  szInfo, countof(szInfo));

	SetDlgItemText(IDC_ERROR_CONTROL_INFO, szInfo);
}

//---------------------------------------------------------------------------
// OnSetActive
//
//  This function is called before the page is made visible.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow activation of this page, FALSE - to prevent it.
//
BOOL
CDepPage::OnSetActive()
{
	SetWizardButtons(PSWIZB_BACK|PSWIZB_NEXT);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnWizardNext
//
//  This function is called when the Next button is pressed.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  zero, to allow page change;
//	  -1, to prevent page change;
//	  positive value, to jump to the specific page.
//
int
CDepPage::OnWizardNext()
{
	SC_HANDLE hService;

	CWaitCursor wait;

	CService * pService = m_pCtx->pService;
	_ASSERTE(pService != NULL);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	// get dependency information
	PTSTR pszDep = m_wndDepends.GetRootDependencyInfo();
	if (pszDep == NULL)
	{
		m_pCtx->dwError = ERROR_NOT_ENOUGH_MEMORY;
		return 0;
	}

	// now we have all information to create a service
	hService = CreateService(m_pCtx->hSCM, pService->m_szName,
						pService->m_szDisplayName, SERVICE_CHANGE_CONFIG, 
						pService->m_dwServiceType, pService->m_dwStartupType,
						pService->m_dwErrorControl, pService->m_szImagePath,
						NULL, NULL, pszDep, pService->m_szLogon,
						m_pCtx->szPassword);
	if (hService == NULL)
	{
		m_pCtx->dwError = GetLastError();
		free(pszDep);
		return 0;
	}

	m_pCtx->dwError = ERROR_SUCCESS;
	m_pCtx->bRightGranted = 0;

	free(pszDep);

	if (!pService->m_bLocalSystem &&
		!pService->m_bLocalService &&
		!pService->m_bNetworkService)
	{
		HRESULT hRes;

		// grant privilege to this account
		hRes = GrantPrivilege(pMainWnd->GetMachineName(), 
							  pService->m_szLogon, SE_SERVICE_LOGON_NAME);
		if (FAILED(hRes))
			m_pCtx->bRightGranted = 0xFF;
		else if (hRes == S_OK)
			m_pCtx->bRightGranted = 1;
	}

	// set service description
	if (pMainWnd->m_dwMajorVersion >= 5 &&
		_ChangeServiceConfig2 != NULL)
	{
		SERVICE_DESCRIPTION Desc;
		Desc.lpDescription = pService->m_pszDescription;

		_ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, &Desc);
	}

	_VERIFY(CloseServiceHandle(hService));
	return 0;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CDepPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	CMainWnd * pMainWnd = m_pCtx->pMainWnd;
	_ASSERTE(pMainWnd != NULL);

	m_wndDepends.SetMainWnd(pMainWnd);
	m_wndDepends.SubclassWindow(GetDlgItem(IDC_DEPENDS_TREE));
	m_wndDepends.SetImageList(pMainWnd->GetImageList(), TVSIL_NORMAL);

	m_wndDepends.SetRootDependencyInfo(_T("\0"));

	EnableDlgItem(IDC_REMOVE, FALSE);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnDepends_SelChanged
//
//  Handles TVN_SELCHANGED notification from the dependencies tree. Enables
//  Remove button for top-level items in the tree.
//
//  Parameters:
//	  pNMHDR - notification parameters
//
//  Returns:
//	  always zero.
//
LRESULT
CDepPage::OnDepends_SelChanged(
    LPNMHDR pNMHDR
    )
{
	NMTREEVIEW * pnmtv = (NMTREEVIEW *)pNMHDR;
	_ASSERTE(pnmtv != NULL);

	BOOL bEnable = (pnmtv->itemNew.lParam != 0) &&
				   m_wndDepends.GetParentItem(pnmtv->itemNew.hItem) == NULL;

	EnableDlgItem(IDC_REMOVE, bEnable);
	return 0;
}

//---------------------------------------------------------------------------
// OnRemove
//
//  Handles "OnRemove" button.
//
//  Parameters:
//    none.
//
//  Returns:
//    no return value.
//
void
CDepPage::OnRemove()
{
	CWindow wndRemove(GetDlgItem(IDC_REMOVE));

	if (!m_wndDepends.RemoveDependency())
	{
		wndRemove.ModifyStyle(BS_DEFPUSHBUTTON, BS_PUSHBUTTON);
		wndRemove.EnableWindow(FALSE);

		CWindow(GetDlgItem(IDC_ADD)).SetFocus();
	}
	else
	{
		wndRemove.SetFocus();
	}
}

//---------------------------------------------------------------------------
// OnSetActive
//
//  This function is called before the page is made visible.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow activation of this page, FALSE - to prevent it.
//
BOOL
CFinishPage::OnSetActive()
{
	DWORD dwButtons = PSWIZB_BACK;
	UINT nIcon = IDB_ALERT;
	
	DWORD dwError = m_pCtx->dwError;
	if (dwError != ERROR_SUCCESS)
	{
		FormatDlgItem(m_hWnd, IDC_HEADER, 
					  MAKEINTRESOURCE(IDS_WIZARD_FAILURE));

		ShowDlgItem(IDC_SUCCESS, SW_HIDE);
		ShowDlgItem(IDC_START, SW_HIDE);

		ShowDlgItem(IDC_STATUS_ICON, SW_SHOW);
		ShowDlgItem(IDC_STATUS, SW_SHOW);

		TCHAR szFormat[256];
		TCHAR szMessage[1024];

		if (!FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwError,
						   0, szMessage, countof(szMessage), NULL))
		{
			// there is no system message - display "Unknown error: <number>"
			AtlLoadString(IDS_UNKNOWN_ERROR, szFormat, countof(szFormat));

			FormatMessage(FORMAT_MESSAGE_FROM_STRING, szFormat, 0, 0, 
						  szMessage, countof(szMessage), 
						  (va_list *)&dwError);
		}

		SetDlgItemText(IDC_STATUS, szMessage);
	}
	else
	{
		FormatDlgItem(m_hWnd, IDC_HEADER, 
					  MAKEINTRESOURCE(IDS_WIZARD_SUCCESS));

		ShowDlgItem(IDC_SUCCESS, SW_SHOW);
		ShowDlgItem(IDC_START, SW_SHOW);
		ShowDlgItem(IDC_ALERT, SW_HIDE);
		ShowDlgItem(IDC_FAILURE, SW_HIDE);

		dwButtons = PSWIZB_FINISH;

		if (m_pCtx->bRightGranted != 0)
		{
			CService * pService = m_pCtx->pService;
			_ASSERTE(pService != NULL);
			
			ShowDlgItem(IDC_STATUS_ICON, SW_SHOW);
			ShowDlgItem(IDC_STATUS, SW_SHOW);

			UINT nMessage;
			if (m_pCtx->bRightGranted == 1)
			{
				nIcon = IDB_INFO;
				nMessage = IDP_SERVICE_LOGON_GRANTED;
			}
			else
				nMessage = IDP_SERVICE_LOGON_NOT_GRANTED;

			FormatDlgItem(m_hWnd, IDC_STATUS, MAKEINTRESOURCE(nMessage),
						  pService->m_szLogon);
		}
	}

	if (m_bmpIcon.m_hBitmap != NULL)
		m_bmpIcon.DeleteObject();

	COLORMAP ColorMap;
	ColorMap.from = RGB(0xFF,0x00,0xFF);
	ColorMap.to = RGB(0xFF,0xFF,0xFF);

	m_bmpIcon = CreateMappedBitmap(_Module.GetResourceInstance(),
								   nIcon, 0, &ColorMap, 1);

	SendDlgItemMessage(IDC_STATUS_ICON, STM_SETIMAGE, IMAGE_BITMAP,
					   (LPARAM)(HBITMAP)m_bmpIcon);

	SetWizardButtons(dwButtons);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnWizardFinish
//
//  This function is called when the Finish button is pressed.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  TRUE, to allow page change, FALSE, to prevent page change.
//
BOOL
CFinishPage::OnWizardFinish()
{
	m_pCtx->bStart = IsDlgButtonChecked(IDC_START);
	return TRUE;
}

//---------------------------------------------------------------------------
// OnInitDialog
//
//  Handles WM_INITDIALOG message. Initializes property page controls.
//
//  Parameters:
//    hWnd   - handle to the window that will receive the focus
//    lParam - dialog creation data
//
//  Returns:
//	  always TRUE.
//
BOOL
CFinishPage::OnInitDialog(
	HWND hWnd,
	LPARAM lParam
    )
{
	_UNUSED(hWnd);
	_UNUSED(lParam);

	HFONT hFont = CreateLocalFont(MAKEINTRESOURCE(IDS_WIZARD_FONT));
	_ASSERTE(hFont != NULL);

	SendDlgItemMessage(IDC_HEADER, WM_SETFONT, (WPARAM)hFont, 0);
	m_fntHeader.Attach(hFont);

	return TRUE;
}
