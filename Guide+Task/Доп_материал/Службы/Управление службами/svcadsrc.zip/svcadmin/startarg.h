// startarg.h
//
// Start arguments dialog.
//
// $Id: $
//

#ifndef __startarg_h_included
#define __startarg_h_included

class CStartArgDlg :
	public CDialogImpl<CStartArgDlg>
{
  public:

	TCHAR	m_szCmdLine[MAX_PATH];

  public:

	enum { IDD = IDD_START_PARAMS };

	BEGIN_MSG_MAP_EX(CStartArgDlg)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDOK, BN_CLICKED, OnOK)
		CMD_SIMPLE(IDCANCEL, BN_CLICKED, OnCancel)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM)
		{ SendDlgItemMessage(IDC_COMMAND_LINE, EM_LIMITTEXT, MAX_PATH-1);
		  return TRUE; }

	// control handlers
	void OnOK()
		{ GetDlgItemText(IDC_COMMAND_LINE, m_szCmdLine, countof(m_szCmdLine));
		  EndDialog(IDOK); }

	void OnCancel()
		{ EndDialog(IDCANCEL); }

};

#endif // __startarg_h_included
