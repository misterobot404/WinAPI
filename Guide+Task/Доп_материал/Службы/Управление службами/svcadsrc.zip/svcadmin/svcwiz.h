// svcwiz.h
//
// Service installation wizard.
//
// $Id: $
//

#ifndef __svcwiz_h_included
#define __svcwiz_h_included

#include "deptree.h"

class CMainWnd;
class CService;

struct CWizCtx {
	CMainWnd *		pMainWnd;				// pointer to the main window
	CService *		pService;				// holds attributes of the service
	SC_HANDLE		hSCM;					// SCM handle (*)
	DWORD			dwError;				// error code
	BYTE			bRightGranted;			// logon as service right granted
	BOOL			bStart;					// start the service
	TCHAR			szPassword[PWLEN + 1];	// logon account password
};

// (*) the handle has SC_MANAGER_CREATE_SERVICE access


// common wizard page base
template <class T>
class ATL_NO_VTABLE CWizardPage :
	public CPropertyPageImpl<T>
{
	typedef CPropertyPageImpl<T> _Base;
	typedef CWizardPage<T> _Self;

  public:

	CWizardPage(CWizCtx * pCtx, UINT nTitle = 0, UINT nSubTitle = 0)
		{ m_pCtx = pCtx;

		  _Base::m_psp.dwFlags |= PSP_USETITLE;
		  _Base::m_psp.pszTitle = MAKEINTRESOURCE(IDS_INSTALL_WIZARD);

		  if (nTitle != 0)
		  {
			  _Base::m_psp.pszHeaderTitle = MAKEINTRESOURCE(nTitle);
			  _Base::m_psp.dwFlags |= PSP_USEHEADERTITLE;
		  }

		  if (nSubTitle != 0)
		  {
			  _Base::m_psp.pszHeaderSubTitle = MAKEINTRESOURCE(nSubTitle);
			  _Base::m_psp.dwFlags |= PSP_USEHEADERSUBTITLE;
		  }	
	
		  if (nTitle == 0 && nSubTitle == 0)
			  _Base::m_psp.dwFlags |= PSP_HIDEHEADER; }

  public:

	BEGIN_MSG_MAP_EX(_Self)
		MSG_WM_ACTIVATE(OnActivate)
		MSG_WM_SYSCOLORCHANGE(OnSysColorChange)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	void OnActivate(UINT fuActive, BOOL, HWND hWndOther)
		{ if (fuActive == WA_INACTIVE && hWndOther != NULL)
		  { 
			CWindow wndActive(hWndOther);

			if (wndActive.GetParent() == GetParent())
				wndActive.CenterWindow(m_hWnd);
		  } }

	void OnSysColorChange()
		{ SendMessageToDescendants(WM_SYSCOLORCHANGE, 0, 0, FALSE);	}

	BOOL EnableDlgItem(UINT nCtrlId, BOOL bEnable)
		{ return ::EnableDlgItem(m_hWnd, nCtrlId, bEnable);	}

	BOOL ShowDlgItem(UINT nCtrlId, INT nCmdShow)
		{ return ::ShowDlgItem(m_hWnd, nCtrlId, nCmdShow); }

  protected:

	CWizCtx *		m_pCtx;			// wizard context
};

// Welcome page
class CWelcomePage : 
	public CWizardPage<CWelcomePage>
{
   typedef CWizardPage<CWelcomePage> _Base;

  public:

	CWelcomePage(CWizCtx * pCtx)
		: CWizardPage<CWelcomePage>(pCtx, 0, 0)
		{ }

  public:

	BOOL OnSetActive()
		{ SetWizardButtons(PSWIZB_NEXT); return TRUE; }

	enum { IDD = IDD_WIZARD_WELCOME };

	BEGIN_MSG_MAP_EX(CWelcomePage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()
 
  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

  protected:

	CFont			m_fntHeader;		// header font
};

// Executable Path page
class CPathPage : 
	public CWizardPage<CPathPage>
{
   typedef CWizardPage<CPathPage> _Base;

  public:

	CPathPage(CWizCtx * pCtx)
		: CWizardPage<CPathPage>(pCtx, IDS_WIZARD_PATH_TITLE,
								 IDS_WIZARD_PATH_SUBTITLE)
		{ }

  public:

	BOOL OnSetActive();
	int OnWizardNext();

	enum { IDD = IDD_WIZARD_PATH };

	BEGIN_MSG_MAP_EX(CPathPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		MSG_WM_SYSCOLORCHANGE(OnSysColorChange)
		CMD_SIMPLE(IDC_IMAGE_PATH, EN_CHANGE, OnSetActive)
		CMD_SIMPLE(IDC_BROWSE, BN_CLICKED, OnBrowse)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);
	void OnSysColorChange();

	// control handlers
	void OnBrowse();

  protected:

	CBitmap		m_bmpAlert;
};

// Service name page
class CNamePage : 
	public CWizardPage<CNamePage>
{
   typedef CWizardPage<CNamePage> _Base;

  public:

	CNamePage(CWizCtx * pCtx)
		: CWizardPage<CNamePage>(pCtx, IDS_WIZARD_NAME_TITLE, 
								 IDS_WIZARD_NAME_SUBTITLE)
		{ }

  public:

	BOOL OnSetActive();
	int OnWizardNext();

	enum { IDD = IDD_WIZARD_NAME };

	BEGIN_MSG_MAP_EX(CNamePage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDC_NAME, EN_CHANGE, OnSetActive)
		CMD_SIMPLE(IDC_DISPLAY_NAME, EN_CHANGE, OnSetActive)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

};

// Logon Account page
class CLogonPage : 
	public CWizardPage<CLogonPage>
{
   typedef CWizardPage<CLogonPage> _Base;

  public:

	CLogonPage(CWizCtx * pCtx)
		: CWizardPage<CLogonPage>(pCtx, IDS_WIZARD_LOGON_TITLE, 
								  IDS_WIZARD_LOGON_SUBTITLE)
		{ }

  public:

	BOOL OnSetActive();
	int OnWizardNext();

	enum { IDD = IDD_WIZARD_LOGON };

	BEGIN_MSG_MAP_EX(CLogonPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDC_LOCALSYSTEM, BN_CLICKED, OnAccount_Clicked)
		CMD_SIMPLE(IDC_LOCALSERVICE, BN_CLICKED, OnAccount_Clicked)
		CMD_SIMPLE(IDC_NETWORKSERVICE, BN_CLICKED, OnAccount_Clicked)
		CMD_SIMPLE(IDC_THISACCOUNT, BN_CLICKED, OnAccount_Clicked)
		CMD_SIMPLE(IDC_BROWSE, BN_CLICKED, OnBrowse)
		CMD_SIMPLE(IDC_USERNAME, EN_CHANGE, OnSetActive)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// control handlers
	void OnAccount_Clicked();
	void OnBrowse();

};

// Startup options page
class CStartupPage : 
	public CWizardPage<CStartupPage>
{
   typedef CWizardPage<CStartupPage> _Base;

  public:

	CStartupPage(CWizCtx * pCtx)
		: CWizardPage<CStartupPage>(pCtx, IDS_WIZARD_STARTUP_TITLE, 
								    IDS_WIZARD_STARTUP_SUBTITLE)
		{ }

  public:

	BOOL OnSetActive();
	int OnWizardNext();

	enum { IDD = IDD_WIZARD_STARTUP };

	BEGIN_MSG_MAP_EX(CStartupPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDC_STARTUP_TYPE, CBN_SELCHANGE, OnStartupType_SelChange)
		CMD_SIMPLE(IDC_ERROR_CONTROL, CBN_SELCHANGE, OnErrorControl_SelChange)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// control handlers
	void OnStartupType_SelChange();
	void OnErrorControl_SelChange();

  protected:

	CComboBox		m_wndStartupType;		// startup type combo box
	CComboBox		m_wndErrorControl;		// error control combo box

};

// Dependencies page
class CDepPage : 
	public CWizardPage<CDepPage>
{
   typedef CWizardPage<CDepPage> _Base;

  public:

	CDepPage(CWizCtx * pCtx)
		: CWizardPage<CDepPage>(pCtx, IDS_WIZARD_DEPS_TITLE, 
								IDS_WIZARD_DEPS_SUBTITLE)
		{ }

  public:

	BOOL OnSetActive();
	int OnWizardNext();

	enum { IDD = IDD_WIZARD_DEPS };

	BEGIN_MSG_MAP_EX(CDepPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		NOTIFY_HANDLER_EX(IDC_DEPENDS_TREE, TVN_SELCHANGED, OnDepends_SelChanged)
		CMD_SIMPLE(IDC_ADD, BN_CLICKED, OnAdd)
		CMD_SIMPLE(IDC_REMOVE, BN_CLICKED, OnRemove)
		CHAIN_MSG_MAP(_Base)
		REFLECT_NOTIFICATIONS()
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// notification handlers
	LRESULT OnDepends_SelChanged(LPNMHDR);

	// control handlers
	void OnAdd()
		{ m_wndDepends.AddDependency(); }

	void OnRemove();

  protected:

	CDepTree		m_wndDepends;

};

// Finish page
class CFinishPage : 
	public CWizardPage<CFinishPage>
{
   typedef CWizardPage<CFinishPage> _Base;

  public:

	CFinishPage(CWizCtx * pCtx)
		: CWizardPage<CFinishPage>(pCtx, 0, 0)
		{ }

  public:

	BOOL OnSetActive();
	BOOL OnWizardFinish();

	enum { IDD = IDD_WIZARD_FINISH };

	BEGIN_MSG_MAP_EX(CFinishPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()
 
  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

  protected:

	CFont			m_fntHeader;		// header font
	CBitmap			m_bmpIcon;			// status icon
};

#endif // __svcwiz_h_included
