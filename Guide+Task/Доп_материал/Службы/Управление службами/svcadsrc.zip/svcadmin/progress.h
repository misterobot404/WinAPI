// progress.h
//
// Progress dialog.
//
// $Id: $
//

#ifndef __progress_h_included
#define __progress_h_included

class CMainWnd;
class CService;

class CProgressDlg : 
	public CDialogImpl<CProgressDlg>
{
  public:

	CProgressDlg(CMainWnd * pMainWnd)
		{ m_pMainWnd = pMainWnd; m_hStop = NULL; }

	~CProgressDlg()
		{ if (m_hStop != NULL) _VERIFY(CloseHandle(m_hStop)); }

	DWORD DoStartService(PCTSTR pszName, PCTSTR pszDisplayName, int nArgc, 
						 PCWSTR * pArgv)
		{ m_nArgc = nArgc; m_pArgv = pArgv;
		  return DoIt(pszName, pszDisplayName, 
					  IDS_PROGRESS_START, StartServiceThread); }

	DWORD DoStopService(PCTSTR pszName, PCTSTR pszDisplayName)
		{ return DoIt(pszName, pszDisplayName, 
					  IDS_PROGRESS_STOP, StopServiceThread); }

	DWORD DoPauseService(PCTSTR pszName, PCTSTR pszDisplayName)
		{ return DoIt(pszName, pszDisplayName, 
					  IDS_PROGRESS_PAUSE, PauseServiceThread); }

	DWORD DoResumeService(PCTSTR pszName, PCTSTR pszDisplayName)
		{ return DoIt(pszName, pszDisplayName, 
					  IDS_PROGRESS_RESUME, ResumeServiceThread); }

	DWORD GetServiceSpecificError()
		{ return m_dwSpecificError;	}

  public:

	enum { IDD = IDD_PROGRESS };

	BEGIN_MSG_MAP_EX(CProgressDlg)
		MSG_WM_INITDIALOG(OnInitDialog)
		MSG_WM_TIMER(OnTimer)
		CMD_SIMPLE(IDCANCEL, BN_CLICKED, OnCancel)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);
	void OnTimer(UINT, PVOID);

	// control handlers
	void OnCancel()
		{ _VERIFY(SetEvent(m_hStop)); }

  protected:

	// thread creation data
	struct CThreadData {
		CProgressDlg *			pThis;		// this pointer
		DWORD (CProgressDlg::*	pProc)();	// function to execute
	};

	CMainWnd *		m_pMainWnd;			// pointer to the main window
	DWORD			m_dwStartTime;		// operation start time
	DWORD			m_dwFinishTime;		// expected operation finish time (*)
	DWORD			m_dwError;			// error code
	DWORD			m_dwSpecificError;	// service specific error code
	PCTSTR			m_pszName;			// service name
	HANDLE			m_hStop;			// thread stop event
	int				m_nArgc;			// number of arguments
	PCWSTR *		m_pArgv;			// vector of arguments

	// (*) this is the only variable which is accessed by two threads
	//     simultaneously

  protected:

	DWORD DoIt(PCTSTR, PCTSTR, UINT, DWORD (CProgressDlg::*)());

	DWORD StartServiceThread();
	DWORD StopServiceThread();
	DWORD PauseServiceThread();
	DWORD ResumeServiceThread();

	DWORD WaitService(SC_HANDLE, LPSERVICE_STATUS, DWORD);

	__noreturn static DWORD CALLBACK StaticThreadProc(PVOID);

};

#endif // __progress_h_included
