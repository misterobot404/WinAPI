// deptree.h
//
// Service dependency tree.
//
// $Id: $
//

#ifndef __deptree_h_included
#define __deptree_h_included

class CMainWnd;

// Add dependency dialog
class CAddDepDlg :
	public CDialogImpl<CAddDepDlg>
{
  public:

	CMainWnd *	m_pMainWnd;
	PCTSTR		m_pszDep;
	BOOL		m_bGroup;
	TCHAR		m_szName[256];

  public:

	enum { IDD = IDD_DEPENDENCY_ADD };

	BEGIN_MSG_MAP_EX(CAddDepDlg)
		MSG_WM_ACTIVATE(OnActivate)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDOK, BN_CLICKED, OnOK)
		CMD_SIMPLE(IDCANCEL, BN_CLICKED, OnCancel)
		CMD_SIMPLE(IDC_SERVICE, BN_CLICKED, OnOption)
		CMD_SIMPLE(IDC_GROUP, BN_CLICKED, OnOption)
	END_MSG_MAP()

  protected:
 
	// message handlers
	void OnActivate(UINT, BOOL, HWND);
	BOOL OnInitDialog(HWND, LPARAM);

	// control handlers
	void OnOK();
	void OnOption();

	void OnCancel()
		{ EndDialog(IDCANCEL); }

  protected:

	BOOL EnableDlgItem(UINT nCtrlId, BOOL bEnable)
		{ return ::EnableDlgItem(m_hWnd, nCtrlId, bEnable);	}

};

template <class T>
class CDepTreeImpl : public CWindowImpl<T>
{
  public:

	CDepTreeImpl(HWND)
		{ }
};

class CDepTree :
	public CTreeViewCtrlT<CDepTreeImpl<CDepTree> >
{
   typedef CTreeViewCtrlT<CDepTreeImpl<CDepTree> > _Base;

  public:

	void SetMainWnd(CMainWnd * pMainWnd)
		{ m_pMainWnd = pMainWnd; }

	void SetRootDependencyInfo(PCTSTR pszDeps);
	PTSTR GetRootDependencyInfo();

	BOOL AddDependency();
	BOOL RemoveDependency();

  public:

	BEGIN_MSG_MAP_EX(CDepTree)
		REFLECTED_NOTIFY_CODE_HANDLER_EX(TVN_DELETEITEM, OnDeleteItem)
		REFLECTED_NOTIFY_CODE_HANDLER_EX(TVN_GETDISPINFO, OnGetDispInfo)
		REFLECTED_NOTIFY_CODE_HANDLER_EX(TVN_ITEMEXPANDING, OnItemExpanding)
		DEFAULT_REFLECTION_HANDLER()
	END_MSG_MAP()

  protected:

	// notification handlers
	LRESULT OnDeleteItem(LPNMHDR);
	LRESULT OnGetDispInfo(LPNMHDR);
	LRESULT OnItemExpanding(LPNMHDR);

  protected:

	CMainWnd *		m_pMainWnd;

  protected:
	
	enum {
		ISI_SERVICE,
		ISI_DISPLAY_NAME,
		ISI_GROUP
	};

	UINT InsertDependencies(PCTSTR, HTREEITEM);
	BOOL InsertServiceItem(PCTSTR, HTREEITEM, DWORD);
};

#endif // __deptree_h_included
