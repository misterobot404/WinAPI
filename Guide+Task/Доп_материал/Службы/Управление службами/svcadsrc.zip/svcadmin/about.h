// about.h
//
// About dialog.
//
// $Id: $
//

#ifndef __about_h_included
#define __about_h_included

class CAboutDlg : public CDialogImpl<CAboutDlg>
{
  public:

	enum { IDD = IDD_ABOUT };

	BEGIN_MSG_MAP_EX(CAboutDlg)
		MSG_WM_CTLCOLORDLG(OnCtlColorDlg)
		MSG_WM_CTLCOLORSTATIC(OnCtlColorStatic)
		MSG_WM_INITDIALOG(OnInitDialog)
		MSG_WM_SETCURSOR(OnSetCursor)
		CMD_SIMPLE(IDOK, BN_CLICKED, OnOK)
		CMD_SIMPLE(IDC_URL, STN_CLICKED, OnUrl)
	END_MSG_MAP()

  protected:

	HBRUSH OnCtlColorDlg(HDC, HWND);
	HBRUSH OnCtlColorStatic(HDC, HWND);
	BOOL OnInitDialog(HWND, LPARAM);
	BOOL OnSetCursor(HWND, UINT, UINT);

	void OnOK()
		{ EndDialog(0); }

	void OnUrl()
		{ ShellExecute(GetParent(), _T("open"), _T("http://www.rsdn.ru/"), 
					   NULL, NULL, SW_SHOWNORMAL); }

  protected:

	CFont	m_fntHeader;
	CFont	m_fntBold;
	CFont	m_fntUnderline;
	HWND	m_hWndUrl;
	HCURSOR	m_hCursor;
	CBitmap	m_bmpBack;
};

#endif // __aboutdlg_h_included
