// svcprop.h
//
// Service property pages.
//
// $Id: $
//

#ifndef __svcprop_h_included
#define __svcprop_h_included

#include "deptree.h"

class CMainWnd;
class CService;

// this structure describes the context for property pages when editing
// service properties
struct CPropCtx {
	CMainWnd *		pMainWnd;		// pointer to the main window
	CService *		pService;		// pointer to the service object
	SC_HANDLE		hService;		// service handle (*)
	BOOL			bReadOnly;		// read-only flag
	BOOL			bRefresh;		// refresh is required
};

// (*) the handle has at least SERVICE_QUERY_CONFIG access; it may also
//     have SERVICE_CHANGE_CONFIG access, in this case bReadOnly is set
//	   to FALSE.

// this is the common base for all service property pages
template <class T>
class ATL_NO_VTABLE CServicePage : 
	public CPropertyPageImpl<T>
{
	typedef CPropertyPageImpl<T> _Base;
	typedef CServicePage<T> _Self;

  public:

	CServicePage(CPropCtx * pCtx)
		{ m_pCtx = pCtx; }

  public:

	BEGIN_MSG_MAP_EX(_Self)
		MSG_WM_ACTIVATE(OnActivate)
		MSG_WM_SYSCOLORCHANGE(OnSysColorChange)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	void OnActivate(UINT fuActive, BOOL, HWND hWndOther)
		{ if (fuActive == WA_INACTIVE && hWndOther != NULL)
		  { 
			CWindow wndActive(hWndOther);

			if (wndActive.GetParent() == GetParent())
				wndActive.CenterWindow(m_hWnd);
		  } }

	void OnSysColorChange()
		{ SendMessageToDescendants(WM_SYSCOLORCHANGE, 0, 0, FALSE);	}

	void SetModified()
		{ _Base::SetModified(m_bDirty = TRUE); }

	BOOL EnableDlgItem(UINT nCtrlId, BOOL bEnable)
		{ return ::EnableDlgItem(m_hWnd, nCtrlId, bEnable);	}

	BOOL ShowDlgItem(UINT nCtrlId, INT nCmdShow)
		{ return ::ShowDlgItem(m_hWnd, nCtrlId, nCmdShow); }

  protected:

	CPropCtx *	m_pCtx;				// property sheet context		
	BOOL		m_bDirty;			// dirty flag

};

// General property page
class CGeneralPage : 
	public CServicePage<CGeneralPage>
{
   typedef CServicePage<CGeneralPage> _Base;

  public:

	CGeneralPage(CPropCtx * pCtx)
	  : CServicePage<CGeneralPage>(pCtx) { }

  public:

	BOOL OnApply();
	BOOL OnKillActive();

	enum { IDD = IDD_GENERAL_PAGE };

	BEGIN_MSG_MAP_EX(CGeneralPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDC_DISPLAY_NAME, EN_CHANGE, SetModified)
		CMD_SIMPLE(IDC_DESCRIPTION, EN_CHANGE, SetModified)
		CMD_SIMPLE(IDC_IMAGE_PATH, EN_CHANGE, SetModified)
		CMD_SIMPLE(IDC_STARTUP_TYPE, CBN_SELCHANGE, SetModified)
		CMD_SIMPLE(IDC_OWN_PROCESS, BN_CLICKED, SetModified)
		CMD_SIMPLE(IDC_SHARE_PROCESS, BN_CLICKED, SetModified)
		CMD_SIMPLE(IDC_BROWSE, BN_CLICKED, OnBrowse)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// control handlers
	void OnBrowse();

  protected:

	CComboBox	m_wndStartupType;	// startup type combo

};

// Advanced property page
class CAdvancedPage : 
	public CServicePage<CAdvancedPage>
{
   typedef CServicePage<CAdvancedPage> _Base;

  public:

	CAdvancedPage(CPropCtx * pCtx)
	  : CServicePage<CAdvancedPage>(pCtx) { }

  public:

	BOOL OnApply();
	BOOL OnKillActive();

	enum { IDD = IDD_ADVANCED_PAGE };

	BEGIN_MSG_MAP_EX(CAdvancedPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDC_LOCALSYSTEM, BN_CLICKED, OnAccount_Clicked)
		CMD_SIMPLE(IDC_LOCALSERVICE, BN_CLICKED, OnAccount_Clicked)
		CMD_SIMPLE(IDC_NETWORKSERVICE, BN_CLICKED, OnAccount_Clicked)
		CMD_SIMPLE(IDC_THISACCOUNT, BN_CLICKED, OnAccount_Clicked)
		CMD_SIMPLE(IDC_INTERACTIVE, BN_CLICKED, SetModified)
		CMD_SIMPLE(IDC_BROWSE, BN_CLICKED, OnBrowse)
		CMD_SIMPLE(IDC_USERNAME, EN_CHANGE, OnCredential_Change)
		CMD_SIMPLE(IDC_PASSWORD, EN_CHANGE, OnCredential_Change)
		CMD_SIMPLE(IDC_CONFIRM, EN_CHANGE, OnCredential_Change)
		CMD_SIMPLE(IDC_LOAD_GROUP, CBN_SELCHANGE, SetModified)
		CMD_SIMPLE(IDC_LOAD_GROUP, CBN_EDITCHANGE, SetModified)
		CMD_SIMPLE(IDC_ERROR_CONTROL, CBN_SELCHANGE, SetModified)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// control handlers
	void OnAccount_Clicked();
	void OnBrowse();

	void OnCredential_Change()
		{ SetModified(); m_bPassword = TRUE; }

  protected:

	CComboBox	m_wndLoadGroup;		// load order group combo box
	CComboBox	m_wndErrorControl;	// error control combo box
	BOOL		m_bPassword;		// password was touched

};

// recovery action selection dialog
class CActionDlg :
	public CDialogImpl<CActionDlg>
{
  public:

	UINT		m_nType;		// action type
	TCHAR		m_szDelay[40];	// action delay

  public:

	enum { IDD = IDD_RECOVERY_ACTION };

	BEGIN_MSG_MAP_EX(CActionDlg)
		MSG_WM_ACTIVATE(OnActivate)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDC_DELAY, EN_KILLFOCUS, OnDelay_KillFocus)
		CMD_SIMPLE(IDOK, BN_CLICKED, OnOK)
		CMD_SIMPLE(IDCANCEL, BN_CLICKED, OnCancel)
	END_MSG_MAP()

  protected:

	// message handlers
	void OnActivate(UINT, BOOL, HWND);
	BOOL OnInitDialog(HWND, LPARAM	);

	// control handlers
	void OnDelay_KillFocus();
	void OnOK();

	void OnCancel()
		{ EndDialog(IDCANCEL); }
};

// Recovery property page
class CRecoveryPage : 
	public CServicePage<CRecoveryPage>
{
   typedef CServicePage<CRecoveryPage> _Base;

  public:

	CRecoveryPage(CPropCtx * pCtx)
	  : CServicePage<CRecoveryPage>(pCtx) { }

  public:

	BOOL OnApply();
	BOOL OnKillActive();

	enum { IDD = IDD_RECOVERY_PAGE };

	BEGIN_MSG_MAP_EX(CRecoveryPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		NOTIFY_HANDLER_EX(IDC_ACTIONS, NM_DBLCLK, OnActions_DblClk)
		NOTIFY_HANDLER_EX(IDC_ACTIONS, LVN_ITEMCHANGED, OnActions_ItemChanged)
		CMD_SIMPLE(IDC_ADD, BN_CLICKED, OnAdd)
		CMD_SIMPLE(IDC_REMOVE, BN_CLICKED, OnRemove)
		CMD_SIMPLE(IDC_CHANGE, BN_CLICKED, OnChange)
		CMD_SIMPLE(IDC_UP, BN_CLICKED, OnUp)
		CMD_SIMPLE(IDC_DOWN, BN_CLICKED, OnDown)
		CMD_SIMPLE(IDC_BROWSE, BN_CLICKED, OnBrowse)
		CMD_SIMPLE(IDC_COMMAND_LINE, EN_CHANGE, SetModified)
		CMD_SIMPLE(IDC_MESSAGE, EN_CHANGE, SetModified)
		CMD_SIMPLE(IDC_RESET_DELAY, EN_CHANGE, SetModified)
		CMD_SIMPLE(IDC_RESET_DELAY, EN_KILLFOCUS, OnResetDelay_KillFocus)
		CMD_SIMPLE(IDC_RESET_COUNT, BN_CLICKED, OnResetCount_Clicked)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// notification handlers
	LRESULT OnActions_DblClk(LPNMHDR);

	LRESULT OnActions_ItemChanged(LPNMHDR)
		{ SetListButtons(); return 0; }

	// control handlers
	void OnAdd();
	void OnRemove();
	void OnChange();
	void OnUp();
	void OnDown();
	void OnBrowse();
	void OnResetDelay_KillFocus();
	void OnResetCount_Clicked();

  protected:

	CListViewCtrl	m_wndList;	// failure actions list

  protected:

	void SetListButtons();
	void CheckActionTypes();

};

// Dependencies property page
class CDependenciesPage :
	public CServicePage<CDependenciesPage>
{
   typedef CServicePage<CDependenciesPage> _Base;

  public:

	CDependenciesPage(CPropCtx * pCtx)
	  : CServicePage<CDependenciesPage>(pCtx) { }

  public:

	BOOL OnApply();

	enum { IDD = IDD_DEPENDENCIES_PAGE };

	BEGIN_MSG_MAP_EX(CDependenciesPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		NOTIFY_HANDLER_EX(IDC_DEPENDS_TREE, TVN_SELCHANGED, OnDepends_SelChanged)
		NOTIFY_HANDLER_EX(IDC_NEEDED_TREE, TVN_DELETEITEM, OnNeeded_DeleteItem)
		NOTIFY_HANDLER_EX(IDC_NEEDED_TREE, TVN_GETDISPINFO, OnNeeded_GetDispInfo)
		NOTIFY_HANDLER_EX(IDC_NEEDED_TREE, TVN_ITEMEXPANDING, OnNeeded_ItemExpanding)
		CMD_SIMPLE(IDC_ADD, BN_CLICKED, OnAdd)
		CMD_SIMPLE(IDC_REMOVE, BN_CLICKED, OnRemove)
		CHAIN_MSG_MAP(_Base)
		REFLECT_NOTIFICATIONS()
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// notification handlers
	LRESULT OnDepends_SelChanged(LPNMHDR);
	LRESULT OnNeeded_DeleteItem(LPNMHDR);
	LRESULT OnNeeded_GetDispInfo(LPNMHDR);
	LRESULT OnNeeded_ItemExpanding(LPNMHDR);

	// control handlers
	void OnAdd();
	void OnRemove();

  protected:

	CDepTree		m_wndDepends;		// dependencies
	CTreeViewCtrl	m_wndNeeded;		// dependents

  protected:

	void InsertTopLevelDependencies();
	UINT InsertServiceDependents(PCTSTR, HTREEITEM);

};

// Security property page
class ATL_NO_VTABLE CSecurityPageImpl : 
	public CServicePage<CSecurityPageImpl>,
	public CComObjectRootEx<CComSingleThreadModel>,
	public ISecurityInformation
{
   typedef CServicePage<CSecurityPageImpl> _Base;

  public:

	CSecurityPageImpl()
	  : CServicePage<CSecurityPageImpl>(NULL) 
		{ m_hService = NULL; }

	~CSecurityPageImpl()
		{ if (m_hService != NULL) _VERIFY(CloseServiceHandle(m_hService)); }

	void SetContext(CPropCtx * pCtx)
		{ _ASSERTE(pCtx != NULL); m_pCtx = pCtx; }

	HPROPSHEETPAGE Create();

  public:

	// ISecurityInformation
	STDMETHOD(GetObjectInformation)(PSI_OBJECT_INFO);
	STDMETHOD(GetSecurity)(SECURITY_INFORMATION, PSECURITY_DESCRIPTOR *, BOOL);
	STDMETHOD(SetSecurity)(SECURITY_INFORMATION, PSECURITY_DESCRIPTOR);
	STDMETHOD(GetAccessRights)(const GUID *, DWORD, PSI_ACCESS *, PULONG, PULONG);
	STDMETHOD(MapGeneric)(const GUID *, PUCHAR, PACCESS_MASK);
	STDMETHOD(GetInheritTypes)(PSI_INHERIT_TYPE *, PULONG);
	STDMETHOD(PropertySheetPageCallback)(HWND, UINT, SI_PAGE_TYPE);

	BEGIN_COM_MAP(CSecurityPageImpl)
		COM_INTERFACE_ENTRY_IID(IID_ISecurityInformation, ISecurityInformation)
	END_COM_MAP()

  public:

	enum { IDD = IDD_SECURITY_PAGE };

	BEGIN_MSG_MAP_EX(CGeneralPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CMD_SIMPLE(IDC_DACL, BN_CLICKED, OnDacl)
		CMD_SIMPLE(IDC_SACL, BN_CLICKED, OnSacl)
		CMD_SIMPLE(IDC_OWNER, BN_CLICKED, OnOwner)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

	// control handlers
	void OnDacl();
	void OnSacl();
	void OnOwner();

  protected:

	SC_HANDLE		m_hService;			// service handle
	DWORD			m_dwAllowed;		// allowed access
	DWORD			m_dwInfo;			// information being set

  protected:

	HRESULT OpenServiceHandle(PCTSTR pszName);
	HRESULT GetServiceSecurity(SC_HANDLE, SECURITY_INFORMATION,
							   PSECURITY_DESCRIPTOR *);

	PACLDLGCONTROL GetAclDlgControl();
	PACLEDITCONTROL GetAclEditControl(BOOL bAudit);
	static DWORD CALLBACK EditCallback(PVOID, PVOID, PVOID, 
						PSECURITY_DESCRIPTOR, PVOID, PVOID,  PVOID, PDWORD);

};

typedef CComObjectGlobal<CSecurityPageImpl> CSecurityPage;

// No permission General property page
class CNoPermPage :
	public CServicePage<CNoPermPage>
{
   typedef CServicePage<CNoPermPage> _Base;

  public:

	CNoPermPage(CPropCtx * pCtx)
	  : CServicePage<CNoPermPage>(pCtx) { }

  public:

	enum { IDD = IDD_NOPERM_PAGE };

	BEGIN_MSG_MAP_EX(CNoPermPage)
		MSG_WM_INITDIALOG(OnInitDialog)
		CHAIN_MSG_MAP(_Base)
	END_MSG_MAP()

  protected:

	// message handlers
	BOOL OnInitDialog(HWND, LPARAM);

};

#endif // __svcprop_h_included
