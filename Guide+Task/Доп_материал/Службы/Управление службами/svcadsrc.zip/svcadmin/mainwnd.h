// mainwnd.h
//
// Main application window.
//
// $Id: $
//

#ifndef __mainwnd_h_included
#define __mainwnd_h_included

class CService;

// main window 
class CMainWnd : public CFrameWindowImpl<CMainWnd>,
				 public CUpdateUI<CMainWnd>,
				 public CIdleHandler,
				 public CMessageFilter
{
   typedef CFrameWindowImpl<CMainWnd> _Base;
   typedef CUpdateUI<CMainWnd> _UpdateUI;

  public:

	SC_HANDLE		m_hSCM;					// SCM handle
	DWORD			m_dwMajorVersion;		// major OS version (*)
	DWORD			m_dwMinorVersion;		// minor OS version (*)

    // (*) When connected to a remote computer, these values reflect
	//     the operating system version on the remote computer.

  public:

	CMainWnd() // don't do like this, ever
		{ memset(&m_hSCM, 0, sizeof(*this) - offsetof(CMainWnd, m_hSCM)); }

	void RestoreWindowPos(int nShowCmd);

	PCTSTR GetMachineName()
		{ return m_szMachine[0] != 0 ? m_szMachine : NULL; }

	PCTSTR GetStateString(DWORD dwState);
	PCTSTR GetStartupTypeString(DWORD dwStartupType);
	PCTSTR GetErrorControlString(DWORD dwErrorControl);
	PCTSTR GetProcessString(DWORD dwProcessType);
	PCTSTR GetInteractiveString(DWORD dwProcessType);
	PCTSTR GetFailureActionString(DWORD dwFailureAction);

	HIMAGELIST GetImageList()
		{ return m_imlIcons; }

	int GetServicesCount()
		{ return m_wndList.GetItemCount(); }

	CService * GetService(int nItem)
		{ return (CService *)m_wndList.GetItemData(nItem); }

  public:

	static CFrameWndClassInfo& GetWndClassInfo();

	void UpdateLayout(BOOL bResizeBars = TRUE);
	BOOL OnIdle();

	BOOL PreTranslateMessage(MSG * pMsg)
		{ return _Base::PreTranslateMessage(pMsg); }

	enum {
		COLUMN_DISPLAY_NAME = 0,
		COLUMN_DESCRIPTION,
		COLUMN_STATUS,
		COLUMN_STARTUP_TYPE,
		COLUMN_ERROR_CONTROL,
		COLUMN_PROCESS,
		COLUMN_LOGON_AS,
		COLUMN_INTERACTIVE,
		COLUMN_LOAD_ORDER,
		COLUMN_IMAGE_PATH,
		COLUMN_MAX,
		COLUMN_DEFAULT_SET = (1 << COLUMN_DISPLAY_NAME) |
							 (1 << COLUMN_DESCRIPTION) |
							 (1 << COLUMN_STATUS) |
							 (1 << COLUMN_STARTUP_TYPE) |
							 (1 << COLUMN_LOGON_AS)
	};

    BEGIN_MSG_MAP_EX(CMainWnd)
		MSG_WM_ACTIVATE(OnActivate)
		MSG_WM_CONTEXTMENU(OnContextMenu)
		MSG_WM_CREATE(OnCreate)
		MSG_WM_DESTROY(OnDestroy)
		MSG_WM_ERASEBKGND(OnEraseBkgnd)
		MSG_WM_GETMINMAXINFO(OnGetMinMaxInfo)
		MSG_WM_INITMENUPOPUP(OnInitMenuPopup)
		MSG_WM_SYSCOLORCHANGE(OnSysColorChange)
		NOTIFY_HANDLER_EX(ATL_IDW_CLIENT, NM_DBLCLK, OnList_DblClk)
		NOTIFY_HANDLER_EX(ATL_IDW_CLIENT, LVN_COLUMNCLICK, OnList_ColumnClick)
		NOTIFY_HANDLER_EX(ATL_IDW_CLIENT, LVN_DELETEITEM, OnList_DeleteItem)
		NOTIFY_HANDLER_EX(ATL_IDW_CLIENT, LVN_ITEMCHANGED, OnList_ItemChanged)
		NOTIFY_HANDLER_EX(0, NM_RCLICK, OnHeader_RClick)
		CMD_ID_SIMPLE(ID_ACTION_CONNECT, OnActionConnect)
		CMD_ID_SIMPLE(ID_ACTION_DISCONNECT, OnActionDisconnect)
		CMD_ID_SIMPLE(ID_ACTION_START, OnActionStart)
		CMD_ID_SIMPLE(ID_ACTION_START_EX, OnActionStartEx)
		CMD_ID_SIMPLE(ID_ACTION_STOP, OnActionStop)
		CMD_ID_SIMPLE(ID_ACTION_PAUSE, OnActionPause)
		CMD_ID_SIMPLE(ID_ACTION_RESUME, OnActionResume)
		CMD_ID_SIMPLE(ID_ACTION_INSTALL, OnActionInstall)
		CMD_ID_SIMPLE(ID_ACTION_DELETE, OnActionDelete)
		CMD_ID_SIMPLE(ID_ACTION_EXIT, OnActionExit)
		CMD_ID_SIMPLE(ID_VIEW_TOOLBAR, OnViewToolbar)
		CMD_ID_SIMPLE(ID_VIEW_STATUS_BAR, OnViewStatusBar)
		CMD_ID_SIMPLE(ID_VIEW_REFRESH, OnViewRefresh)
		CMD_ID_SIMPLE(ID_VIEW_PROPERTIES, OnViewProperties)
		COMMAND_RANGE_HANDLER_EX(ID_VIEW_COLUMN_0, ID_VIEW_COLUMN_9, OnViewColumnX)
		CMD_ID_SIMPLE(ID_HELP_ABOUT, OnHelpAbout)
		CHAIN_MSG_MAP(_UpdateUI)
		CHAIN_MSG_MAP(_Base)
    END_MSG_MAP()

	BEGIN_UPDATE_UI_MAP(CMainWnd)
		UPDATE_ELEMENT(ID_ACTION_DISCONNECT, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_START,		 UPDUI_MENUPOPUP|UPDUI_TOOLBAR)
		UPDATE_ELEMENT(ID_ACTION_START_EX,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_STOP,		 UPDUI_MENUPOPUP|UPDUI_TOOLBAR)
		UPDATE_ELEMENT(ID_ACTION_PAUSE,		 UPDUI_MENUPOPUP|UPDUI_TOOLBAR)
		UPDATE_ELEMENT(ID_ACTION_RESUME,	 UPDUI_MENUPOPUP|UPDUI_TOOLBAR)
		UPDATE_ELEMENT(ID_ACTION_DELETE,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_TOOLBAR,		 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_STATUS_BAR,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_REFRESH,		 UPDUI_MENUPOPUP|UPDUI_TOOLBAR)
		UPDATE_ELEMENT(ID_VIEW_PROPERTIES,	 UPDUI_MENUPOPUP|UPDUI_TOOLBAR)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_0,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_1,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_2,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_3,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_4,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_5,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_6,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_7,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_8,	 UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_VIEW_COLUMN_9,	 UPDUI_MENUPOPUP)
	END_UPDATE_UI_MAP()

  protected:

	// message handlers
    void OnActivate(UINT, BOOL, HWND);
    void OnContextMenu(HWND, CPoint);
    int OnCreate(LPCREATESTRUCT);
    void OnDestroy(void);
    void OnGetMinMaxInfo(LPMINMAXINFO);
	void OnSysColorChange();

	BOOL OnEraseBkgnd(HDC)
		{ return (BOOL)DefWindowProc(); }
	void OnInitMenuPopup(HMENU hMenu, UINT, BOOL)
		{ SetMenuDefaultItem(hMenu, (UINT)-1, FALSE); SetMsgHandled(FALSE); }

	// notification handlers
	LRESULT OnList_ColumnClick(LPNMHDR);
	LRESULT OnList_DeleteItem(LPNMHDR);
	LRESULT OnList_ItemChanged(LPNMHDR);
	LRESULT OnHeader_RClick(LPNMHDR);

	LRESULT OnList_DblClk(LPNMHDR)
		{ OnViewProperties(); return 0; }

	// command handlers
	void OnActionConnect();
	void OnActionDisconnect();
	void OnActionStart();
	void OnActionStartEx();
	void OnActionStop();
	void OnActionPause();
	void OnActionResume();
	void OnActionInstall();
	void OnActionDelete();
	void OnViewToolbar();
	void OnViewStatusBar();
	void OnViewRefresh();
	void OnViewProperties();
	void OnViewColumnX(UINT, int, HWND);
	void OnHelpAbout();

	void OnActionExit()
		{ PostMessage(WM_CLOSE); }

	// WTL 3.1 bugfix
	BOOL UISetState(int nID, DWORD dwState)
	{
		const _AtlUpdateUIMap* pMap = m_pUIMap;
		_AtlUpdateUIData* pUIData = m_pUIData;
		if(pUIData == NULL)
			return FALSE;
		for( ; pMap->m_nID != (WORD)-1; pMap++, pUIData++)
		{
			if(nID == (int)pMap->m_nID)
			{		
				pUIData->m_wState = (WORD)(dwState | pMap->m_wType);
				m_wDirtyType |= pMap->m_wType;
				break;	// found
			}
		}
		return TRUE;
	}

  protected:

	TCHAR			m_szMachine[UNCLEN + 1];// remote machine name
	CListViewCtrl	m_wndList;				// main list view
	CImageList		m_imlIcons;				// image list
	CBitmap			m_bmSortUp;				// sort up bitmap
	CBitmap			m_bmSortDown;			// sort down bitmap
	LONG			m_nSortOrder;			// list sort order
	TCHAR			m_szState[7][40];		// state names cache
	TCHAR			m_szStartupType[3][40];	// startup type names cache
	TCHAR			m_szErrorControl[4][40];// error control names cache
	TCHAR			m_szProcess[2][40];		// process type names cache
	TCHAR			m_szInteractive[2][40];	// interactive names cache
	TCHAR			m_szFailureAction[4][40];// failure action names cache
	DWORD			m_dwColumnSet;			// column set
	int				m_nColWidth[COLUMN_MAX];// column width array
	int				m_nColOrder[COLUMN_MAX];// column order array

  protected:

	void InsertColumn(int iColumn, int nPos);
	void DeleteColumn(int nPos);
	int GetLogicalColumn(int nPos);
	int GetPhysicalColumn(int nColumn);

	void LoadConfig();
	void SaveConfig();
	void SetSortMark(int nOrder);

	BOOL DoConnect(PCTSTR pszMachine, PCTSTR pszUserName, PCTSTR pszPassword);
	BOOL DoStartService(CService * pService, int nArgc, PCWSTR * pArgv);
	BOOL DoStopService(CService * pService);

	int FindServiceItem(PCTSTR pszName, CService ** ppService);
	HRESULT AddServiceItem(LPENUM_SERVICE_STATUS pStatus);
	void UpdateServiceItem(int nItem, CService * pService);
	
	static int CALLBACK SortCallback(LPARAM, LPARAM, LPARAM);
};

#endif // __mainwnd_h_included
