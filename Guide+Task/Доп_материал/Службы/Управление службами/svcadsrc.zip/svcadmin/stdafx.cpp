// stdafx.cpp
//
// $Id: $
//

#include "stdafx.h"

#if _ATL_VER < 0x0700
#include <atlimpl.cpp>
#endif

#ifdef _ATL_MIN_CRT

EXTERN_C
char *
__cdecl
_strdup(
	const char * psz
	)
{
	if (psz == NULL)
		return NULL;

	size_t cch = lstrlenA(psz) + 1;

	char * qsz = (char *)malloc(cch * sizeof(char));
	if (qsz != NULL)
		lstrcpyA(qsz, psz);

	return qsz;
}

EXTERN_C
wchar_t *
__cdecl
_wcsdup(
	const wchar_t * psz
	)
{
	if (psz == NULL)
		return NULL;

	size_t cch = lstrlenW(psz) + 1;

	wchar_t * qsz = (wchar_t *)malloc(cch * sizeof(wchar_t));
	if (qsz != NULL)
		lstrcpyW(qsz, psz);

	return qsz;
}

EXTERN_C 
void 
__fastcall 
_itot10(
	int i, 
	_TCHAR * str
	)
{
	if (i == 0)
	{
		str[0] = _T('0');
		str[1] = 0;
		return;
	}

	if (i < 0)
	{
		*str++ = _T('-');
		i = -i;
	}

	_TCHAR * p = str;
	while (i != 0)
	{
		*p++ = (_TCHAR)(_T('0') + (i % 10));
		i /= 10;
	}

	*p-- = 0;

	while (*str != 0)
	{
		_TCHAR x = *p;
		*p = *str;
		*str = x;

		p--;
		str++;
	}
}

#endif
