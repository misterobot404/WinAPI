// voidsvc.cpp
//

#include "stdafx.h"
#include "messages.h"

HANDLE					_hEvent;
PCTSTR					_pszServiceName;
SERVICE_STATUS			_Status;
SERVICE_STATUS_HANDLE	_hStatus;
HANDLE					_hEventSource;
const TCHAR				_szKey[] = _T("System\\CurrentControlSet\\Services")
								   _T("\\Eventlog\\Application\\");

//---------------------------------------------------------------------------
// LogEvent
//
//  Logs an event into the system log.
//
//  Parameters:
//    hRes     - event code
//    pData    - pointer to a data block to associate with the message
//    cbData   - size of the data block
//    cStrings - number of event strings
//    ...      - event strings
//
//  Returns:
//    no return value.
//
VOID
CDECL
LogEvent(
    HRESULT hRes,
    CONST VOID * pData,
    UINT cbData, 
    UINT cStrings,
    ...
    )
{
    PTSTR rgStrings[16];

    _ASSERTE(cStrings < countof(rgStrings));

    // put arguments into the array
    va_list va;
    va_start(va, cStrings);

    for (UINT i = 0; i < cStrings; i++)
        rgStrings[i] = va_arg(va, LPTSTR);
    va_end(va);

    // register event source in the first call to LogEvent
    if (_hEventSource == NULL)
    {
        _hEventSource = RegisterEventSource(NULL, _pszServiceName);
        if (_hEventSource == NULL)
        {
            _RPT_API_FAILED(RegisterEventSource);
            return;
        }
    }
    _ASSERTE(_hEventSource != NULL);

    // select event type based on the severity of hRes
    WORD wType;
    switch (hRes & 0xC0000000)
    {
        case ERROR_SEVERITY_SUCCESS:
            wType = EVENTLOG_SUCCESS;
            break;
        case ERROR_SEVERITY_INFORMATIONAL:
            wType = EVENTLOG_INFORMATION_TYPE;
            break;
        case ERROR_SEVERITY_WARNING:
           wType = EVENTLOG_WARNING_TYPE;
            break;
        case ERROR_SEVERITY_ERROR:
            wType = EVENTLOG_ERROR_TYPE;
            break;
        default:
            _ASSERTE(0);
            __assume(0);
    }

    ReportEvent(_hEventSource, wType, 0, hRes, NULL, (WORD)cStrings,
                cbData, (PCTSTR *)rgStrings, (PVOID)pData);

    // DeregisterEventSource is called when the service is exiting
}


//--------------------------------------------------------------------------
// CtrlHandler
//
//  Processes control requests to the service.
//
//  Parameters:
//	  dwControl - control code
//
//  Returns:
//    no return value.
//  
VOID
WINAPI
CtrlHandler(
	DWORD dwControl
	)
{
	switch (dwControl)
	{
		case SERVICE_CONTROL_STOP:
			_VERIFY(SetEvent(_hEvent));
			break;
		case SERVICE_CONTROL_PAUSE:
			_Status.dwCurrentState = SERVICE_PAUSED;
			_VERIFY(SetServiceStatus(_hStatus, &_Status));
			LogEvent(VOIDSVC_S_PAUSE, NULL, 0, 1, _pszServiceName);
			break;
		case  SERVICE_CONTROL_CONTINUE:
			_Status.dwCurrentState = SERVICE_RUNNING;
			_VERIFY(SetServiceStatus(_hStatus, &_Status));
			LogEvent(VOIDSVC_S_CONTINUE, NULL, 0, 1, _pszServiceName);
			break;
		case SERVICE_CONTROL_PARAMCHANGE:
			_Status.dwCurrentState = SERVICE_RUNNING;
			_VERIFY(SetServiceStatus(_hStatus, &_Status));
			LogEvent(VOIDSVC_S_PARAMCHANGE, NULL, 0, 1, _pszServiceName);
			break;
		case SERVICE_CONTROL_NETBINDADD:
			_Status.dwCurrentState = SERVICE_RUNNING;
			_VERIFY(SetServiceStatus(_hStatus, &_Status));
			LogEvent(VOIDSVC_S_NETBINDADD, NULL, 0, 1, _pszServiceName);
			break;
		case SERVICE_CONTROL_NETBINDREMOVE:
			_Status.dwCurrentState = SERVICE_RUNNING;
			_VERIFY(SetServiceStatus(_hStatus, &_Status));
			LogEvent(VOIDSVC_S_NETBINDREMOVE, NULL, 0, 1, _pszServiceName);
			break;
		case SERVICE_CONTROL_NETBINDDISABLE:
			_Status.dwCurrentState = SERVICE_RUNNING;
			_VERIFY(SetServiceStatus(_hStatus, &_Status));
			LogEvent(VOIDSVC_S_NETBINDDISABLE, NULL, 0, 1, _pszServiceName);
			break;
		case SERVICE_CONTROL_NETBINDENABLE:
			_Status.dwCurrentState = SERVICE_RUNNING;
			_VERIFY(SetServiceStatus(_hStatus, &_Status));
			LogEvent(VOIDSVC_S_NETBINDENABLE, NULL, 0, 1, _pszServiceName);
			break;
		default:
			break;
	}
}

//--------------------------------------------------------------------------
// ServiceMain
//
//  This is the main service procedure.
//
//  Parameters:
//	  dwArgc   - number of arguments
//    ppszArgv - vector of arguments
//
//  Returns:
//	  no return value.
//
VOID
WINAPI
ServiceMain(
	DWORD dwArgc,
	LPTSTR * ppszArgv
	)
{
	_UNUSED(dwArgc);
	_UNUSED(ppszArgv);

	_Status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	_Status.dwControlsAccepted = SERVICE_ACCEPT_STOP|
								 SERVICE_ACCEPT_PAUSE_CONTINUE|
								 SERVICE_ACCEPT_PARAMCHANGE|
								 SERVICE_ACCEPT_NETBINDCHANGE;
	_Status.dwWin32ExitCode = 0;
  	_Status.dwServiceSpecificExitCode = 0;
	_Status.dwCheckPoint = 0;
	_Status.dwWaitHint = 0;

	_hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (_hEvent == NULL)
	{
		_RPT_API_FAILED(CreateEvent);
		return;
	}

	_hStatus = RegisterServiceCtrlHandler(_pszServiceName, CtrlHandler);
	if (_hStatus == NULL)
	{
		_RPT_API_FAILED(RegisterServiceCtrlHandler);
		_VERIFY(CloseHandle(_hEvent));
		return;
	}

	LogEvent(VOIDSVC_S_START, NULL, 0, 1, _pszServiceName);

	_Status.dwCurrentState = SERVICE_RUNNING;
	_VERIFY(SetServiceStatus(_hStatus, &_Status));

	WaitForSingleObject(_hEvent, INFINITE);
	_VERIFY(CloseHandle(_hEvent));

	_Status.dwCurrentState = SERVICE_STOPPED;
	_VERIFY(SetServiceStatus(_hStatus, &_Status));

	LogEvent(VOIDSVC_S_STOP, NULL, 0, 1, _pszServiceName);
}

//--------------------------------------------------------------------------
// Install
//
//  Performs installation of the service.
//
//  Parameters:
//	  pszName - service name
//
//  Returns:
//	  TRUE, if successful, and FALSE - otherwise.
//
BOOL
WINAPI
Install(
	IN PCTSTR pszName
	)
{
	SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CREATE_SERVICE);
	if (hSCM == NULL)
	{
		_RPT_API_FAILED(OpenSCManager);
		return FALSE;
	}

	TCHAR szPathName[MAX_PATH];
	GetModuleFileName(NULL, szPathName + 1, countof(szPathName) - 2);

	szPathName[0] = _T('\"');
	lstrcat(szPathName, _T("\" "));
	lstrcat(szPathName, pszName);

	SC_HANDLE hService = CreateService(hSCM, pszName, 
			pszName, 0, SERVICE_WIN32_OWN_PROCESS, 
			SERVICE_DEMAND_START, SERVICE_ERROR_IGNORE, 
			szPathName, NULL, NULL, NULL, NULL, NULL);

	if (hService == NULL)
		_RPT_API_FAILED(CreateService);
	else
		_VERIFY(CloseServiceHandle(hService));

	_VERIFY(CloseServiceHandle(hSCM));

	if (hService == NULL)
		return FALSE;

	HKEY hKey;
	LONG lRes;
	TCHAR szKey[MAX_PATH];

	lstrcpy(szKey, _szKey);
	lstrcat(szKey, pszName);

	lRes = RegCreateKeyEx(HKEY_LOCAL_MACHINE, szKey, 0, NULL, 0,
						  KEY_READ|KEY_WRITE, NULL, &hKey, NULL);
	if (lRes == ERROR_SUCCESS)
	{
		GetModuleFileName(NULL, szPathName, countof(szPathName));
		RegSetValueEx(hKey, _T("EventMessageFile"), 0, REG_SZ,
					 (PBYTE)szPathName, lstrlen(szPathName) * sizeof(TCHAR));

		DWORD dwValue = 7;
		RegSetValueEx(hKey, _T("TypesSupported"), 0, REG_DWORD,
					  (PBYTE)&dwValue, sizeof(DWORD));

		RegCloseKey(hKey);
	}

	return lRes == ERROR_SUCCESS;
}

//--------------------------------------------------------------------------
// Uninstall
//
//  Performs uninstallation of the service.
//
//  Parameters:
//	  pszName - service name
//
//  Returns:
//	  TRUE, if successful, and FALSE - otherwise.
//
BOOL
WINAPI
Uninstall(
	IN PCTSTR pszName
	)
{
	SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
	if (hSCM == NULL)
	{
		_RPT_API_FAILED(OpenSCManager);
		return FALSE;
	}

	SC_HANDLE hService = OpenService(hSCM, pszName, SERVICE_STOP|DELETE);
	if (hService == NULL)
	{
		_RPT_API_FAILED(OpenService);
		_VERIFY(CloseServiceHandle(hSCM));
		return FALSE;
	}

	SERVICE_STATUS Status;
	ControlService(hService, SERVICE_CONTROL_STOP, &Status);

	Sleep(200);

	BOOL bOk = DeleteService(hService);
	if (!bOk)
		_RPT_API_FAILED(DeleteService);

	_VERIFY(CloseServiceHandle(hService));
	_VERIFY(CloseServiceHandle(hSCM));

	TCHAR szKey[MAX_PATH];
	lstrcpy(szKey, _szKey);
	lstrcat(szKey, pszName);

	RegDeleteKey(HKEY_LOCAL_MACHINE, szKey);

	return bOk;
}

//--------------------------------------------------------------------------
// _tWinMain
//
//  This is the application entry point.
//
//  Parameters:
//  Parameters:
//    hInstance     - instance handle
//    hPrevInstance - previous instance handle
//    pszCmdLine    - command line
//    nShowCmd	    - show command
//
//  Returns:
//    the return value is the exit code of the process.
//
int
APIENTRY
_tWinMain(
	HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    PTSTR pszCmdLine,
    int nCmdShow
	)
{
	_UNUSED(hInstance);
	_UNUSED(hPrevInstance);
	_UNUSED(nCmdShow);

	pszCmdLine = GetCommandLine();

	// skip process name in the beginning of the command line
	TCHAR chSep = _T(' ');
	if (*pszCmdLine == _T('\"'))
	{
		chSep = _T('\"');
		pszCmdLine++;
	}

	while (*pszCmdLine != 0 && *pszCmdLine != chSep)
		pszCmdLine++;
	pszCmdLine++;

	// skip whitespace
	while (*pszCmdLine == _T(' '))
		pszCmdLine++;

	// find the end of the first argument
	PTSTR psz = pszCmdLine;
	while (*psz != _T(' ') && *psz != 0)
		psz++;
	*psz = 0;

	if (*pszCmdLine == 0)
		return -1;

	int len = lstrlen(pszCmdLine);

	if (CompareString(LOCALE_SYSTEM_DEFAULT, NORM_IGNORECASE, pszCmdLine,
					  min(len, 9), _T("/install:"), 9) == CSTR_EQUAL)
		return Install(pszCmdLine + 9);

	if (CompareString(LOCALE_SYSTEM_DEFAULT, NORM_IGNORECASE, pszCmdLine,
					  min(len, 11), _T("/uninstall:"), 11) == CSTR_EQUAL)
		return Uninstall(pszCmdLine + 11);

	SERVICE_TABLE_ENTRY ServiceTable[2];

	ServiceTable[0].lpServiceName = pszCmdLine;
	ServiceTable[0].lpServiceProc = ServiceMain;
	ServiceTable[1].lpServiceName = NULL;
	ServiceTable[1].lpServiceProc = NULL;

	_pszServiceName = pszCmdLine;
	StartServiceCtrlDispatcher(ServiceTable);

	if (_hEventSource != NULL)
		DeregisterEventSource(_hEventSource);

	return 0;
}

#ifndef _DEBUG
//--------------------------------------------------------------------------
// wWinMainCRTStartup
//
//  This is the real process entry point.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  this function does not return to the caller.
//
EXTERN_C
void
__cdecl
wWinMainCRTStartup()
{
	ExitProcess(_tWinMain(NULL, NULL, NULL, 0));
}
#endif
