// svcconf.cpp
//
// Displays configuration of a service.
//
// $Id: $
//

#include "stdafx.h"

//---------------------------------------------------------------------------
// PrintUsage
//
//  Prints program usage information.
//
//  Parameters:
//	  none.
//
//  Returns:
//	  one.
//
int
PrintUsage()
{
	_tprintf(_T("Usage:\n"));
	_tprintf(_T("\n"));
	_tprintf(_T("svcconf <service name>\n"));
	return 1;
}

//---------------------------------------------------------------------------
// PrintError
//
//  Prints an error code and the corresponding description.
//
//  Parameters:
//	  pszMessage - additional message text
//	  dwError    - error code.
//
//  Returns:
//	  one.
//
int
PrintError(
	IN PCTSTR pszMessage,
	IN DWORD dwErrorCode
	)
{
	_tprintf(_T("%s\n"), pszMessage);

	TCHAR szErrorText[512];

	if (FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwErrorCode, 0,
					  szErrorText, countof(szErrorText), NULL))
		_tprintf(_T("Error %d: %s\n"), dwErrorCode, szErrorText);
	else
		_tprintf(_T("Error %d"), dwErrorCode);

	return 1;
}

//---------------------------------------------------------------------------
// _tmain
//
//  Program entry point.
//
//  Parameters:
//    argc - number of arguments
//	  argv - vector of arguments
//
//  Returns:
//	  program's exit code.
//
int
_tmain(
	int argc,
	_TCHAR * argv[]
	)
{
	if (argc < 2)
		return PrintUsage();

	SC_HANDLE hSCM = NULL;
	SC_HANDLE hService = NULL;

	LPQUERY_SERVICE_CONFIG pConfig = NULL;

#if _WIN32_WINNT >= 0x500
	LPSERVICE_DESCRIPTION pDesc = NULL;
	LPSERVICE_FAILURE_ACTIONS pActions = NULL;
#endif

	DWORD cbNeeded;
	BOOL bOk = FALSE;

	for (;;)
	{
		// open handle to the service manager
		hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
		if (hSCM == NULL)
		{
			PrintError(_T("OpenSCManager failed"), GetLastError());
			break;
		}

		// open service handle with SERVICE_QUERY_CONFIG access right
		hService = OpenService(hSCM, argv[1], SERVICE_QUERY_CONFIG);
		if (hService == NULL)
		{
			PrintError(_T("OpenService failed"), GetLastError());
			break;
		}

		// determine how much space we need in order to receive the service
		// configuration
		if (!QueryServiceConfig(hService, NULL, 0, &cbNeeded))
		{
			if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
			{
				PrintError(_T("QueryServiceConfig failed"), GetLastError());
				break;
			}
		}

		// allocate memory for the configuration buffer
		pConfig = (LPQUERY_SERVICE_CONFIG)_alloca(cbNeeded);
		_ASSERTE(pConfig != NULL);

		// retrieve the service configuration
		if (!QueryServiceConfig(hService, pConfig, cbNeeded, &cbNeeded))
		{
			PrintError(_T("QueryServiceConfig failed"), GetLastError());
			break;
		}

#if _WIN32_WINNT >= 0x500
		// determine how much space we need in order to receive the service
		// description
		if (!QueryServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION,
								 NULL, 0, &cbNeeded))
		{
			if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
			{
				PrintError(_T("QueryServiceConfig2 failed"), GetLastError());
				break;
			}
		}

		// allocate memory for the description buffer
		pDesc = (LPSERVICE_DESCRIPTION)_alloca(cbNeeded);
		_ASSERTE(pDesc != NULL);

		// retrieve the service description
		if (!QueryServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION,
								 (PBYTE)pDesc, cbNeeded, &cbNeeded))
		{
			PrintError(_T("QueryServiceConfig2 failed"), GetLastError());
			break;
		}

		// determine how much space we need in order to receive the service
		// failure actions
		if (!QueryServiceConfig2(hService, SERVICE_CONFIG_FAILURE_ACTIONS,
								 NULL, 0, &cbNeeded))
		{
			if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
			{
				PrintError(_T("QueryServiceConfig2 failed"), GetLastError());
				break;
			}
		}

		// allocate memory for the failure actions buffer
		pActions = (LPSERVICE_FAILURE_ACTIONS)_alloca(cbNeeded);
		_ASSERTE(pActions != NULL);

		// retrieve the service failure actions
		if (!QueryServiceConfig2(hService, SERVICE_CONFIG_FAILURE_ACTIONS,
								 (PBYTE)pActions, cbNeeded, &cbNeeded))
		{
			PrintError(_T("QueryServiceConfig2 failed"), GetLastError());
			break;
		}
#endif

		bOk = TRUE;
		break;
	}

	if (hService != NULL)
		_VERIFY(CloseServiceHandle(hService));
	if (hSCM != NULL)
		_VERIFY(CloseServiceHandle(hSCM));

	if (!bOk)
		return 1;

	// prepare some strings
	PCTSTR pszServiceType = NULL;
	PCTSTR pszInteractive = NULL;
	PCTSTR pszStartType = NULL;
	PCTSTR pszErrorControl = NULL;

	switch (pConfig->dwServiceType & ~SERVICE_INTERACTIVE_PROCESS)
	{
		case SERVICE_KERNEL_DRIVER:
			pszServiceType = _T("Kernel Driver");
			break;
		case SERVICE_FILE_SYSTEM_DRIVER:
			pszServiceType = _T("File System Driver");
			break;
		case SERVICE_WIN32_OWN_PROCESS:
			pszServiceType = _T("Win32 Own Process");
			break;
		case SERVICE_WIN32_SHARE_PROCESS:
			pszServiceType = _T("Win32 Share Process");
			break;
		default:
			pszServiceType = _T("Unknown");
			break;
	}

	if (pConfig->dwServiceType & SERVICE_INTERACTIVE_PROCESS)
		pszInteractive = _T("(Interactive)");
	else
		pszInteractive = _T("");

	switch (pConfig->dwStartType)
	{
		case SERVICE_BOOT_START:
			pszStartType = _T("Boot");
			break;
		case SERVICE_SYSTEM_START:
			pszStartType = _T("System");
			break;
		case SERVICE_AUTO_START:
			pszStartType = _T("Auto");
			break;
		case SERVICE_DEMAND_START:
			pszStartType = _T("On Demand");
			break;
		case SERVICE_DISABLED:
			pszStartType = _T("Disabled");
			break;
		default:
			pszStartType = _T("Unknown");
			break;
	}

	switch (pConfig->dwErrorControl)
	{
		case SERVICE_ERROR_IGNORE:
			pszErrorControl = _T("Ignore");
			break;
		case SERVICE_ERROR_NORMAL:
			pszErrorControl = _T("Normal");
			break;
		case SERVICE_ERROR_SEVERE:
			pszErrorControl = _T("Severe");
			break;
		case SERVICE_ERROR_CRITICAL:
			pszErrorControl = _T("Critical");
			break;
		default:
			pszErrorControl = _T("Unknown");
			break;
	}

	// print basic service configuration information
	_tprintf(_T("Name:             %s\n"), argv[1]);
	_tprintf(_T("Display Name:     %s\n"), pConfig->lpDisplayName);
	_tprintf(_T("Service Type:     %s %s\n"), pszServiceType, pszInteractive);
	_tprintf(_T("Start Type:       %s\n"), pszStartType);
	_tprintf(_T("Error Control:    %s\n"), pszErrorControl);
	_tprintf(_T("Binary File:      %s\n"), pConfig->lpBinaryPathName);
	_tprintf(_T("Logon Account:    %s\n"), pConfig->lpServiceStartName);
	_tprintf(_T("Load Order Group: %s\n"), pConfig->lpLoadOrderGroup);
	
	// list service dependencies
	_tprintf(_T("Dependencies:\n"));

	PCTSTR psz = pConfig->lpDependencies;
	while (*psz != 0)
	{
		if (*psz == SC_GROUP_IDENTIFIER)
			_tprintf(_T("\tGroup:   %s\n"), psz + 1);
		else
			_tprintf(_T("\tService: %s\n"), psz);

		psz += lstrlen(psz) + 1;
	}

#if _WIN32_WINNT >= 0x500

	// display service description:
	_tprintf(_T("\nDescription:\n%s\n\n"), pDesc->lpDescription);

	// display service failure actions
	_tprintf(_T("Failure Actions:\n"));
	_tprintf(_T("\tReset Period:   %d sec\n"), pActions->dwResetPeriod);
	_tprintf(_T("\tCommand Line:   %s\n"), pActions->lpCommand);
	_tprintf(_T("\tReboot Message: %s\n"), pActions->lpRebootMsg);

	SC_ACTION * p = pActions->lpsaActions;
	for (ULONG i = 0; i < pActions->cActions; i++)
	{
		PCTSTR pszAction;
		switch (p->Type)
		{
			case SC_ACTION_NONE:		pszAction = _T("None");
										break;
			case SC_ACTION_REBOOT:		pszAction = _T("Reboot");
										break;
			case SC_ACTION_RESTART:		pszAction = _T("Restart");
										break;
			case SC_ACTION_RUN_COMMAND: pszAction = _T("Run Command");
										break;
			default:					pszAction = _T("Unknown");
										break;
		}

		_tprintf(_T("\t%d Delay: %6 msec  Action: %s\n"), i + 1,
				 p->Delay, pszAction);
	}

#endif

	return 0;
}

#if !defined(_DEBUG) && defined(_UNICODE)

//---------------------------------------------------------------------------
// wprintf
//
//  printf implementation for Release build to avoid inclusion of CRT stuff.
//
//  Parameters:
//	  fmt - format string
//	  ... - optional parameters
//
//  Returns:
//    number of characters printed.
//
int
__cdecl
wprintf(
	const WCHAR * fmt,
	...
	)
{
	va_list va;
	va_start(va, fmt);

	WCHAR szBufferW[1024];
	CHAR szBufferA[1024];

	int ret = wvsprintfW(szBufferW, fmt, va);

	va_end(va);

	ret = WideCharToMultiByte(CP_ACP, 0, szBufferW, ret, szBufferA,
							  countof(szBufferA), NULL, NULL);

	if (!WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), szBufferA, ret,
				   (DWORD *)&ret, NULL))
		return -1;

	return ret;
}

//---------------------------------------------------------------------------
// wmainCRTStartup
//
//  The real process entry point.
//
//  Parameters:
//    none.
//
//  Returns:
//	  this function does not return to the caller.
//
extern "C"
void 
__cdecl 
wmainCRTStartup()
{
	int argc;
	PWSTR * argv = CommandLineToArgvW(GetCommandLineW(), &argc);

	ExitProcess(wmain(argc, argv));
}

#endif
