// stdafx.h
//
// $Id: $
//

#define STRICT
#define _WIN32_WINNT	0x500
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <tchar.h>

#include <limits.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

#include "alexfstd.h"
