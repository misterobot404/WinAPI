// svclist.cpp
//
// Lists all installed services.
//
// $Id: $
//

#include "stdafx.h"

//---------------------------------------------------------------------------
// PrintError
//
//  Prints an error code and the corresponding description.
//
//  Parameters:
//	  pszMessage - additional message text
//	  dwError    - error code.
//
//  Returns:
//	  one.
//
int
PrintError(
	IN PCTSTR pszMessage,
	IN DWORD dwErrorCode
	)
{
	_tprintf(_T("%s\n"), pszMessage);

	TCHAR szErrorText[512];

	if (FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwErrorCode, 0,
					  szErrorText, countof(szErrorText), NULL))
		_tprintf(_T("Error %d: %s\n"), dwErrorCode, szErrorText);
	else
		_tprintf(_T("Error %d"), dwErrorCode);

	return 1;
}

//---------------------------------------------------------------------------
// _tmain
//
//  Program entry point.
//
//  Parameters:
//    argc - number of arguments
//	  argv - vector of arguments
//
//  Returns:
//	  program's exit code.
//
int
_tmain(
	int argc,
	_TCHAR * argv[]
	)
{
	_UNUSED(argc);
	_UNUSED(argv);

	SC_HANDLE hSCM;
	int nRet = 0;

	// open handle to the service manager
	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ENUMERATE_SERVICE);
	if (hSCM == NULL)
		return PrintError(_T("OpenSCManager failed"), GetLastError());

	BYTE bBuffer[2048];
	DWORD dwResumeHandle = 0;
	DWORD cbNeeded;
	DWORD cServices;
	BOOL bContinue;
	DWORD dwError;
	LPENUM_SERVICE_STATUS pStatus;

	do
	{
		bContinue = FALSE;
		pStatus = (LPENUM_SERVICE_STATUS)bBuffer;

		// retrieve a portion of service status information
		if (!EnumServicesStatus(hSCM, SERVICE_WIN32, SERVICE_STATE_ALL,
								pStatus, sizeof(bBuffer), &cbNeeded,
								&cServices, &dwResumeHandle))
		{
			dwError = GetLastError();

			if (dwError != ERROR_MORE_DATA)
			{
				nRet = PrintError(_T("EnumServicesStatus failed"), 
								  dwError);
				break;
			}

			bContinue = TRUE;
		}

		// display all retrieved services
		for (DWORD i = 0; i < cServices; i++)
		{
			PCTSTR pszStatus;
			switch (pStatus->ServiceStatus.dwCurrentState)
			{
				case SERVICE_STOPPED:
					pszStatus = _T("Stopped");
					break;
				case SERVICE_RUNNING:
					pszStatus = _T("Running");
					break;
				case SERVICE_PAUSED:
					pszStatus = _T("Paused");
					break;
				case SERVICE_STOP_PENDING:
					pszStatus = _T("Stop Pending");
					break;
				case SERVICE_START_PENDING:
					pszStatus = _T("Start Pending");
					break;
				case SERVICE_PAUSE_PENDING:
					pszStatus = _T("Pause Pending");
					break;
				case SERVICE_CONTINUE_PENDING:
					pszStatus = _T("Continue Pending");
					break;
				default:
					pszStatus = _T("Unknown");
					break;
			}

			if (lstrlen(pStatus->lpDisplayName) > 60)
				pStatus->lpDisplayName[60] = 0;

			_tprintf(_T("%-60s %s\n"), pStatus->lpDisplayName,
					 pszStatus);

			// proceed to the next service
			pStatus++;
		}
	}
	while (bContinue);

	_VERIFY(CloseServiceHandle(hSCM));
	return nRet;
}

#if !defined(_DEBUG) && defined(_UNICODE)

//---------------------------------------------------------------------------
// wprintf
//
//  printf implementation for Release build to avoid inclusion of CRT stuff.
//
//  Parameters:
//	  fmt - format string
//	  ... - optional parameters
//
//  Returns:
//    number of characters printed.
//
int
__cdecl
wprintf(
	const WCHAR * fmt,
	...
	)
{
	va_list va;
	va_start(va, fmt);

	WCHAR szBufferW[1024];
	CHAR szBufferA[1024];

	int ret = wvsprintfW(szBufferW, fmt, va);

	va_end(va);

	ret = WideCharToMultiByte(CP_ACP, 0, szBufferW, ret, szBufferA,
							  countof(szBufferA), NULL, NULL);

	if (!WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), szBufferA, ret,
				   (DWORD *)&ret, NULL))
		return -1;

	return ret;
}

//---------------------------------------------------------------------------
// wmainCRTStartup
//
//  The real process entry point.
//
//  Parameters:
//    none.
//
//  Returns:
//	  this function does not return to the caller.
//
extern "C"
void 
__cdecl 
wmainCRTStartup()
{
	int argc;
	PWSTR * argv = CommandLineToArgvW(GetCommandLineW(), &argc);

	ExitProcess(wmain(argc, argv));
}

#endif
