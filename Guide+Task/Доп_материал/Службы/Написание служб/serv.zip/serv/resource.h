//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//

#define IDS_CMDLINE_EOPENSCM_AD         1
#define IDS_CMDLINE_EOPENSCM            2
#define IDS_CMDLINE_ECREATE_DUPNAME     3
#define IDS_CMDLINE_ECREATE_EXISTS      4
#define IDS_CMDLINE_ECREATE             5
#define IDS_CMDLINE_EOPENSERV           6
#define IDS_CMDLINE_ELOAD_DESC          7
#define IDS_CMDLINE_EOPEN_SERVKEY       8
#define IDS_CMDLINE_EWRITE_DESC         9
#define IDS_CMDLINE_ECREATE_LOGKEY      10
#define IDS_CMDLINE_EWRITE_LOG          11
#define IDS_CMDLINE_EOPEN_LOGKEY        12
#define IDS_CMDLINE_EDELETE_LOG         13
#define IDS_CMDLINE_MCREATE             51
#define IDS_CMDLINE_MDELETE             52
#define IDS_CMDLINE_MHELP               53
#define IDS_DESCRIPTION                 101

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
