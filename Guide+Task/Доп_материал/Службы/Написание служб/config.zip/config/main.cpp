#include "stddef.h"
#include "resource.h"

// �������� �������� �� ���������
#define DEFAULT_WAIT       10000

// ������� ���������
#define MIN_WAIT           1000
#define MAX_WAIT           100000

void ReadWaitTime(DWORD* Wait);
bool WriteWaitTime(DWORD Wait);
void Signal();

BOOL CALLBACK DlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

// �������� �������
int WINAPI _tWinMain(HINSTANCE hInst, HINSTANCE, TCHAR* , int)
{
	DialogBox(hInst, TEXT("IDD_DIALOG"), NULL, DlgProc);
	return 0;
}

// ������� �������
BOOL CALLBACK DlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		{
			DWORD Wait;
			ReadWaitTime(&Wait);

			if (Wait > MAX_WAIT)
			{
				Wait = MAX_WAIT;
			}
			else if (Wait < MIN_WAIT)
			{
				Wait = MIN_WAIT;
			}

			SetDlgItemInt(hDlg, IDC_WAITTIME, Wait, FALSE);
		}	
		return TRUE;
	case WM_COMMAND:
		if (LOWORD(wParam)==IDOK)
		{
			DWORD Wait;
			BOOL  Translate;
			Wait = GetDlgItemInt(hDlg, IDC_WAITTIME, &Translate, FALSE);

			if (!Translate)
			{
				MessageBox(
					hDlg, 
					TEXT("Can not translate string in edit box to number."),
					TEXT("Error"),
					MB_OK);
				return TRUE;
			}

			if (Wait > MAX_WAIT)
			{
				MessageBox(
					hDlg, 
					TEXT("Value is too big."),
					TEXT("Error"),
					MB_OK);
				return TRUE;
			}

			if (Wait < MIN_WAIT)
			{
				MessageBox(
					hDlg, 
					TEXT("Value is too small."),
					TEXT("Error"),
					MB_OK);
				return TRUE;
			}

			if (!WriteWaitTime(Wait))
			{
				MessageBox(
					hDlg, 
					TEXT("Can not write WaitTime in regestry."),
					TEXT("Error"),
					MB_OK);
				return TRUE;
			}

			Signal();
		}
		else if (LOWORD(wParam)!=IDCANCEL)
		{
			return FALSE;
		}

		EndDialog(hDlg, 0);
		return TRUE;
	}
	return FALSE;
}

// ������ �������� �� �������
void ReadWaitTime(DWORD* pWait)
{
	*pWait = DEFAULT_WAIT;

	TCHAR KeyName[256];

	wsprintf(
		KeyName, 
		TEXT("System\\CurrentControlSet\\Services\\%s\\Parameters"), 
		ServiceName);

	HKEY  hKey;
	DWORD res;

	res = RegOpenKeyEx(
			HKEY_LOCAL_MACHINE,
			KeyName,
			0,
			KEY_QUERY_VALUE,
			&hKey);

	if (res!=ERROR_SUCCESS)
	{	
		return;
	}

	DWORD Type;
	DWORD Data;
	DWORD Size = sizeof(Data);

	res = RegQueryValueEx(
			hKey,
			TEXT("WaitTime"),
			NULL,
			&Type,
			(BYTE*) &Data,
			&Size);

	if ((res!=ERROR_SUCCESS)||(Type!=REG_DWORD))
	{
		RegCloseKey(hKey);
		return;
	}

	if (Data > MAX_WAIT)
	{
		Data = MAX_WAIT;
	}
	else if (Data < MIN_WAIT)
	{
		Data = MIN_WAIT;
	}

	*pWait = Data;

	RegCloseKey(hKey);
}

// ���������� �������� � ������
bool WriteWaitTime(DWORD Wait)
{
	TCHAR KeyName[256];

	wsprintf(
		KeyName, 
		TEXT("System\\CurrentControlSet\\Services\\%s\\Parameters"), 
		ServiceName);

	HKEY  hKey;
	DWORD res;

	res = RegCreateKeyEx(
			HKEY_LOCAL_MACHINE,
			KeyName,
			0,
			NULL,
			0,
			KEY_SET_VALUE,
			NULL,
			&hKey,
			NULL);

	if (res!=ERROR_SUCCESS)
	{	
		return false;
	}

	res = RegSetValueEx(
			hKey,
			TEXT("WaitTime"),
			0,
			REG_DWORD,
			(CONST BYTE*) &Wait,
			sizeof(Wait));

	if (res!=ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return false;
	}

	RegCloseKey(hKey);
	return true;
}

// �������� ������ ���������
void Signal()
{
	SC_HANDLE hSCM;
	SC_HANDLE hService;

	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);

	if (!hSCM)
	{
		return;
	}

	hService = OpenService(hSCM, ServiceName, SERVICE_USER_DEFINED_CONTROL);
	
	if (!hService)
	{
		CloseServiceHandle(hSCM);

		return;
	}

	SERVICE_STATUS sStatus;

	ControlService(hService, PARAMETERS_CHANGED, &sStatus);

	CloseServiceHandle(hService);
	CloseServiceHandle(hSCM);
}

/////////////////////////////////////////////////////////////////////////////////////////////
